export type UserRole = 'client' | 'professional';
export type BookingStatus = 'pending' | 'confirmed' | 'completed' | 'cancelled';
export type PaymentStatus = 'pending' | 'paid' | 'refunded';
export type DocumentType = 'rg' | 'cpf' | 'address_proof' | 'criminal_record';
export type DocumentStatus = 'pending' | 'approved' | 'rejected';
export type VerificationStatus = 'pending' | 'documents_submitted' | 'verified' | 'rejected';

export interface Profile {
  id: string;
  user_id: string;
  role: UserRole;
  full_name: string;
  phone: string | null;
  avatar_url: string | null;
  bio: string | null;
  services_offered: string[];
  hourly_rate: number | null;
  city: string | null;
  neighborhood: string | null;
  average_rating: number;
  total_reviews: number;
  is_active: boolean;
  pix_key: string | null;
  pix_key_type: string | null;
  verification_status: VerificationStatus;
  terms_accepted_at: string | null;
  criminal_record_checked_at: string | null;
  criminal_record_status: string | null;
  created_at: string;
  updated_at: string;
}

export interface ProfessionalDocument {
  id: string;
  professional_id: string;
  document_type: DocumentType;
  file_url: string;
  file_name: string;
  status: DocumentStatus;
  rejection_reason: string | null;
  reviewed_at: string | null;
  reviewed_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface Booking {
  id: string;
  client_id: string;
  professional_id: string;
  service_type: string;
  scheduled_date: string;
  scheduled_time: string;
  hours: number;
  address: string;
  notes: string | null;
  status: BookingStatus;
  total_amount: number;
  created_at: string;
  updated_at: string;
  professional?: Profile;
  client?: Profile;
}

export interface Review {
  id: string;
  booking_id: string;
  client_id: string;
  professional_id: string;
  rating: number;
  comment: string | null;
  created_at: string;
  client?: Profile;
}

export interface Payment {
  id: string;
  booking_id: string;
  amount: number;
  status: PaymentStatus;
  payment_method: string | null;
  paid_at: string | null;
  created_at: string;
}
