import { useState, useEffect } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, Star, MapPin, DollarSign, Zap, ShieldCheck, ArrowLeft, Sparkles, Wrench, Leaf, Wind, Waves } from 'lucide-react';

interface Category {
  id: string;
  name: string;
  description: string | null;
}

interface Subcategory {
  id: string;
  category_id: string;
  name: string;
}

interface ServiceItem {
  id: string;
  name: string;
  category_id: string | null;
  subcategory_id: string | null;
}

interface ProfResult {
  professional_id: string;
  price: number;
  charge_type: string;
  handles_emergency: boolean;
  profile: {
    id: string;
    full_name: string;
    avatar_url: string | null;
    city: string | null;
    neighborhood: string | null;
    average_rating: number | null;
    total_reviews: number | null;
    verification_status: string | null;
    latitude: number | null;
    longitude: number | null;
  };
}

const CATEGORY_ICONS: Record<string, any> = {
  'Limpeza e Higienização': Sparkles,
  'Manutenção e Reparos': Wrench,
  'Jardinagem e Áreas Externas': Leaf,
  'Climatização': Wind,
  'Piscinas e Áreas de Lazer': Waves,
};

const CATEGORY_COLORS = [
  'from-blue-500 to-cyan-500',
  'from-orange-500 to-amber-500',
  'from-green-500 to-emerald-500',
  'from-purple-500 to-violet-500',
  'from-sky-500 to-blue-500',
];

export default function BuscarServicos() {
  const { profile } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();
  const [categories, setCategories] = useState<Category[]>([]);
  const [subcategories, setSubcategories] = useState<Subcategory[]>([]);
  const [services, setServices] = useState<ServiceItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [professionals, setProfessionals] = useState<ProfResult[]>([]);
  const [loadingProfs, setLoadingProfs] = useState(false);
  const [sortBy, setSortBy] = useState('proximity');

  const selectedCatId = searchParams.get('categoria');
  const selectedSubcatId = searchParams.get('subcategoria');
  const selectedServiceId = searchParams.get('servico');

  useEffect(() => {
    fetchCatalog();
  }, []);

  useEffect(() => {
    if (selectedServiceId) {
      fetchProfessionals(selectedServiceId);
    }
  }, [selectedServiceId]);

  const fetchCatalog = async () => {
    const [catsRes, subcatsRes, svcsRes] = await Promise.all([
      supabase.from('service_categories').select('*').eq('is_active', true).order('name'),
      supabase.from('service_subcategories').select('*').eq('is_active', true).order('name'),
      supabase.from('services').select('*').eq('is_active', true).order('name'),
    ]);
    setCategories((catsRes.data || []) as Category[]);
    setSubcategories((subcatsRes.data || []) as Subcategory[]);
    setServices((svcsRes.data || []) as ServiceItem[]);
    setLoading(false);
  };

  const fetchProfessionals = async (serviceId: string) => {
    setLoadingProfs(true);
    try {
      const { data, error } = await supabase
        .from('professional_services')
        .select(`
          professional_id,
          price,
          charge_type,
          handles_emergency,
          profile:profiles!professional_services_professional_id_fkey(
            id, full_name, avatar_url, city, neighborhood,
            average_rating, total_reviews, verification_status,
            latitude, longitude
          )
        `)
        .eq('service_id', serviceId)
        .eq('is_active', true);

      if (error) throw error;

      // Filter: only verified, active, contract accepted professionals from same city
      const filtered = (data || []).filter((p: any) => {
        const prof = Array.isArray(p.profile) ? p.profile[0] : p.profile;
        if (!prof) return false;
        if (prof.verification_status !== 'verified') return false;
        if (profile?.city && prof.city !== profile.city) return false;
        return true;
      }).map((p: any) => ({
        ...p,
        profile: Array.isArray(p.profile) ? p.profile[0] : p.profile,
      }));

      setProfessionals(filtered as ProfResult[]);
    } catch (err) {
      console.error('Erro ao buscar profissionais:', err);
    } finally {
      setLoadingProfs(false);
    }
  };

  const getDistance = (prof: ProfResult['profile']): number | null => {
    if (!(profile as any)?.latitude || !(profile as any)?.longitude || !prof.latitude || !prof.longitude) return null;
    const R = 6371;
    const dLat = (prof.latitude - (profile as any).latitude) * Math.PI / 180;
    const dLon = (prof.longitude - (profile as any).longitude) * Math.PI / 180;
    const a = Math.sin(dLat / 2) ** 2 +
      Math.cos((profile as any).latitude * Math.PI / 180) *
      Math.cos(prof.latitude * Math.PI / 180) *
      Math.sin(dLon / 2) ** 2;
    return R * 2 * Math.asin(Math.sqrt(a));
  };

  const sortedProfessionals = [...professionals].sort((a, b) => {
    switch (sortBy) {
      case 'rating':
        return (b.profile.average_rating || 0) - (a.profile.average_rating || 0);
      case 'reviews':
        return (b.profile.total_reviews || 0) - (a.profile.total_reviews || 0);
      case 'price_asc':
        return a.price - b.price;
      case 'price_desc':
        return b.price - a.price;
      case 'proximity':
      default: {
        const distA = getDistance(a.profile) ?? 9999;
        const distB = getDistance(b.profile) ?? 9999;
        return distA - distB;
      }
    }
  });

  const navigate = (params: Record<string, string | null>) => {
    const sp = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => { if (v) sp.set(k, v); });
    setSearchParams(sp);
    setProfessionals([]);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <Header />
        <main className="flex-1 flex items-center justify-center"><Loader2 className="h-8 w-8 animate-spin text-primary" /></main>
        <Footer />
      </div>
    );
  }

  const selectedCat = categories.find(c => c.id === selectedCatId);
  const selectedSubcat = subcategories.find(sc => sc.id === selectedSubcatId);
  const selectedService = services.find(s => s.id === selectedServiceId);

  // Step 1: Show categories
  if (!selectedCatId) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <Header />
        <main className="flex-1 container mx-auto px-4 py-8 pt-24">
          <h1 className="text-3xl font-bold mb-2">O que você precisa?</h1>
          <p className="text-muted-foreground mb-8">Escolha uma categoria de serviço</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {categories.map((cat, i) => {
              const Icon = CATEGORY_ICONS[cat.name] || Sparkles;
              return (
                <Card
                  key={cat.id}
                  className="cursor-pointer hover:shadow-lg transition-all hover:-translate-y-1"
                  onClick={() => navigate({ categoria: cat.id })}
                >
                  <CardContent className="pt-6">
                    <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${CATEGORY_COLORS[i % CATEGORY_COLORS.length]} flex items-center justify-center mb-4`}>
                      <Icon className="h-7 w-7 text-white" />
                    </div>
                    <h3 className="text-lg font-semibold">{cat.name}</h3>
                    <p className="text-sm text-muted-foreground mt-1">{cat.description}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  // Step 2: Show subcategories
  if (selectedCatId && !selectedSubcatId && !selectedServiceId) {
    const catSubcats = subcategories.filter(sc => sc.category_id === selectedCatId);
    const directServices = services.filter(s => s.category_id === selectedCatId && !s.subcategory_id);

    return (
      <div className="min-h-screen flex flex-col bg-background">
        <Header />
        <main className="flex-1 container mx-auto px-4 py-8 pt-24">
          <Button variant="ghost" className="mb-4" onClick={() => navigate({})}>
            <ArrowLeft className="h-4 w-4 mr-2" /> Voltar
          </Button>
          <h1 className="text-2xl font-bold mb-6">{selectedCat?.name}</h1>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {catSubcats.map(sc => (
              <Card
                key={sc.id}
                className="cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => navigate({ categoria: selectedCatId, subcategoria: sc.id })}
              >
                <CardContent className="py-4 px-5">
                  <h3 className="font-medium">{sc.name}</h3>
                </CardContent>
              </Card>
            ))}
            {directServices.map(svc => (
              <Card
                key={svc.id}
                className="cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => navigate({ categoria: selectedCatId, servico: svc.id })}
              >
                <CardContent className="py-4 px-5">
                  <h3 className="font-medium">{svc.name}</h3>
                </CardContent>
              </Card>
            ))}
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  // Step 3: Show services in subcategory
  if (selectedSubcatId && !selectedServiceId) {
    const subcatServices = services.filter(s => s.subcategory_id === selectedSubcatId);
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <Header />
        <main className="flex-1 container mx-auto px-4 py-8 pt-24">
          <Button variant="ghost" className="mb-4" onClick={() => navigate({ categoria: selectedCatId })}>
            <ArrowLeft className="h-4 w-4 mr-2" /> Voltar
          </Button>
          <h1 className="text-2xl font-bold mb-2">{selectedSubcat?.name}</h1>
          <p className="text-muted-foreground mb-6">Escolha o serviço específico</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {subcatServices.map(svc => (
              <Card
                key={svc.id}
                className="cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => navigate({ categoria: selectedCatId, subcategoria: selectedSubcatId, servico: svc.id })}
              >
                <CardContent className="py-4 px-5">
                  <h3 className="font-medium">{svc.name}</h3>
                </CardContent>
              </Card>
            ))}
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  // Step 4: Show professionals for selected service
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      <main className="flex-1 container mx-auto px-4 py-8 pt-24">
        <Button
          variant="ghost"
          className="mb-4"
          onClick={() => {
            if (selectedSubcatId) navigate({ categoria: selectedCatId, subcategoria: selectedSubcatId });
            else navigate({ categoria: selectedCatId });
          }}
        >
          <ArrowLeft className="h-4 w-4 mr-2" /> Voltar
        </Button>

        <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
          <div>
            <h1 className="text-2xl font-bold">{selectedService?.name}</h1>
            <p className="text-muted-foreground">
              {sortedProfessionals.length} profissional{sortedProfessionals.length !== 1 ? 'is' : ''} disponível{sortedProfessionals.length !== 1 ? 'is' : ''}
            </p>
          </div>
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="proximity">📍 Mais próximo</SelectItem>
              <SelectItem value="rating">⭐ Melhor avaliado</SelectItem>
              <SelectItem value="reviews">📊 Mais avaliações</SelectItem>
              <SelectItem value="price_asc">💰 Menor preço</SelectItem>
              <SelectItem value="price_desc">💰 Maior preço</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {loadingProfs ? (
          <div className="flex justify-center py-12"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>
        ) : sortedProfessionals.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <p className="text-muted-foreground">Nenhum profissional disponível para este serviço na sua cidade.</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4">
            {sortedProfessionals.map(prof => {
              const dist = getDistance(prof.profile);
              return (
                <Link key={prof.professional_id} to={`/profissional/${prof.profile.id}`}>
                  <Card className="hover:shadow-md transition-shadow">
                    <CardContent className="pt-6">
                      <div className="flex gap-4">
                        <div className="w-14 h-14 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white text-lg font-bold flex-shrink-0">
                          {prof.profile.avatar_url ? (
                            <img src={prof.profile.avatar_url} alt="" className="w-full h-full rounded-full object-cover" />
                          ) : (
                            prof.profile.full_name.charAt(0)
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2">
                            <div>
                              <div className="flex items-center gap-2">
                                <h3 className="font-semibold text-lg">{prof.profile.full_name}</h3>
                                {prof.profile.verification_status === 'verified' && (
                                  <ShieldCheck className="h-4 w-4 text-green-500" />
                                )}
                              </div>
                              <p className="text-sm text-muted-foreground flex items-center gap-1">
                                <MapPin className="h-3 w-3" />
                                {[prof.profile.neighborhood, prof.profile.city].filter(Boolean).join(', ')}
                                {dist !== null && <span className="ml-1">· {dist.toFixed(1)} km</span>}
                              </p>
                            </div>
                            <div className="text-right flex-shrink-0">
                              <p className="font-bold text-primary text-lg">
                                R$ {prof.price.toFixed(2)}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                /{prof.charge_type === 'hour' ? 'hora' : 'período'}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center gap-3 mt-2 flex-wrap">
                            <div className="flex items-center gap-1">
                              <div className="flex gap-0.5">
                                {[1, 2, 3, 4, 5].map(s => (
                                  <Star key={s} className={`h-3.5 w-3.5 ${s <= Math.round(prof.profile.average_rating || 0) ? 'fill-yellow-400 text-yellow-400' : 'text-muted-foreground/30'}`} />
                                ))}
                              </div>
                              <span className="text-sm font-medium">{(prof.profile.average_rating || 0).toFixed(1)}</span>
                              <span className="text-xs text-muted-foreground">({prof.profile.total_reviews || 0})</span>
                            </div>
                            {prof.handles_emergency && (
                              <Badge variant="outline" className="text-xs text-orange-600 border-orange-300">
                                <Zap className="h-3 w-3 mr-0.5" /> Emergência
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              );
            })}
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
}
