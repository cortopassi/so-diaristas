import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { usePWA } from "@/hooks/usePWA";
import { Download, Smartphone, CheckCircle, Share, PlusSquare, MoreVertical } from "lucide-react";
import { Link } from "react-router-dom";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";

export default function Install() {
  const { isInstallable, isInstalled, install, isOnline } = usePWA();

  const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
  const isAndroid = /Android/.test(navigator.userAgent);

  const handleInstall = async () => {
    const success = await install();
    if (success) {
      // Successfully installed
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      
      <main className="flex-1 container mx-auto px-4 py-12">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-8">
            <div className="w-20 h-20 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Smartphone className="w-10 h-10 text-primary" />
            </div>
            <h1 className="text-3xl font-bold text-foreground mb-2">
              Instale o Só Diaristas
            </h1>
            <p className="text-muted-foreground">
              Tenha acesso rápido ao app direto da tela inicial do seu celular
            </p>
          </div>

          {!isOnline && (
            <Card className="mb-6 border-destructive/50 bg-destructive/10">
              <CardContent className="pt-6">
                <p className="text-destructive text-center">
                  Você está offline. Conecte-se à internet para instalar o app.
                </p>
              </CardContent>
            </Card>
          )}

          {isInstalled ? (
            <Card className="mb-6 border-secondary bg-secondary/10">
              <CardContent className="pt-6">
                <div className="flex items-center justify-center gap-3 text-secondary">
                  <CheckCircle className="w-6 h-6" />
                  <span className="text-lg font-medium">App já instalado!</span>
                </div>
                <p className="text-center text-muted-foreground mt-2">
                  Você pode acessar o Só Diaristas pela tela inicial do seu dispositivo.
                </p>
                <div className="text-center mt-4">
                  <Link to="/">
                    <Button>Voltar para o início</Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          ) : (
            <>
              {/* Android Install Button */}
              {isInstallable && (
                <Card className="mb-6">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Download className="w-5 h-5 text-primary" />
                      Instalação Rápida
                    </CardTitle>
                    <CardDescription>
                      Clique no botão abaixo para instalar o app
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button 
                      onClick={handleInstall} 
                      className="w-full" 
                      size="lg"
                    >
                      <Download className="w-5 h-5 mr-2" />
                      Instalar App
                    </Button>
                  </CardContent>
                </Card>
              )}

              {/* iOS Instructions */}
              {isIOS && !isInstallable && (
                <Card className="mb-6">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Share className="w-5 h-5 text-primary" />
                      Como instalar no iPhone/iPad
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ol className="space-y-4">
                      <li className="flex items-start gap-3">
                        <span className="w-7 h-7 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-bold shrink-0">
                          1
                        </span>
                        <div>
                          <p className="font-medium">Toque no ícone de compartilhar</p>
                          <p className="text-sm text-muted-foreground flex items-center gap-1 mt-1">
                            <Share className="w-4 h-4" /> na barra inferior do Safari
                          </p>
                        </div>
                      </li>
                      <li className="flex items-start gap-3">
                        <span className="w-7 h-7 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-bold shrink-0">
                          2
                        </span>
                        <div>
                          <p className="font-medium">Role e toque em "Adicionar à Tela de Início"</p>
                          <p className="text-sm text-muted-foreground flex items-center gap-1 mt-1">
                            <PlusSquare className="w-4 h-4" /> Add to Home Screen
                          </p>
                        </div>
                      </li>
                      <li className="flex items-start gap-3">
                        <span className="w-7 h-7 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-bold shrink-0">
                          3
                        </span>
                        <div>
                          <p className="font-medium">Confirme tocando em "Adicionar"</p>
                          <p className="text-sm text-muted-foreground mt-1">
                            O ícone do app aparecerá na sua tela inicial
                          </p>
                        </div>
                      </li>
                    </ol>
                  </CardContent>
                </Card>
              )}

              {/* Android Manual Instructions */}
              {isAndroid && !isInstallable && (
                <Card className="mb-6">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <MoreVertical className="w-5 h-5 text-primary" />
                      Como instalar no Android
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ol className="space-y-4">
                      <li className="flex items-start gap-3">
                        <span className="w-7 h-7 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-bold shrink-0">
                          1
                        </span>
                        <div>
                          <p className="font-medium">Toque no menu do navegador</p>
                          <p className="text-sm text-muted-foreground flex items-center gap-1 mt-1">
                            <MoreVertical className="w-4 h-4" /> (três pontos) no canto superior
                          </p>
                        </div>
                      </li>
                      <li className="flex items-start gap-3">
                        <span className="w-7 h-7 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-bold shrink-0">
                          2
                        </span>
                        <div>
                          <p className="font-medium">Selecione "Instalar aplicativo"</p>
                          <p className="text-sm text-muted-foreground mt-1">
                            ou "Adicionar à tela inicial"
                          </p>
                        </div>
                      </li>
                      <li className="flex items-start gap-3">
                        <span className="w-7 h-7 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-bold shrink-0">
                          3
                        </span>
                        <div>
                          <p className="font-medium">Confirme a instalação</p>
                          <p className="text-sm text-muted-foreground mt-1">
                            O app será adicionado à sua tela inicial
                          </p>
                        </div>
                      </li>
                    </ol>
                  </CardContent>
                </Card>
              )}

              {/* Desktop Instructions */}
              {!isIOS && !isAndroid && !isInstallable && (
                <Card className="mb-6">
                  <CardHeader>
                    <CardTitle>Instalação no Computador</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground mb-4">
                      Se você estiver usando Chrome, Edge ou Brave, procure pelo ícone de instalação 
                      na barra de endereços do navegador.
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Para a melhor experiência, recomendamos acessar este site pelo seu celular.
                    </p>
                  </CardContent>
                </Card>
              )}
            </>
          )}

          {/* Benefits */}
          <Card>
            <CardHeader>
              <CardTitle>Benefícios do App</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                <li className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-secondary shrink-0" />
                  <span>Acesso rápido pela tela inicial</span>
                </li>
                <li className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-secondary shrink-0" />
                  <span>Funciona offline com informações básicas</span>
                </li>
                <li className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-secondary shrink-0" />
                  <span>Notificações de novos agendamentos</span>
                </li>
                <li className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-secondary shrink-0" />
                  <span>Experiência de app nativo</span>
                </li>
                <li className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-secondary shrink-0" />
                  <span>Não ocupa espaço de armazenamento</span>
                </li>
              </ul>
            </CardContent>
          </Card>

          <div className="text-center mt-8">
            <Link to="/" className="text-primary hover:underline">
              ← Voltar para o site
            </Link>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
