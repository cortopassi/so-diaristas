import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';
import { Loader2, CheckCircle2, MapPin } from 'lucide-react';
import { formatCPF, validateCPF } from '@/lib/cpfValidator';
import { fetchCep, formatCep } from '@/lib/viaCep';
import { generateOTP } from '@/lib/otp';

export default function CadastroCliente() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [cepLoading, setCepLoading] = useState(false);
  const [otpCode, setOtpCode] = useState('');
  const [showOtp, setShowOtp] = useState(false);

  // Form state
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [dateOfBirth, setDateOfBirth] = useState('');
  const [email, setEmail] = useState('');
  const [cpf, setCpf] = useState('');
  const [cep, setCep] = useState('');
  const [rua, setRua] = useState('');
  const [numero, setNumero] = useState('');
  const [complemento, setComplemento] = useState('');
  const [bairro, setBairro] = useState('');
  const [cidade, setCidade] = useState('');
  const [estado, setEstado] = useState('');
  const [latitude, setLatitude] = useState<number | null>(null);
  const [longitude, setLongitude] = useState<number | null>(null);
  const [geoLoading, setGeoLoading] = useState(false);

  const formatPhone = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    if (numbers.length <= 2) return numbers;
    if (numbers.length <= 7) return `(${numbers.slice(0, 2)}) ${numbers.slice(2)}`;
    return `(${numbers.slice(0, 2)}) ${numbers.slice(2, 7)}-${numbers.slice(7, 11)}`;
  };

  const handleCepChange = async (value: string) => {
    const formatted = formatCep(value);
    setCep(formatted);
    const clean = value.replace(/\D/g, '');
    if (clean.length === 8) {
      setCepLoading(true);
      const data = await fetchCep(clean);
      if (data) {
        setRua(data.logradouro);
        setBairro(data.bairro);
        setCidade(data.localidade);
        setEstado(data.uf);
      } else {
        toast.error('CEP não encontrado');
      }
      setCepLoading(false);
    }
  };

  const handleGeolocation = () => {
    if (!navigator.geolocation) {
      toast.error('Geolocalização não suportada pelo navegador');
      return;
    }
    setGeoLoading(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLatitude(pos.coords.latitude);
        setLongitude(pos.coords.longitude);
        setGeoLoading(false);
        toast.success('Localização capturada!');
      },
      () => {
        setGeoLoading(false);
        toast.error('Não foi possível obter a localização');
      }
    );
  };

  const validateStep1 = () => {
    if (!fullName.trim()) { toast.error('Nome completo é obrigatório'); return false; }
    if (!phone.trim()) { toast.error('Telefone é obrigatório'); return false; }
    if (!dateOfBirth) { toast.error('Data de nascimento é obrigatória'); return false; }
    if (!email.trim()) { toast.error('E-mail é obrigatório'); return false; }
    if (!validateCPF(cpf)) { toast.error('CPF inválido'); return false; }
    if (!cep.trim() || !cidade.trim()) { toast.error('CEP e endereço são obrigatórios'); return false; }
    if (!numero.trim()) { toast.error('Número é obrigatório'); return false; }
    if (!latitude || !longitude) { toast.error('Ative sua geolocalização'); return false; }
    return true;
  };

  const handleSubmit = async () => {
    if (!validateStep1()) return;
    setLoading(true);

    try {
      console.log('[DEBUG] Iniciando cadastro cliente...');
      const invisiblePassword = crypto.randomUUID();

      const { data: authData, error: authError } = await supabase.auth.signUp({
        email,
        password: invisiblePassword,
      });

      console.log('[DEBUG] signUp result:', { user: authData?.user?.id, error: authError });
      if (authError) throw authError;

      if (authData.user) {
        const profileData = {
          user_id: authData.user.id,
          full_name: fullName,
          role: 'client' as const,
          phone,
          city: cidade,
          neighborhood: bairro,
          cpf: cpf.replace(/\D/g, ''),
          date_of_birth: dateOfBirth,
          cep: cep.replace(/\D/g, ''),
          rua,
          numero,
          complemento,
          estado,
          latitude,
          longitude,
        };
        console.log('[DEBUG] Inserindo profile:', profileData);

        const { error: profileError } = await supabase
          .from('profiles')
          .insert(profileData as any);

        if (profileError) {
          console.error('[DEBUG] Profile insert error:', profileError);
          throw profileError;
        }
        console.log('[DEBUG] Profile criado com sucesso!');

        // Generate and store OTP
        const code = generateOTP();
        const { error: otpError } = await supabase
          .from('otp_codes')
          .insert({
            cpf: cpf.replace(/\D/g, ''),
            code,
            expires_at: new Date(Date.now() + 5 * 60 * 1000).toISOString(),
          } as any);

        if (otpError) {
          console.warn('[DEBUG] OTP insert error:', otpError);
        }

        setOtpCode(code);
        setShowOtp(true);
        setStep(2);
      }

      toast.success('Cadastro realizado com sucesso!');
    } catch (error: any) {
      console.error('[DEBUG] Erro no cadastro cliente:', error);
      toast.error('Erro ao criar conta', { description: error.message });
    } finally {
      setLoading(false);
    }
  };

  if (step === 2 && showOtp) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/5 to-secondary/5 p-4">
        <Card className="w-full max-w-md text-center">
          <CardHeader>
            <CheckCircle2 className="h-16 w-16 text-secondary mx-auto mb-4" />
            <CardTitle>Cadastro Realizado!</CardTitle>
            <CardDescription>
              Seu código de acesso temporário
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-muted rounded-lg p-6">
              <p className="text-sm text-muted-foreground mb-2">Seu código OTP:</p>
              <p className="text-4xl font-bold tracking-widest text-primary">{otpCode}</p>
              <p className="text-xs text-muted-foreground mt-2">Válido por 5 minutos</p>
            </div>
            <p className="text-sm text-muted-foreground">
              Use seu CPF e este código para entrar na plataforma.
            </p>
            <Button onClick={() => navigate('/login')} className="w-full">
              Ir para Login
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/5 to-secondary/5 p-4 py-12">
      <Card className="w-full max-w-lg">
        <CardHeader className="text-center">
          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center mx-auto mb-4">
            <span className="text-white font-bold text-xl">SD</span>
          </div>
          <CardTitle className="text-2xl">Cadastro Cliente</CardTitle>
          <CardDescription>Preencha seus dados para criar sua conta</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 gap-4">
            <div className="space-y-2">
              <Label>Nome completo *</Label>
              <Input value={fullName} onChange={(e) => setFullName(e.target.value)} placeholder="Maria da Silva" required />
            </div>
            <div className="space-y-2">
              <Label>CPF *</Label>
              <Input value={cpf} onChange={(e) => setCpf(formatCPF(e.target.value))} placeholder="000.000.000-00" maxLength={14} required />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Telefone (WhatsApp) *</Label>
                <Input value={phone} onChange={(e) => setPhone(formatPhone(e.target.value))} placeholder="(47) 99999-9999" maxLength={15} required />
              </div>
              <div className="space-y-2">
                <Label>Data de nascimento *</Label>
                <Input type="date" value={dateOfBirth} onChange={(e) => setDateOfBirth(e.target.value)} required />
              </div>
            </div>
            <div className="space-y-2">
              <Label>E-mail *</Label>
              <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="seu@email.com" required />
            </div>
          </div>

          {/* Endereço */}
          <div className="border-t pt-4 mt-4">
            <h3 className="font-semibold mb-3">Endereço</h3>
            <div className="grid grid-cols-1 gap-4">
              <div className="space-y-2">
                <Label>CEP *</Label>
                <div className="relative">
                  <Input value={cep} onChange={(e) => handleCepChange(e.target.value)} placeholder="00000-000" maxLength={9} required />
                  {cepLoading && <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 animate-spin" />}
                </div>
              </div>
              <div className="space-y-2">
                <Label>Rua</Label>
                <Input value={rua} onChange={(e) => setRua(e.target.value)} readOnly className="bg-muted" />
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label>Número *</Label>
                  <Input value={numero} onChange={(e) => setNumero(e.target.value)} placeholder="123" required />
                </div>
                <div className="space-y-2 col-span-2">
                  <Label>Complemento</Label>
                  <Input value={complemento} onChange={(e) => setComplemento(e.target.value)} placeholder="Apto 101" />
                </div>
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label>Bairro</Label>
                  <Input value={bairro} readOnly className="bg-muted" />
                </div>
                <div className="space-y-2">
                  <Label>Cidade</Label>
                  <Input value={cidade} readOnly className="bg-muted" />
                </div>
                <div className="space-y-2">
                  <Label>Estado</Label>
                  <Input value={estado} readOnly className="bg-muted" />
                </div>
              </div>
            </div>
          </div>

          {/* Geolocalização */}
          <div className="border-t pt-4">
            <Button
              type="button"
              variant={latitude ? 'secondary' : 'outline'}
              onClick={handleGeolocation}
              disabled={geoLoading}
              className="w-full"
            >
              {geoLoading ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <MapPin className="h-4 w-4 mr-2" />
              )}
              {latitude ? '📍 Localização capturada!' : 'Ativar minha localização *'}
            </Button>
          </div>

          <Button onClick={handleSubmit} disabled={loading} className="w-full mt-6">
            {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Criar minha conta
          </Button>

          <p className="text-sm text-muted-foreground text-center">
            Já tem conta?{' '}
            <a href="/login" className="text-primary hover:underline font-medium">Entrar</a>
            {' · '}
            <a href="/cadastro-profissional" className="text-secondary hover:underline font-medium">Sou profissional</a>
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
