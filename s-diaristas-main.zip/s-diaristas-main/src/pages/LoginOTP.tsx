import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { Loader2, KeyRound } from 'lucide-react';
import { formatCPF, validateCPF } from '@/lib/cpfValidator';

export default function LoginOTP() {
  const navigate = useNavigate();
  const [step, setStep] = useState<'cpf' | 'otp'>('cpf');
  const [cpf, setCpf] = useState('');
  const [otpInput, setOtpInput] = useState('');
  const [generatedOtp, setGeneratedOtp] = useState('');
  const [loading, setLoading] = useState(false);
  const [fullName, setFullName] = useState('');

  const handleRequestCode = async () => {
    if (!validateCPF(cpf)) {
      toast.error('CPF inválido');
      return;
    }
    setLoading(true);

    try {
      const cleanCpf = cpf.replace(/\D/g, '');

      const { data, error } = await supabase.functions.invoke('otp-login', {
        body: { action: 'request', cpf: cleanCpf },
      });

      if (error) throw error;
      if (data?.error) {
        toast.error(data.error);
        setLoading(false);
        return;
      }

      setGeneratedOtp(data.otp);
      setFullName(data.full_name);
      setStep('otp');
      toast.success(`Código gerado para ${data.full_name}!`);
    } catch (error: any) {
      toast.error('Erro ao buscar conta', { description: error.message });
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOtp = async () => {
    if (otpInput !== generatedOtp) {
      toast.error('Código incorreto');
      return;
    }

    setLoading(true);
    try {
      const cleanCpf = cpf.replace(/\D/g, '');

      const { data, error } = await supabase.functions.invoke('otp-login', {
        body: { action: 'verify', cpf: cleanCpf, code: otpInput },
      });

      if (error) throw error;
      if (data?.error) {
        toast.error(data.error);
        setLoading(false);
        return;
      }

      // Use the token to verify OTP and sign in
      const { error: verifyError } = await supabase.auth.verifyOtp({
        email: data.email,
        token: data.token,
        type: 'magiclink',
      });

      if (verifyError) throw verifyError;

      toast.success('Login realizado com sucesso!');
      navigate(data.role === 'professional' ? '/painel-profissional' : '/painel-cliente');
    } catch (error: any) {
      toast.error('Erro no login', { description: error.message });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/5 to-secondary/5 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <Link to="/" className="flex items-center justify-center gap-2 mb-4">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
              <span className="text-white font-bold text-xl">SD</span>
            </div>
          </Link>
          <CardTitle className="text-2xl">Entrar</CardTitle>
          <CardDescription>
            {step === 'cpf' ? 'Digite seu CPF para receber o código de acesso' : 'Digite o código de acesso'}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {step === 'cpf' ? (
            <>
              <div className="space-y-2">
                <Label>CPF</Label>
                <Input
                  value={cpf}
                  onChange={(e) => setCpf(formatCPF(e.target.value))}
                  placeholder="000.000.000-00"
                  maxLength={14}
                />
              </div>
              <Button onClick={handleRequestCode} disabled={loading} className="w-full">
                {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Receber código
              </Button>
            </>
          ) : (
            <>
              {/* Show OTP on screen for dev */}
              <div className="bg-muted rounded-lg p-4 text-center">
                <p className="text-xs text-muted-foreground mb-1">Código de acesso (dev):</p>
                <p className="text-3xl font-bold tracking-widest text-primary">{generatedOtp}</p>
                <p className="text-xs text-muted-foreground mt-1">Válido por 5 minutos</p>
              </div>

              <div className="space-y-2">
                <Label>Digite o código</Label>
                <Input
                  value={otpInput}
                  onChange={(e) => setOtpInput(e.target.value.replace(/\D/g, ''))}
                  placeholder="000000"
                  maxLength={6}
                  className="text-center text-2xl tracking-widest"
                />
              </div>
              <Button onClick={handleVerifyOtp} disabled={loading} className="w-full">
                {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                <KeyRound className="mr-2 h-4 w-4" />
                Entrar
              </Button>
              <Button variant="ghost" onClick={() => setStep('cpf')} className="w-full">
                Voltar
              </Button>
            </>
          )}

          <div className="text-center text-sm text-muted-foreground pt-2">
            Não tem conta?{' '}
            <Link to="/cadastro-cliente" className="text-primary hover:underline font-medium">Cliente</Link>
            {' · '}
            <Link to="/cadastro-profissional" className="text-secondary hover:underline font-medium">Profissional</Link>
          </div>

          <div className="text-center pt-2">
            <Link to="/" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              ← Voltar ao site
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
