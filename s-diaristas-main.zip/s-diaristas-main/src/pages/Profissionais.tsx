import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Loader2, Star, MapPin, Search, Filter, X } from 'lucide-react';
import { Profile } from '@/types/database';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';

const SERVICES = [
  'Limpeza Residencial',
  'Limpeza Comercial',
  'Passadoria',
  'Cozinha',
  'Limpeza Pós-Obra',
  'Organização',
];

export default function Profissionais() {
  const [professionals, setProfessionals] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [filtersOpen, setFiltersOpen] = useState(false);

  // Filtros
  const [searchName, setSearchName] = useState('');
  const [selectedService, setSelectedService] = useState<string>('all');
  const [selectedCity, setSelectedCity] = useState('');
  const [maxPrice, setMaxPrice] = useState<number[]>([200]);
  const [minRating, setMinRating] = useState<number[]>([0]);

  // Cidades disponíveis
  const [availableCities, setAvailableCities] = useState<string[]>([]);

  useEffect(() => {
    fetchProfessionals();
  }, []);

  const fetchProfessionals = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('role', 'professional')
        .eq('is_active', true)
        .order('average_rating', { ascending: false });

      if (error) throw error;

      const profs = (data || []) as Profile[];
      setProfessionals(profs);

      // Extrair cidades únicas
      const cities = [...new Set(profs.map(p => p.city).filter(Boolean))] as string[];
      setAvailableCities(cities);
    } catch (error) {
      console.error('Erro ao buscar profissionais:', error);
    } finally {
      setLoading(false);
    }
  };

  // Aplicar filtros
  const filteredProfessionals = professionals.filter(prof => {
    // Filtro por nome
    if (searchName && !prof.full_name.toLowerCase().includes(searchName.toLowerCase())) {
      return false;
    }

    // Filtro por serviço
    if (selectedService && selectedService !== 'all') {
      if (!prof.services_offered?.includes(selectedService)) {
        return false;
      }
    }

    // Filtro por cidade
    if (selectedCity && prof.city !== selectedCity) {
      return false;
    }

    // Filtro por preço máximo
    if (prof.hourly_rate && prof.hourly_rate > maxPrice[0]) {
      return false;
    }

    // Filtro por avaliação mínima
    if ((prof.average_rating || 0) < minRating[0]) {
      return false;
    }

    return true;
  });

  const clearFilters = () => {
    setSearchName('');
    setSelectedService('all');
    setSelectedCity('');
    setMaxPrice([200]);
    setMinRating([0]);
  };

  const hasActiveFilters = searchName || (selectedService && selectedService !== 'all') || selectedCity || maxPrice[0] < 200 || minRating[0] > 0;

  const FiltersContent = () => (
    <div className="space-y-6">
      {/* Serviço */}
      <div className="space-y-2">
        <Label>Tipo de Serviço</Label>
        <Select value={selectedService} onValueChange={setSelectedService}>
          <SelectTrigger>
            <SelectValue placeholder="Todos os serviços" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos os serviços</SelectItem>
            {SERVICES.map(service => (
              <SelectItem key={service} value={service}>{service}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Cidade */}
      <div className="space-y-2">
        <Label>Cidade</Label>
        <Select value={selectedCity || 'all'} onValueChange={(v) => setSelectedCity(v === 'all' ? '' : v)}>
          <SelectTrigger>
            <SelectValue placeholder="Todas as cidades" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas as cidades</SelectItem>
            {availableCities.map(city => (
              <SelectItem key={city} value={city}>{city}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Preço Máximo */}
      <div className="space-y-3">
        <div className="flex justify-between">
          <Label>Preço Máximo por Hora</Label>
          <span className="text-sm font-medium">R$ {maxPrice[0]}</span>
        </div>
        <Slider
          value={maxPrice}
          onValueChange={setMaxPrice}
          min={20}
          max={200}
          step={10}
        />
      </div>

      {/* Avaliação Mínima */}
      <div className="space-y-3">
        <div className="flex justify-between">
          <Label>Avaliação Mínima</Label>
          <span className="text-sm font-medium flex items-center gap-1">
            <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
            {minRating[0].toFixed(1)}
          </span>
        </div>
        <Slider
          value={minRating}
          onValueChange={setMinRating}
          min={0}
          max={5}
          step={0.5}
        />
      </div>

      {hasActiveFilters && (
        <Button variant="outline" onClick={clearFilters} className="w-full">
          <X className="h-4 w-4 mr-2" />
          Limpar Filtros
        </Button>
      )}
    </div>
  );

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      
      <main className="flex-1 container mx-auto px-4 py-8 pt-24">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Encontre Profissionais</h1>
          <p className="text-muted-foreground">
            Profissionais verificadas e bem avaliadas perto de você
          </p>
        </div>

        {/* Barra de Busca */}
        <div className="flex gap-3 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar por nome..."
              value={searchName}
              onChange={(e) => setSearchName(e.target.value)}
              className="pl-10"
            />
          </div>
          
          {/* Filtros Mobile */}
          <Sheet open={filtersOpen} onOpenChange={setFiltersOpen}>
            <SheetTrigger asChild>
              <Button variant="outline" className="md:hidden relative">
                <Filter className="h-4 w-4" />
                {hasActiveFilters && (
                  <span className="absolute -top-1 -right-1 h-3 w-3 rounded-full bg-primary" />
                )}
              </Button>
            </SheetTrigger>
            <SheetContent>
              <SheetHeader>
                <SheetTitle>Filtros</SheetTitle>
              </SheetHeader>
              <div className="mt-6">
                <FiltersContent />
              </div>
            </SheetContent>
          </Sheet>
        </div>

        <div className="flex gap-8">
          {/* Filtros Desktop */}
          <aside className="hidden md:block w-64 flex-shrink-0">
            <Card>
              <CardContent className="pt-6">
                <h3 className="font-semibold mb-4 flex items-center gap-2">
                  <Filter className="h-4 w-4" />
                  Filtros
                </h3>
                <FiltersContent />
              </CardContent>
            </Card>
          </aside>

          {/* Lista de Profissionais */}
          <div className="flex-1">
            {loading ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : filteredProfessionals.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <Search className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
                  <p className="text-muted-foreground mb-4">
                    Nenhuma profissional encontrada com esses filtros
                  </p>
                  {hasActiveFilters && (
                    <Button variant="outline" onClick={clearFilters}>
                      Limpar Filtros
                    </Button>
                  )}
                </CardContent>
              </Card>
            ) : (
              <>
                <p className="text-sm text-muted-foreground mb-4">
                  {filteredProfessionals.length} profissional{filteredProfessionals.length !== 1 ? 'is' : ''} encontrada{filteredProfessionals.length !== 1 ? 's' : ''}
                </p>
                <div className="grid gap-4">
                  {filteredProfessionals.map(prof => (
                    <Link key={prof.id} to={`/profissional/${prof.id}`}>
                      <Card className="hover:shadow-md transition-shadow cursor-pointer">
                        <CardContent className="pt-6">
                          <div className="flex gap-4">
                            {/* Avatar */}
                            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white text-xl font-bold flex-shrink-0">
                              {prof.avatar_url ? (
                                <img
                                  src={prof.avatar_url}
                                  alt={prof.full_name}
                                  className="w-full h-full rounded-full object-cover"
                                />
                              ) : (
                                prof.full_name.charAt(0)
                              )}
                            </div>

                            {/* Info */}
                            <div className="flex-1 min-w-0">
                              <div className="flex items-start justify-between gap-2">
                                <div>
                                  <h3 className="font-semibold text-lg">{prof.full_name}</h3>
                                  {(prof.city || prof.neighborhood) && (
                                    <p className="text-sm text-muted-foreground flex items-center gap-1">
                                      <MapPin className="h-3 w-3" />
                                      {[prof.neighborhood, prof.city].filter(Boolean).join(', ')}
                                    </p>
                                  )}
                                </div>
                                {prof.hourly_rate && (
                                  <div className="text-right">
                                    <p className="font-bold text-primary">
                                      R$ {prof.hourly_rate.toFixed(2)}
                                    </p>
                                    <p className="text-xs text-muted-foreground">/hora</p>
                                  </div>
                                )}
                              </div>

                              {/* Rating */}
                              <div className="flex items-center gap-2 mt-2">
                                <div className="flex gap-0.5">
                                  {[1, 2, 3, 4, 5].map((star) => (
                                    <Star
                                      key={star}
                                      className={`h-4 w-4 ${
                                        star <= Math.round(prof.average_rating || 0)
                                          ? 'fill-yellow-400 text-yellow-400'
                                          : 'text-muted-foreground/30'
                                      }`}
                                    />
                                  ))}
                                </div>
                                <span className="text-sm font-medium">
                                  {(prof.average_rating || 0).toFixed(1)}
                                </span>
                                <span className="text-sm text-muted-foreground">
                                  ({prof.total_reviews} avaliações)
                                </span>
                              </div>

                              {/* Services */}
                              {prof.services_offered && prof.services_offered.length > 0 && (
                                <div className="flex flex-wrap gap-1 mt-3">
                                  {prof.services_offered.slice(0, 3).map((service) => (
                                    <Badge key={service} variant="secondary" className="text-xs">
                                      {service}
                                    </Badge>
                                  ))}
                                  {prof.services_offered.length > 3 && (
                                    <Badge variant="outline" className="text-xs">
                                      +{prof.services_offered.length - 3}
                                    </Badge>
                                  )}
                                </div>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </Link>
                  ))}
                </div>
              </>
            )}
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
