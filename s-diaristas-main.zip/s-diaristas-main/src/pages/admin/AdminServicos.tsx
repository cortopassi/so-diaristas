import { useEffect, useState } from 'react';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { supabase } from '@/integrations/supabase/client';
import { useAdmin } from '@/hooks/useAdmin';
import { toast } from '@/hooks/use-toast';
import { Plus, Edit, ToggleLeft, ToggleRight } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function AdminServicos() {
  const { logAction } = useAdmin();
  const [categories, setCategories] = useState<any[]>([]);
  const [services, setServices] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const [catDialog, setCatDialog] = useState(false);
  const [editCat, setEditCat] = useState<any>(null);
  const [catName, setCatName] = useState('');
  const [catDesc, setCatDesc] = useState('');

  const [svcDialog, setSvcDialog] = useState(false);
  const [editSvc, setEditSvc] = useState<any>(null);
  const [svcName, setSvcName] = useState('');
  const [svcDesc, setSvcDesc] = useState('');
  const [svcTag, setSvcTag] = useState('');
  const [svcCatId, setSvcCatId] = useState('');

  const fetchData = async () => {
    const [catsRes, svcsRes] = await Promise.all([
      supabase.from('service_categories').select('*').order('name'),
      supabase.from('services').select('*').order('name'),
    ]);
    setCategories(catsRes.data || []);
    setServices(svcsRes.data || []);
    setLoading(false);
  };

  useEffect(() => { fetchData(); }, []);

  const saveCategory = async () => {
    if (!catName.trim()) return;
    if (editCat) {
      await supabase.from('service_categories').update({ name: catName, description: catDesc }).eq('id', editCat.id);
      await logAction('update_category', 'service_category', editCat.id);
    } else {
      await supabase.from('service_categories').insert({ name: catName, description: catDesc });
      await logAction('create_category', 'service_category');
    }
    toast({ title: editCat ? 'Categoria atualizada' : 'Categoria criada' });
    setCatDialog(false);
    setEditCat(null);
    setCatName('');
    setCatDesc('');
    fetchData();
  };

  const toggleCategory = async (cat: any) => {
    await supabase.from('service_categories').update({ is_active: !cat.is_active }).eq('id', cat.id);
    await logAction(cat.is_active ? 'deactivate_category' : 'activate_category', 'service_category', cat.id);
    fetchData();
  };

  const saveService = async () => {
    if (!svcName.trim() || !svcCatId) return;
    if (editSvc) {
      await supabase.from('services').update({ name: svcName, description: svcDesc, tag_api: svcTag, category_id: svcCatId }).eq('id', editSvc.id);
      await logAction('update_service', 'service', editSvc.id);
    } else {
      await supabase.from('services').insert({ name: svcName, description: svcDesc, tag_api: svcTag, category_id: svcCatId });
      await logAction('create_service', 'service');
    }
    toast({ title: editSvc ? 'Serviço atualizado' : 'Serviço criado' });
    setSvcDialog(false);
    setEditSvc(null);
    setSvcName('');
    setSvcDesc('');
    setSvcTag('');
    setSvcCatId('');
    fetchData();
  };

  const toggleService = async (svc: any) => {
    await supabase.from('services').update({ is_active: !svc.is_active }).eq('id', svc.id);
    await logAction(svc.is_active ? 'deactivate_service' : 'activate_service', 'service', svc.id);
    fetchData();
  };

  const openEditCat = (cat: any) => { setEditCat(cat); setCatName(cat.name); setCatDesc(cat.description || ''); setCatDialog(true); };
  const openEditSvc = (svc: any) => { setEditSvc(svc); setSvcName(svc.name); setSvcDesc(svc.description || ''); setSvcTag(svc.tag_api || ''); setSvcCatId(svc.category_id || ''); setSvcDialog(true); };

  return (
    <AdminLayout requiredRole="operator">
      <div className="space-y-6">
        <h2 className="text-2xl font-bold">Serviços e Categorias</h2>

        <Tabs defaultValue="categories">
          <TabsList>
            <TabsTrigger value="categories">Categorias</TabsTrigger>
            <TabsTrigger value="services">Serviços</TabsTrigger>
          </TabsList>

          <TabsContent value="categories" className="space-y-4">
            <Button onClick={() => { setEditCat(null); setCatName(''); setCatDesc(''); setCatDialog(true); }}>
              <Plus className="h-4 w-4 mr-1" /> Nova Categoria
            </Button>
            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nome</TableHead>
                      <TableHead>Descrição</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {categories.map(c => (
                      <TableRow key={c.id}>
                        <TableCell className="font-medium">{c.name}</TableCell>
                        <TableCell className="text-muted-foreground">{c.description || '-'}</TableCell>
                        <TableCell><Badge variant={c.is_active ? 'default' : 'secondary'}>{c.is_active ? 'Ativa' : 'Inativa'}</Badge></TableCell>
                        <TableCell>
                          <div className="flex gap-1">
                            <Button size="icon" variant="ghost" onClick={() => openEditCat(c)}><Edit className="h-4 w-4" /></Button>
                            <Button size="icon" variant="ghost" onClick={() => toggleCategory(c)}>
                              {c.is_active ? <ToggleRight className="h-4 w-4 text-green-500" /> : <ToggleLeft className="h-4 w-4 text-muted-foreground" />}
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="services" className="space-y-4">
            <Button onClick={() => { setEditSvc(null); setSvcName(''); setSvcDesc(''); setSvcTag(''); setSvcCatId(''); setSvcDialog(true); }}>
              <Plus className="h-4 w-4 mr-1" /> Novo Serviço
            </Button>
            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nome</TableHead>
                      <TableHead>Categoria</TableHead>
                      <TableHead>TAG_API</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {services.map(s => (
                      <TableRow key={s.id}>
                        <TableCell className="font-medium">{s.name}</TableCell>
                        <TableCell>{categories.find(c => c.id === s.category_id)?.name || '-'}</TableCell>
                        <TableCell className="font-mono text-xs">{s.tag_api || '-'}</TableCell>
                        <TableCell><Badge variant={s.is_active ? 'default' : 'secondary'}>{s.is_active ? 'Ativo' : 'Inativo'}</Badge></TableCell>
                        <TableCell>
                          <div className="flex gap-1">
                            <Button size="icon" variant="ghost" onClick={() => openEditSvc(s)}><Edit className="h-4 w-4" /></Button>
                            <Button size="icon" variant="ghost" onClick={() => toggleService(s)}>
                              {s.is_active ? <ToggleRight className="h-4 w-4 text-green-500" /> : <ToggleLeft className="h-4 w-4 text-muted-foreground" />}
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <Dialog open={catDialog} onOpenChange={setCatDialog}>
          <DialogContent>
            <DialogHeader><DialogTitle>{editCat ? 'Editar' : 'Nova'} Categoria</DialogTitle></DialogHeader>
            <Input placeholder="Nome" value={catName} onChange={e => setCatName(e.target.value)} />
            <Textarea placeholder="Descrição (opcional)" value={catDesc} onChange={e => setCatDesc(e.target.value)} />
            <DialogFooter>
              <Button variant="outline" onClick={() => setCatDialog(false)}>Cancelar</Button>
              <Button onClick={saveCategory} disabled={!catName.trim()}>Salvar</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        <Dialog open={svcDialog} onOpenChange={setSvcDialog}>
          <DialogContent>
            <DialogHeader><DialogTitle>{editSvc ? 'Editar' : 'Novo'} Serviço</DialogTitle></DialogHeader>
            <Input placeholder="Nome" value={svcName} onChange={e => setSvcName(e.target.value)} />
            <Textarea placeholder="Descrição" value={svcDesc} onChange={e => setSvcDesc(e.target.value)} />
            <Input placeholder="TAG_API" value={svcTag} onChange={e => setSvcTag(e.target.value)} />
            <Select value={svcCatId} onValueChange={setSvcCatId}>
              <SelectTrigger><SelectValue placeholder="Categoria" /></SelectTrigger>
              <SelectContent>
                {categories.filter(c => c.is_active).map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
              </SelectContent>
            </Select>
            <DialogFooter>
              <Button variant="outline" onClick={() => setSvcDialog(false)}>Cancelar</Button>
              <Button onClick={saveService} disabled={!svcName.trim() || !svcCatId}>Salvar</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </AdminLayout>
  );
}
