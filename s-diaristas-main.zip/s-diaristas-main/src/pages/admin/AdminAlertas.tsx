import { useEffect, useState } from 'react';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { useAdmin } from '@/hooks/useAdmin';
import { toast } from '@/hooks/use-toast';
import { CheckCircle, AlertTriangle, Info, XCircle } from 'lucide-react';

export default function AdminAlertas() {
  const { logAction } = useAdmin();
  const [alerts, setAlerts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    const { data } = await supabase.from('admin_alerts').select('*').order('created_at', { ascending: false }).limit(100);
    setAlerts(data || []);
    setLoading(false);
  };

  useEffect(() => { fetchData(); }, []);

  const resolveAlert = async (alertId: string) => {
    await supabase.from('admin_alerts').update({ is_resolved: true, resolved_at: new Date().toISOString() }).eq('id', alertId);
    await logAction('resolve_alert', 'admin_alert', alertId);
    toast({ title: 'Alerta resolvido' });
    fetchData();
  };

  const severityIcon = (s: string) => {
    if (s === 'critical') return <XCircle className="h-5 w-5 text-red-500" />;
    if (s === 'warning') return <AlertTriangle className="h-5 w-5 text-orange-500" />;
    return <Info className="h-5 w-5 text-blue-500" />;
  };

  const severityVariant = (s: string): any => {
    if (s === 'critical') return 'destructive';
    if (s === 'warning') return 'secondary';
    return 'outline';
  };

  const pending = alerts.filter(a => !a.is_resolved);
  const resolved = alerts.filter(a => a.is_resolved);

  return (
    <AdminLayout>
      <div className="space-y-6">
        <h2 className="text-2xl font-bold">Alertas Internos</h2>

        <Card>
          <CardHeader><CardTitle>Pendentes ({pending.length})</CardTitle></CardHeader>
          <CardContent>
            {pending.length === 0 ? <p className="text-sm text-muted-foreground">Nenhum alerta pendente 🎉</p> : (
              <div className="space-y-3">
                {pending.map(a => (
                  <div key={a.id} className="flex items-start justify-between p-4 border rounded-lg">
                    <div className="flex items-start gap-3">
                      {severityIcon(a.severity)}
                      <div>
                        <div className="flex items-center gap-2">
                          <Badge variant={severityVariant(a.severity)}>{a.alert_type}</Badge>
                          <span className="font-medium text-sm">{a.title}</span>
                        </div>
                        <p className="text-sm text-muted-foreground mt-1">{a.message}</p>
                        <p className="text-xs text-muted-foreground mt-1">{new Date(a.created_at).toLocaleString('pt-BR')}</p>
                      </div>
                    </div>
                    <Button size="sm" variant="outline" onClick={() => resolveAlert(a.id)}>
                      <CheckCircle className="h-4 w-4 mr-1" /> Resolver
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {resolved.length > 0 && (
          <Card>
            <CardHeader><CardTitle>Resolvidos ({resolved.length})</CardTitle></CardHeader>
            <CardContent>
              <div className="space-y-2">
                {resolved.slice(0, 20).map(a => (
                  <div key={a.id} className="flex items-center gap-3 p-3 border rounded-lg opacity-60">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <div>
                      <span className="text-sm">{a.title}</span>
                      <span className="text-xs text-muted-foreground ml-2">{new Date(a.created_at).toLocaleDateString('pt-BR')}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </AdminLayout>
  );
}
