import { useEffect, useState } from 'react';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { supabase } from '@/integrations/supabase/client';
import { useAdmin } from '@/hooks/useAdmin';
import { useAuth } from '@/hooks/useAuth';
import { toast } from '@/hooks/use-toast';
import { Plus, FileText, Shield, Clock } from 'lucide-react';

export default function AdminSeguranca() {
  const { logAction, isSuperAdmin } = useAdmin();
  const { user } = useAuth();
  const [contracts, setContracts] = useState<any[]>([]);
  const [logs, setLogs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [contractDialog, setContractDialog] = useState(false);
  const [contractVersion, setContractVersion] = useState('');
  const [contractContent, setContractContent] = useState('');

  const fetchData = async () => {
    const [contractsRes, logsRes] = await Promise.all([
      supabase.from('contract_versions').select('*').order('created_at', { ascending: false }),
      supabase.from('admin_logs').select('*').order('created_at', { ascending: false }).limit(100),
    ]);
    setContracts(contractsRes.data || []);
    setLogs(logsRes.data || []);
    setLoading(false);
  };

  useEffect(() => { fetchData(); }, []);

  const createContract = async () => {
    if (!contractVersion.trim() || !contractContent.trim()) return;
    // Desativar contratos anteriores
    await supabase.from('contract_versions').update({ is_current: false }).eq('is_current', true);
    await supabase.from('contract_versions').insert({
      version: contractVersion,
      content: contractContent,
      is_current: true,
      created_by: user?.id,
    });
    await logAction('create_contract', 'contract_version');
    toast({ title: 'Novo contrato publicado' });
    setContractDialog(false);
    setContractVersion('');
    setContractContent('');
    fetchData();
  };

  const forceNewAcceptance = async (contractId: string) => {
    await supabase.from('contract_versions').update({ force_new_acceptance: true }).eq('id', contractId);
    await logAction('force_contract_acceptance', 'contract_version', contractId);
    toast({ title: 'Novo aceite forçado para todos' });
    fetchData();
  };

  const actionLabels: Record<string, string> = {
    approve_document: 'Aprovou documento',
    reject_document: 'Rejeitou documento',
    approve_all_documents: 'Aprovou todos docs',
    account_suspended: 'Suspendeu conta',
    account_active: 'Reativou conta',
    account_blocked: 'Bloqueou conta',
    client_blocked: 'Bloqueou cliente',
    client_active: 'Desbloqueou cliente',
    add_client_note: 'Adicionou nota',
    booking_completed: 'Concluiu agendamento',
    booking_cancelled: 'Cancelou agendamento',
    create_category: 'Criou categoria',
    update_category: 'Atualizou categoria',
    create_service: 'Criou serviço',
    update_service: 'Atualizou serviço',
    create_contract: 'Publicou contrato',
    force_contract_acceptance: 'Forçou novo aceite',
    create_city: 'Criou cidade',
    update_city: 'Atualizou cidade',
    toggle_city: 'Alterou status cidade',
  };

  return (
    <AdminLayout requiredRole="super_admin">
      <div className="space-y-6">
        <h2 className="text-2xl font-bold">Segurança e Jurídico</h2>

        <Tabs defaultValue="contracts">
          <TabsList>
            <TabsTrigger value="contracts"><FileText className="h-4 w-4 mr-1" /> Contratos</TabsTrigger>
            <TabsTrigger value="logs"><Clock className="h-4 w-4 mr-1" /> Logs</TabsTrigger>
          </TabsList>

          <TabsContent value="contracts" className="space-y-4">
            {isSuperAdmin && (
              <Button onClick={() => setContractDialog(true)}>
                <Plus className="h-4 w-4 mr-1" /> Nova Versão
              </Button>
            )}
            <div className="space-y-4">
              {contracts.map(c => (
                <Card key={c.id}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg flex items-center gap-2">
                        Versão {c.version}
                        {c.is_current && <Badge>Atual</Badge>}
                        {c.force_new_acceptance && <Badge variant="destructive">Reaceite Obrigatório</Badge>}
                      </CardTitle>
                      {isSuperAdmin && c.is_current && !c.force_new_acceptance && (
                        <Button size="sm" variant="outline" onClick={() => forceNewAcceptance(c.id)}>
                          <Shield className="h-4 w-4 mr-1" /> Forçar Novo Aceite
                        </Button>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <pre className="whitespace-pre-wrap text-sm text-muted-foreground max-h-40 overflow-y-auto">{c.content}</pre>
                    <p className="text-xs text-muted-foreground mt-2">Criado em {new Date(c.created_at).toLocaleString('pt-BR')}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="logs">
            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Ação</TableHead>
                      <TableHead>Tipo</TableHead>
                      <TableHead>Detalhes</TableHead>
                      <TableHead>Data</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {logs.map(l => (
                      <TableRow key={l.id}>
                        <TableCell className="font-medium">{actionLabels[l.action] || l.action}</TableCell>
                        <TableCell><Badge variant="outline">{l.target_type || '-'}</Badge></TableCell>
                        <TableCell className="text-xs max-w-[200px] truncate">{l.details ? JSON.stringify(l.details) : '-'}</TableCell>
                        <TableCell className="text-xs">{new Date(l.created_at).toLocaleString('pt-BR')}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <Dialog open={contractDialog} onOpenChange={setContractDialog}>
          <DialogContent className="max-w-2xl">
            <DialogHeader><DialogTitle>Nova Versão do Contrato</DialogTitle></DialogHeader>
            <Input placeholder="Versão (ex: 2.0)" value={contractVersion} onChange={e => setContractVersion(e.target.value)} />
            <Textarea placeholder="Conteúdo completo do contrato..." value={contractContent} onChange={e => setContractContent(e.target.value)} rows={15} />
            <DialogFooter>
              <Button variant="outline" onClick={() => setContractDialog(false)}>Cancelar</Button>
              <Button onClick={createContract} disabled={!contractVersion.trim() || !contractContent.trim()}>Publicar</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </AdminLayout>
  );
}
