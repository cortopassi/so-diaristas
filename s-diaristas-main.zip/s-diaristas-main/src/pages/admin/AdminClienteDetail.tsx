import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { supabase } from '@/integrations/supabase/client';
import { useAdmin } from '@/hooks/useAdmin';
import { toast } from '@/hooks/use-toast';
import { ArrowLeft, AlertTriangle, Lock, Unlock, MessageSquare, Star } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useAuth } from '@/hooks/useAuth';

export default function AdminClienteDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { logAction, isOperator } = useAdmin();
  const { user } = useAuth();
  const [profile, setProfile] = useState<any>(null);
  const [bookings, setBookings] = useState<any[]>([]);
  const [reviews, setReviews] = useState<any[]>([]);
  const [notes, setNotes] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [noteDialog, setNoteDialog] = useState(false);
  const [noteContent, setNoteContent] = useState('');
  const [noteType, setNoteType] = useState('observation');

  const fetchData = async () => {
    if (!id) return;
    const [profileRes, notesRes] = await Promise.all([
      supabase.from('profiles').select('*').eq('id', id).single(),
      supabase.from('client_notes').select('*').eq('client_profile_id', id).order('created_at', { ascending: false }),
    ]);
    
    const p = profileRes.data;
    setProfile(p);
    setNotes(notesRes.data || []);

    if (p) {
      const [bookingsRes, reviewsRes] = await Promise.all([
        supabase.from('bookings').select('*').eq('client_id', p.user_id).order('created_at', { ascending: false }).limit(20),
        supabase.from('reviews').select('*').eq('client_id', p.user_id).order('created_at', { ascending: false }),
      ]);
      setBookings(bookingsRes.data || []);
      setReviews(reviewsRes.data || []);
    }
    setLoading(false);
  };

  useEffect(() => { fetchData(); }, [id]);

  const updateAccountStatus = async (status: string) => {
    await supabase.from('profiles').update({ account_status: status } as any).eq('id', id);
    await logAction(`client_${status}`, 'profile', id);
    toast({ title: `Cliente ${status === 'active' ? 'desbloqueado' : 'bloqueado'}` });
    fetchData();
  };

  const addNote = async () => {
    if (!noteContent.trim() || !user) return;
    await supabase.from('client_notes').insert({
      client_profile_id: id,
      admin_user_id: user.id,
      note_type: noteType,
      content: noteContent,
    });
    await logAction('add_client_note', 'profile', id, { type: noteType });
    toast({ title: 'Observação registrada' });
    setNoteDialog(false);
    setNoteContent('');
    fetchData();
  };

  if (loading) return <AdminLayout><p>Carregando...</p></AdminLayout>;
  if (!profile) return <AdminLayout><p>Cliente não encontrado</p></AdminLayout>;

  return (
    <AdminLayout>
      <div className="space-y-6">
        <Button variant="ghost" onClick={() => navigate('/admin/clientes')}>
          <ArrowLeft className="h-4 w-4 mr-2" /> Voltar
        </Button>

        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold">{profile.full_name}</h2>
          <div className="flex gap-2">
            <Button size="sm" variant="outline" onClick={() => setNoteDialog(true)}>
              <MessageSquare className="h-4 w-4 mr-1" /> Observação
            </Button>
            {isOperator && profile.account_status === 'active' && (
              <Button size="sm" variant="destructive" onClick={() => updateAccountStatus('blocked')}>
                <Lock className="h-4 w-4 mr-1" /> Bloquear
              </Button>
            )}
            {isOperator && profile.account_status !== 'active' && (
              <Button size="sm" variant="outline" onClick={() => updateAccountStatus('active')}>
                <Unlock className="h-4 w-4 mr-1" /> Desbloquear
              </Button>
            )}
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <Card>
            <CardHeader><CardTitle>Dados</CardTitle></CardHeader>
            <CardContent className="space-y-2 text-sm">
              <p><strong>Telefone:</strong> {profile.phone || '-'}</p>
              <p><strong>Cidade:</strong> {profile.city || '-'}</p>
              <p><strong>Contrato aceito:</strong> {profile.terms_accepted_at ? `Sim - ${new Date(profile.terms_accepted_at).toLocaleString('pt-BR')}` : 'Não'}</p>
              <p><strong>Cadastro:</strong> {new Date(profile.created_at).toLocaleString('pt-BR')}</p>
              <p><strong>Status:</strong> <Badge variant={profile.account_status === 'active' ? 'outline' : 'destructive'}>{profile.account_status}</Badge></p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle>Observações ({notes.length})</CardTitle></CardHeader>
            <CardContent>
              {notes.length === 0 ? <p className="text-sm text-muted-foreground">Nenhuma observação</p> : (
                <div className="space-y-2 max-h-60 overflow-y-auto">
                  {notes.map(n => (
                    <div key={n.id} className="p-2 border rounded text-sm">
                      <div className="flex items-center gap-2 mb-1">
                        <Badge variant={n.note_type === 'warning' ? 'destructive' : 'outline'}>
                          {n.note_type === 'warning' ? 'Advertência' : n.note_type === 'block_reason' ? 'Bloqueio' : 'Observação'}
                        </Badge>
                        <span className="text-xs text-muted-foreground">{new Date(n.created_at).toLocaleString('pt-BR')}</span>
                      </div>
                      <p>{n.content}</p>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader><CardTitle>Contratações ({bookings.length})</CardTitle></CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Serviço</TableHead>
                  <TableHead>Data</TableHead>
                  <TableHead>Valor</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {bookings.map(b => (
                  <TableRow key={b.id}>
                    <TableCell>{b.service_type}</TableCell>
                    <TableCell>{new Date(b.scheduled_date).toLocaleDateString('pt-BR')}</TableCell>
                    <TableCell>R$ {Number(b.total_amount).toFixed(2)}</TableCell>
                    <TableCell><Badge variant="outline">{b.status}</Badge></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Avaliações Feitas ({reviews.length})</CardTitle></CardHeader>
          <CardContent>
            {reviews.length === 0 ? <p className="text-sm text-muted-foreground">Nenhuma avaliação</p> : (
              <div className="space-y-2">
                {reviews.map(r => (
                  <div key={r.id} className="p-3 border rounded">
                    <div className="flex items-center gap-2">
                      {Array.from({ length: 5 }).map((_, i) => <Star key={i} className={`h-3 w-3 ${i < r.rating ? 'fill-yellow-400 text-yellow-400' : 'text-muted'}`} />)}
                      <span className="text-xs text-muted-foreground">{new Date(r.created_at).toLocaleDateString('pt-BR')}</span>
                    </div>
                    {r.comment && <p className="text-sm mt-1">{r.comment}</p>}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Dialog open={noteDialog} onOpenChange={setNoteDialog}>
          <DialogContent>
            <DialogHeader><DialogTitle>Registrar Observação</DialogTitle></DialogHeader>
            <Select value={noteType} onValueChange={setNoteType}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="observation">Observação</SelectItem>
                <SelectItem value="warning">Advertência</SelectItem>
                <SelectItem value="block_reason">Motivo Bloqueio</SelectItem>
              </SelectContent>
            </Select>
            <Textarea placeholder="Descreva..." value={noteContent} onChange={e => setNoteContent(e.target.value)} />
            <DialogFooter>
              <Button variant="outline" onClick={() => setNoteDialog(false)}>Cancelar</Button>
              <Button onClick={addNote} disabled={!noteContent.trim()}>Salvar</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </AdminLayout>
  );
}
