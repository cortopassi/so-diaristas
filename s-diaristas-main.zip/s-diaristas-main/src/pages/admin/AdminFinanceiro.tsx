import { useEffect, useState } from 'react';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { supabase } from '@/integrations/supabase/client';
import { DollarSign, Download, TrendingUp } from 'lucide-react';
import { format, startOfMonth, endOfMonth, subMonths } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function AdminFinanceiro() {
  const [bookings, setBookings] = useState<any[]>([]);
  const [profiles, setProfiles] = useState<Record<string, any>>({});
  const [loading, setLoading] = useState(true);
  const [selectedMonth, setSelectedMonth] = useState(format(new Date(), 'yyyy-MM'));
  const [filterCity, setFilterCity] = useState('all');

  useEffect(() => {
    const fetch = async () => {
      const monthDate = new Date(selectedMonth + '-01');
      const start = format(startOfMonth(monthDate), 'yyyy-MM-dd');
      const end = format(endOfMonth(monthDate), 'yyyy-MM-dd');

      const [bookingsRes, profilesRes] = await Promise.all([
        supabase.from('bookings').select('*').gte('scheduled_date', start).lte('scheduled_date', end).eq('status', 'completed'),
        supabase.from('profiles').select('id, user_id, full_name, city').eq('role', 'professional'),
      ]);

      const profMap: Record<string, any> = {};
      (profilesRes.data || []).forEach((p: any) => { profMap[p.id] = p; });
      setProfiles(profMap);
      setBookings(bookingsRes.data || []);
      setLoading(false);
    };
    fetch();
  }, [selectedMonth]);

  const cities = [...new Set(Object.values(profiles).map(p => p.city).filter(Boolean))];
  const filteredBookings = filterCity === 'all' ? bookings : bookings.filter(b => profiles[b.professional_id]?.city === filterCity);

  const totalRevenue = filteredBookings.reduce((s, b) => s + Number(b.total_amount), 0);
  const totalCommission = totalRevenue * 0.2;
  const totalPayout = totalRevenue * 0.8;

  const cityStats = cities.map(city => {
    const cityBookings = bookings.filter(b => profiles[b.professional_id]?.city === city);
    const revenue = cityBookings.reduce((s, b) => s + Number(b.total_amount), 0);
    return { city, count: cityBookings.length, revenue };
  }).sort((a, b) => b.revenue - a.revenue);

  const months = Array.from({ length: 12 }, (_, i) => {
    const d = subMonths(new Date(), i);
    return { value: format(d, 'yyyy-MM'), label: format(d, 'MMMM yyyy', { locale: ptBR }) };
  });

  const exportCSV = () => {
    const rows = [['Serviço', 'Data', 'Profissional', 'Cidade', 'Valor Bruto', 'Comissão', 'Repasse']];
    filteredBookings.forEach(b => {
      rows.push([
        b.service_type,
        new Date(b.scheduled_date).toLocaleDateString('pt-BR'),
        profiles[b.professional_id]?.full_name || '-',
        profiles[b.professional_id]?.city || '-',
        Number(b.total_amount).toFixed(2),
        (Number(b.total_amount) * 0.2).toFixed(2),
        (Number(b.total_amount) * 0.8).toFixed(2),
      ]);
    });
    const csv = rows.map(r => r.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `financeiro-${selectedMonth}.csv`;
    a.click();
  };

  return (
    <AdminLayout requiredRole="financial">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold">Financeiro</h2>
          <Button variant="outline" onClick={exportCSV}><Download className="h-4 w-4 mr-1" /> Exportar CSV</Button>
        </div>

        <div className="flex gap-3">
          <Select value={selectedMonth} onValueChange={setSelectedMonth}>
            <SelectTrigger className="w-[200px]"><SelectValue /></SelectTrigger>
            <SelectContent>{months.map(m => <SelectItem key={m.value} value={m.value}>{m.label}</SelectItem>)}</SelectContent>
          </Select>
          <Select value={filterCity} onValueChange={setFilterCity}>
            <SelectTrigger className="w-[180px]"><SelectValue placeholder="Cidade" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas</SelectItem>
              {cities.map(c => <SelectItem key={c} value={c!}>{c}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>

        <div className="grid md:grid-cols-3 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm">Faturamento Bruto</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent><p className="text-2xl font-bold">R$ {totalRevenue.toFixed(2)}</p></CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm">Comissão Plataforma</CardTitle>
              <TrendingUp className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent><p className="text-2xl font-bold text-primary">R$ {totalCommission.toFixed(2)}</p></CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm">Repasse Profissionais</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent><p className="text-2xl font-bold">R$ {totalPayout.toFixed(2)}</p></CardContent>
          </Card>
        </div>

        {cityStats.length > 0 && (
          <Card>
            <CardHeader><CardTitle>Por Cidade</CardTitle></CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Cidade</TableHead>
                    <TableHead>Serviços</TableHead>
                    <TableHead>Faturamento</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {cityStats.map(c => (
                    <TableRow key={c.city}>
                      <TableCell className="font-medium">{c.city}</TableCell>
                      <TableCell>{c.count}</TableCell>
                      <TableCell>R$ {c.revenue.toFixed(2)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}
      </div>
    </AdminLayout>
  );
}
