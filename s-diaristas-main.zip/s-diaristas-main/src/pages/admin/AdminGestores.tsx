import { useState, useEffect } from 'react';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { useAdmin } from '@/hooks/useAdmin';
import { Plus, Trash2, Shield, Loader2 } from 'lucide-react';

type AdminRole = 'super_admin' | 'operator' | 'financial' | 'support';

interface GestorRow {
  id: string;
  user_id: string;
  role: AdminRole;
  created_at: string;
  email?: string;
  full_name?: string;
}

const roleLabels: Record<AdminRole, string> = {
  super_admin: 'Super Admin',
  operator: 'Operador',
  financial: 'Financeiro',
  support: 'Suporte',
};

const roleBadgeVariant: Record<AdminRole, 'default' | 'secondary' | 'outline' | 'destructive'> = {
  super_admin: 'destructive',
  operator: 'default',
  financial: 'secondary',
  support: 'outline',
};

export default function AdminGestores() {
  const { logAction } = useAdmin();
  const [gestores, setGestores] = useState<GestorRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [email, setEmail] = useState('');
  const [selectedRole, setSelectedRole] = useState<AdminRole>('operator');
  const [saving, setSaving] = useState(false);

  const fetchGestores = async () => {
    setLoading(true);
    const { data: roles, error } = await supabase
      .from('user_roles')
      .select('id, user_id, role, created_at')
      .order('created_at', { ascending: false });

    if (error) {
      toast.error('Erro ao carregar gestores');
      setLoading(false);
      return;
    }

    // Fetch profiles for each user
    const userIds = (roles || []).map(r => r.user_id);
    const { data: profiles } = await supabase
      .from('profiles')
      .select('user_id, full_name')
      .in('user_id', userIds);

    const profileMap = new Map((profiles || []).map(p => [p.user_id, p.full_name]));

    const gestorList: GestorRow[] = (roles || []).map(r => ({
      ...r,
      role: r.role as AdminRole,
      full_name: profileMap.get(r.user_id) || 'Sem perfil',
    }));

    setGestores(gestorList);
    setLoading(false);
  };

  useEffect(() => {
    fetchGestores();
  }, []);

  const handleAdd = async () => {
    if (!email.trim()) {
      toast.error('Informe o email do usuário');
      return;
    }

    setSaving(true);

    // Find user by email via profiles or auth — we'll search profiles
    const { data: authUsers } = await supabase
      .from('profiles')
      .select('user_id, full_name')
      .ilike('full_name', `%${email.trim()}%`);

    // Actually, let's search by the auth user email. Since we can't query auth.users from client,
    // we'll need to look up by user_id. Let's ask for the email in profiles or try a different approach.
    // For now, let's search by exact email match using a workaround: the user must exist in profiles.
    
    // Better approach: search by email using supabase rpc or direct approach
    // Since we can't query auth.users from client, let's add the role by user_id lookup
    // We'll search profiles by full_name or let admin input user_id directly
    
    // Let's try to find the user via a different column. Actually, profiles don't store email.
    // We need to look up via auth. Let's use a simple approach — search by name in profiles.

    const { data: matchedProfiles } = await supabase
      .from('profiles')
      .select('user_id, full_name')
      .or(`full_name.ilike.%${email.trim()}%`);

    if (!matchedProfiles || matchedProfiles.length === 0) {
      toast.error('Nenhum usuário encontrado com esse nome. O usuário precisa estar cadastrado na plataforma.');
      setSaving(false);
      return;
    }

    if (matchedProfiles.length > 1) {
      toast.error(`Encontrados ${matchedProfiles.length} usuários. Seja mais específico no nome.`);
      setSaving(false);
      return;
    }

    const targetUser = matchedProfiles[0];

    // Check if role already exists
    const { data: existing } = await supabase
      .from('user_roles')
      .select('id')
      .eq('user_id', targetUser.user_id)
      .eq('role', selectedRole);

    if (existing && existing.length > 0) {
      toast.error(`${targetUser.full_name} já possui a role ${roleLabels[selectedRole]}`);
      setSaving(false);
      return;
    }

    const { error } = await supabase
      .from('user_roles')
      .insert({ user_id: targetUser.user_id, role: selectedRole });

    if (error) {
      toast.error('Erro ao adicionar gestor: ' + error.message);
      setSaving(false);
      return;
    }

    await logAction('add_admin_role', 'user', targetUser.user_id, { role: selectedRole, name: targetUser.full_name });
    toast.success(`${targetUser.full_name} adicionado como ${roleLabels[selectedRole]}`);
    setEmail('');
    setDialogOpen(false);
    setSaving(false);
    fetchGestores();
  };

  const handleRemove = async (gestor: GestorRow) => {
    if (!confirm(`Remover role ${roleLabels[gestor.role]} de ${gestor.full_name}?`)) return;

    const { error } = await supabase
      .from('user_roles')
      .delete()
      .eq('id', gestor.id);

    if (error) {
      toast.error('Erro ao remover: ' + error.message);
      return;
    }

    await logAction('remove_admin_role', 'user', gestor.user_id, { role: gestor.role, name: gestor.full_name });
    toast.success('Role removida com sucesso');
    fetchGestores();
  };

  return (
    <AdminLayout requiredRole="super_admin">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold">Gestores</h2>
            <p className="text-muted-foreground">Gerencie os administradores da plataforma</p>
          </div>
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Adicionar Gestor
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Adicionar Novo Gestor</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 pt-4">
                <div className="space-y-2">
                  <Label>Nome do usuário (cadastrado na plataforma)</Label>
                  <Input
                    placeholder="Nome completo do usuário"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Nível de acesso</Label>
                  <Select value={selectedRole} onValueChange={v => setSelectedRole(v as AdminRole)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="super_admin">Super Admin — Acesso total</SelectItem>
                      <SelectItem value="operator">Operador — Aprova documentos e serviços</SelectItem>
                      <SelectItem value="financial">Financeiro — Visualiza financeiro</SelectItem>
                      <SelectItem value="support">Suporte — Visualiza dados sem alterar</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button onClick={handleAdd} disabled={saving} className="w-full">
                  {saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                  Adicionar
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5" />
              Gestores Ativos
            </CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
              </div>
            ) : gestores.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">Nenhum gestor cadastrado</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nome</TableHead>
                    <TableHead>Nível</TableHead>
                    <TableHead>Desde</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {gestores.map(g => (
                    <TableRow key={g.id}>
                      <TableCell className="font-medium">{g.full_name}</TableCell>
                      <TableCell>
                        <Badge variant={roleBadgeVariant[g.role]}>
                          {roleLabels[g.role]}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {new Date(g.created_at).toLocaleDateString('pt-BR')}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleRemove(g)}
                          className="text-destructive hover:text-destructive"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
