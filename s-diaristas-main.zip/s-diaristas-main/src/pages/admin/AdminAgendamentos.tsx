import { useEffect, useState } from 'react';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { supabase } from '@/integrations/supabase/client';
import { useAdmin } from '@/hooks/useAdmin';
import { toast } from '@/hooks/use-toast';
import { Search, Eye, CheckCircle, XCircle } from 'lucide-react';

export default function AdminAgendamentos() {
  const { logAction, isOperator } = useAdmin();
  const [bookings, setBookings] = useState<any[]>([]);
  const [profiles, setProfiles] = useState<Record<string, any>>({});
  const [loading, setLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterCity, setFilterCity] = useState('all');
  const [search, setSearch] = useState('');
  const [detail, setDetail] = useState<any>(null);

  const fetchData = async () => {
    const [bookingsRes, profilesRes, paymentsRes] = await Promise.all([
      supabase.from('bookings').select('*').order('created_at', { ascending: false }).limit(200),
      supabase.from('profiles').select('id, user_id, full_name, city'),
      supabase.from('payments').select('*'),
    ]);

    const profMap: Record<string, any> = {};
    (profilesRes.data || []).forEach((p: any) => { profMap[p.id] = p; profMap[p.user_id] = p; });
    setProfiles(profMap);

    const bks = (bookingsRes.data || []).map((b: any) => ({
      ...b,
      clientName: profMap[b.client_id]?.full_name || '-',
      professionalName: profMap[b.professional_id]?.full_name || '-',
      city: profMap[b.professional_id]?.city || '-',
      payment: (paymentsRes.data || []).find((p: any) => p.booking_id === b.id),
    }));
    setBookings(bks);
    setLoading(false);
  };

  useEffect(() => { fetchData(); }, []);

  const cities = [...new Set(bookings.map(b => b.city).filter(Boolean))];

  const filtered = bookings.filter(b => {
    if (filterStatus !== 'all' && b.status !== filterStatus) return false;
    if (filterCity !== 'all' && b.city !== filterCity) return false;
    if (search && !b.clientName.toLowerCase().includes(search.toLowerCase()) && !b.professionalName.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const updateStatus = async (bookingId: string, status: 'pending' | 'confirmed' | 'completed' | 'cancelled') => {
    await supabase.from('bookings').update({ status }).eq('id', bookingId);
    await logAction(`booking_${status}`, 'booking', bookingId);
    toast({ title: `Agendamento ${status === 'completed' ? 'concluído' : 'cancelado'}` });
    setDetail(null);
    fetchData();
  };

  const statusColors: Record<string, string> = {
    pending: 'secondary', confirmed: 'default', completed: 'outline', cancelled: 'destructive',
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <h2 className="text-2xl font-bold">Agendamentos</h2>

        <div className="flex flex-wrap gap-3">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Buscar cliente ou profissional..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
          </div>
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-[150px]"><SelectValue placeholder="Status" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos</SelectItem>
              <SelectItem value="pending">Pendente</SelectItem>
              <SelectItem value="confirmed">Confirmado</SelectItem>
              <SelectItem value="completed">Concluído</SelectItem>
              <SelectItem value="cancelled">Cancelado</SelectItem>
            </SelectContent>
          </Select>
          <Select value={filterCity} onValueChange={setFilterCity}>
            <SelectTrigger className="w-[150px]"><SelectValue placeholder="Cidade" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas</SelectItem>
              {cities.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>

        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Cliente</TableHead>
                  <TableHead>Profissional</TableHead>
                  <TableHead>Cidade</TableHead>
                  <TableHead>Serviço</TableHead>
                  <TableHead>Data</TableHead>
                  <TableHead>Valor</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow><TableCell colSpan={8} className="text-center py-8">Carregando...</TableCell></TableRow>
                ) : filtered.map(b => (
                  <TableRow key={b.id}>
                    <TableCell>{b.clientName}</TableCell>
                    <TableCell>{b.professionalName}</TableCell>
                    <TableCell>{b.city}</TableCell>
                    <TableCell>{b.service_type}</TableCell>
                    <TableCell>{new Date(b.scheduled_date).toLocaleDateString('pt-BR')}</TableCell>
                    <TableCell>R$ {Number(b.total_amount).toFixed(2)}</TableCell>
                    <TableCell><Badge variant={statusColors[b.status] as any}>{b.status}</Badge></TableCell>
                    <TableCell>
                      <Button size="sm" variant="ghost" onClick={() => setDetail(b)}><Eye className="h-4 w-4" /></Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Dialog open={!!detail} onOpenChange={() => setDetail(null)}>
          {detail && (
            <DialogContent className="max-w-lg">
              <DialogHeader><DialogTitle>Detalhes do Agendamento</DialogTitle></DialogHeader>
              <div className="space-y-3 text-sm">
                <p><strong>Cliente:</strong> {detail.clientName}</p>
                <p><strong>Profissional:</strong> {detail.professionalName}</p>
                <p><strong>Serviço:</strong> {detail.service_type}</p>
                <p><strong>Data:</strong> {new Date(detail.scheduled_date).toLocaleDateString('pt-BR')} às {detail.scheduled_time}</p>
                <p><strong>Endereço:</strong> {detail.address}</p>
                <p><strong>Horas:</strong> {detail.hours}</p>
                <p><strong>Valor Bruto:</strong> R$ {Number(detail.total_amount).toFixed(2)}</p>
                <p><strong>Comissão (20%):</strong> R$ {(Number(detail.total_amount) * 0.2).toFixed(2)}</p>
                <p><strong>Valor Líquido:</strong> R$ {(Number(detail.total_amount) * 0.8).toFixed(2)}</p>
                <p><strong>Status:</strong> <Badge variant={statusColors[detail.status] as any}>{detail.status}</Badge></p>
                <p><strong>Pagamento:</strong> {detail.payment ? <Badge variant="outline">{detail.payment.status}</Badge> : 'N/A'}</p>
                {detail.notes && <p><strong>Observações:</strong> {detail.notes}</p>}
              </div>
              {isOperator && (detail.status === 'pending' || detail.status === 'confirmed') && (
                <DialogFooter>
                  <Button variant="outline" onClick={() => updateStatus(detail.id, 'completed')}>
                    <CheckCircle className="h-4 w-4 mr-1" /> Concluir
                  </Button>
                  <Button variant="destructive" onClick={() => updateStatus(detail.id, 'cancelled')}>
                    <XCircle className="h-4 w-4 mr-1" /> Cancelar
                  </Button>
                </DialogFooter>
              )}
            </DialogContent>
          )}
        </Dialog>
      </div>
    </AdminLayout>
  );
}
