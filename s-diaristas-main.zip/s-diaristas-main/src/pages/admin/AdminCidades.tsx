import { useEffect, useState } from 'react';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { supabase } from '@/integrations/supabase/client';
import { useAdmin } from '@/hooks/useAdmin';
import { toast } from '@/hooks/use-toast';
import { Plus, Edit, ToggleLeft, ToggleRight, MapPin } from 'lucide-react';

export default function AdminCidades() {
  const { logAction } = useAdmin();
  const [cities, setCities] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialog, setDialog] = useState(false);
  const [editCity, setEditCity] = useState<any>(null);
  const [name, setName] = useState('');
  const [state, setState] = useState('');

  const fetchData = async () => {
    const { data } = await supabase.from('cities').select('*').order('state').order('name');
    setCities(data || []);
    setLoading(false);
  };

  useEffect(() => { fetchData(); }, []);

  const saveCity = async () => {
    if (!name.trim() || !state.trim()) return;
    if (editCity) {
      await supabase.from('cities').update({ name, state }).eq('id', editCity.id);
      await logAction('update_city', 'city', editCity.id);
    } else {
      await supabase.from('cities').insert({ name, state });
      await logAction('create_city', 'city');
    }
    toast({ title: editCity ? 'Cidade atualizada' : 'Cidade criada' });
    setDialog(false);
    setEditCity(null);
    setName('');
    setState('');
    fetchData();
  };

  const toggleCity = async (city: any) => {
    await supabase.from('cities').update({ is_active: !city.is_active }).eq('id', city.id);
    await logAction('toggle_city', 'city', city.id, { active: !city.is_active });
    fetchData();
  };

  const openEdit = (city: any) => {
    setEditCity(city);
    setName(city.name);
    setState(city.state);
    setDialog(true);
  };

  const activeCount = cities.filter(c => c.is_active).length;

  return (
    <AdminLayout requiredRole="operator">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold">Cidades</h2>
            <p className="text-sm text-muted-foreground">{activeCount} cidades ativas de {cities.length} cadastradas</p>
          </div>
          <Button onClick={() => { setEditCity(null); setName(''); setState(''); setDialog(true); }}>
            <Plus className="h-4 w-4 mr-1" /> Nova Cidade
          </Button>
        </div>

        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Cidade</TableHead>
                  <TableHead>Estado</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Criada em</TableHead>
                  <TableHead>Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow><TableCell colSpan={5} className="text-center py-8">Carregando...</TableCell></TableRow>
                ) : cities.length === 0 ? (
                  <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">Nenhuma cidade cadastrada</TableCell></TableRow>
                ) : cities.map(c => (
                  <TableRow key={c.id}>
                    <TableCell className="font-medium flex items-center gap-2">
                      <MapPin className="h-4 w-4 text-muted-foreground" /> {c.name}
                    </TableCell>
                    <TableCell>{c.state}</TableCell>
                    <TableCell>
                      <Badge variant={c.is_active ? 'default' : 'secondary'}>{c.is_active ? 'Ativa' : 'Inativa'}</Badge>
                    </TableCell>
                    <TableCell className="text-xs">{new Date(c.created_at).toLocaleDateString('pt-BR')}</TableCell>
                    <TableCell>
                      <div className="flex gap-1">
                        <Button size="icon" variant="ghost" onClick={() => openEdit(c)}><Edit className="h-4 w-4" /></Button>
                        <Button size="icon" variant="ghost" onClick={() => toggleCity(c)}>
                          {c.is_active ? <ToggleRight className="h-4 w-4 text-green-500" /> : <ToggleLeft className="h-4 w-4 text-muted-foreground" />}
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Dialog open={dialog} onOpenChange={setDialog}>
          <DialogContent>
            <DialogHeader><DialogTitle>{editCity ? 'Editar' : 'Nova'} Cidade</DialogTitle></DialogHeader>
            <Input placeholder="Nome da cidade" value={name} onChange={e => setName(e.target.value)} />
            <Input placeholder="Estado (ex: SP, RJ)" value={state} onChange={e => setState(e.target.value.toUpperCase())} maxLength={2} />
            <DialogFooter>
              <Button variant="outline" onClick={() => setDialog(false)}>Cancelar</Button>
              <Button onClick={saveCity} disabled={!name.trim() || !state.trim()}>Salvar</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </AdminLayout>
  );
}
