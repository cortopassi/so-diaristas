import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { supabase } from '@/integrations/supabase/client';
import { Eye, Search } from 'lucide-react';

export default function AdminClientes() {
  const navigate = useNavigate();
  const [clients, setClients] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    const fetch = async () => {
      const { data: profiles } = await supabase.from('profiles').select('*').eq('role', 'client').order('created_at', { ascending: false });
      
      // Get booking counts per client
      const { data: bookings } = await supabase.from('bookings').select('client_id, status');
      
      const clientsWithStats = (profiles || []).map((p: any) => {
        const clientBookings = (bookings || []).filter((b: any) => b.client_id === p.user_id);
        return {
          ...p,
          totalBookings: clientBookings.length,
          cancellations: clientBookings.filter((b: any) => b.status === 'cancelled').length,
        };
      });
      
      setClients(clientsWithStats);
      setLoading(false);
    };
    fetch();
  }, []);

  const filtered = clients.filter(c =>
    !search || c.full_name?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <AdminLayout>
      <div className="space-y-6">
        <h2 className="text-2xl font-bold">Clientes</h2>

        <div className="relative max-w-md">
          <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Buscar por nome..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
        </div>

        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nome</TableHead>
                  <TableHead>Cidade</TableHead>
                  <TableHead>Total Serviços</TableHead>
                  <TableHead>Cancelamentos</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow><TableCell colSpan={6} className="text-center py-8">Carregando...</TableCell></TableRow>
                ) : filtered.length === 0 ? (
                  <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">Nenhum cliente encontrado</TableCell></TableRow>
                ) : filtered.map(c => (
                  <TableRow key={c.id}>
                    <TableCell className="font-medium">{c.full_name}</TableCell>
                    <TableCell>{c.city || '-'}</TableCell>
                    <TableCell>{c.totalBookings}</TableCell>
                    <TableCell>{c.cancellations}</TableCell>
                    <TableCell>
                      <Badge variant={c.account_status === 'active' ? 'outline' : 'destructive'}>
                        {c.account_status === 'active' ? 'Ativo' : c.account_status === 'suspended' ? 'Suspenso' : 'Bloqueado'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Button size="sm" variant="ghost" onClick={() => navigate(`/admin/cliente/${c.id}`)}>
                        <Eye className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
