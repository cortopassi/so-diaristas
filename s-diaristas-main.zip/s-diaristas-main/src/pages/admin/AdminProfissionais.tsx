import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { supabase } from '@/integrations/supabase/client';
import { Eye, Search, Star, AlertCircle, UserCheck, UserX, Clock } from 'lucide-react';
import { toast } from 'sonner';

interface PendingAlert {
  id: string;
  title: string;
  message: string;
  created_at: string;
  target_id: string | null;
  is_resolved: boolean;
}

export default function AdminProfissionais() {
  const navigate = useNavigate();
  const [professionals, setProfessionals] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterCity, setFilterCity] = useState('all');
  const [pendingAlerts, setPendingAlerts] = useState<PendingAlert[]>([]);
  const [alertsLoading, setAlertsLoading] = useState(true);
  const [approvingId, setApprovingId] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [profsRes, alertsRes] = await Promise.all([
          supabase
            .from('profiles')
            .select('*')
            .eq('role', 'professional')
            .order('created_at', { ascending: false }),
          supabase
            .from('admin_alerts')
            .select('*')
            .eq('alert_type', 'new_professional')
            .eq('is_resolved', false)
            .order('created_at', { ascending: false }),
        ]);
        console.log('[AdminProfs] profiles result:', profsRes.data?.length, profsRes.error);
        console.log('[AdminProfs] alerts result:', alertsRes.data?.length, alertsRes.error);
        setProfessionals(profsRes.data || []);
        setPendingAlerts(alertsRes.data || []);
      } catch (err) {
        console.error('[AdminProfs] fetch error:', err);
      } finally {
        setLoading(false);
        setAlertsLoading(false);
      }
    };
    fetchData();
  }, []);

  const cities = [...new Set(professionals.map(p => p.city).filter(Boolean))];

  const handleApprove = async (profileId: string, alertId: string) => {
    setApprovingId(profileId);
    try {
      const { error: profileError } = await supabase
        .from('profiles')
        .update({ status_aprovacao: 'aprovado', is_active: true, verification_status: 'verified' })
        .eq('id', profileId);
      if (profileError) throw profileError;

      const { error: alertError } = await supabase
        .from('admin_alerts')
        .update({ is_resolved: true, resolved_at: new Date().toISOString() })
        .eq('id', alertId);
      if (alertError) throw alertError;

      setPendingAlerts(prev => prev.filter(a => a.id !== alertId));
      setProfessionals(prev => prev.map(p => 
        p.id === profileId ? { ...p, status_aprovacao: 'aprovado', is_active: true, verification_status: 'verified' } : p
      ));
      toast.success('Profissional aprovado com sucesso!');
    } catch (err: any) {
      toast.error('Erro ao aprovar', { description: err.message });
    } finally {
      setApprovingId(null);
    }
  };

  const handleReject = async (profileId: string, alertId: string) => {
    setApprovingId(profileId);
    try {
      const { error: profileError } = await supabase
        .from('profiles')
        .update({ status_aprovacao: 'rejeitado', is_active: false, verification_status: 'rejected' })
        .eq('id', profileId);
      if (profileError) throw profileError;

      const { error: alertError } = await supabase
        .from('admin_alerts')
        .update({ is_resolved: true, resolved_at: new Date().toISOString() })
        .eq('id', alertId);
      if (alertError) throw alertError;

      setPendingAlerts(prev => prev.filter(a => a.id !== alertId));
      setProfessionals(prev => prev.map(p => 
        p.id === profileId ? { ...p, status_aprovacao: 'rejeitado', is_active: false, verification_status: 'rejected' } : p
      ));
      toast.success('Profissional rejeitado.');
    } catch (err: any) {
      toast.error('Erro ao rejeitar', { description: err.message });
    } finally {
      setApprovingId(null);
    }
  };

  const getProfessionalName = (targetId: string | null) => {
    if (!targetId) return 'Desconhecido';
    const prof = professionals.find(p => p.id === targetId);
    return prof?.full_name || 'Carregando...';
  };

  const filtered = professionals.filter(p => {
    if (search && !p.full_name?.toLowerCase().includes(search.toLowerCase())) return false;
    if (filterStatus !== 'all' && p.verification_status !== filterStatus) return false;
    if (filterCity !== 'all' && p.city !== filterCity) return false;
    return true;
  });

  const statusBadge = (status: string) => {
    const map: Record<string, { label: string; variant: any }> = {
      pending: { label: 'Pendente', variant: 'secondary' },
      documents_submitted: { label: 'Docs Enviados', variant: 'outline' },
      verified: { label: 'Aprovado', variant: 'default' },
      rejected: { label: 'Rejeitado', variant: 'destructive' },
    };
    const s = map[status] || { label: status, variant: 'outline' };
    return <Badge variant={s.variant}>{s.label}</Badge>;
  };

  const accountBadge = (status: string) => {
    if (status === 'suspended') return <Badge variant="destructive">Suspenso</Badge>;
    if (status === 'blocked') return <Badge variant="destructive">Bloqueado</Badge>;
    return <Badge variant="outline">Ativo</Badge>;
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <h2 className="text-2xl font-bold">Profissionais</h2>

        {/* Pending Approvals Section */}
        {!alertsLoading && pendingAlerts.length > 0 && (
          <Card className="border-orange-300 bg-orange-50 dark:bg-orange-950/20 dark:border-orange-800">
            <CardHeader className="pb-3">
              <div className="flex items-center gap-2">
                <AlertCircle className="h-5 w-5 text-orange-600" />
                <CardTitle className="text-lg text-orange-800 dark:text-orange-300">
                  Profissionais Aguardando Aprovação ({pendingAlerts.length})
                </CardTitle>
              </div>
              <CardDescription className="text-orange-700 dark:text-orange-400">
                Novos cadastros que precisam ser revisados e aprovados
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {pendingAlerts.map(alert => (
                <div key={alert.id} className="flex items-center justify-between bg-background rounded-lg p-4 border">
                  <div className="flex-1">
                    <p className="font-medium">{getProfessionalName(alert.target_id)}</p>
                    <p className="text-sm text-muted-foreground">{alert.message}</p>
                    <div className="flex items-center gap-1 mt-1 text-xs text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      {new Date(alert.created_at).toLocaleString('pt-BR')}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 ml-4">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => alert.target_id && navigate(`/admin/profissional/${alert.target_id}`)}
                    >
                      <Eye className="h-4 w-4 mr-1" /> Ver
                    </Button>
                    <Button
                      size="sm"
                      variant="default"
                      disabled={approvingId === alert.target_id}
                      onClick={() => alert.target_id && handleApprove(alert.target_id, alert.id)}
                    >
                      <UserCheck className="h-4 w-4 mr-1" /> Aprovar
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      disabled={approvingId === alert.target_id}
                      onClick={() => alert.target_id && handleReject(alert.target_id, alert.id)}
                    >
                      <UserX className="h-4 w-4 mr-1" /> Rejeitar
                    </Button>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        <div className="flex flex-wrap gap-3">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Buscar por nome..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
          </div>
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-[180px]"><SelectValue placeholder="Status" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos</SelectItem>
              <SelectItem value="pending">Pendente</SelectItem>
              <SelectItem value="documents_submitted">Docs Enviados</SelectItem>
              <SelectItem value="verified">Aprovado</SelectItem>
              <SelectItem value="rejected">Rejeitado</SelectItem>
            </SelectContent>
          </Select>
          <Select value={filterCity} onValueChange={setFilterCity}>
            <SelectTrigger className="w-[180px]"><SelectValue placeholder="Cidade" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas</SelectItem>
              {cities.map(c => <SelectItem key={c} value={c!}>{c}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>

        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nome</TableHead>
                  <TableHead>Cidade</TableHead>
                  <TableHead>Aprovação</TableHead>
                  <TableHead>Verificação</TableHead>
                  <TableHead>Conta</TableHead>
                  <TableHead>Média</TableHead>
                  <TableHead>Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow><TableCell colSpan={7} className="text-center py-8">Carregando...</TableCell></TableRow>
                ) : filtered.length === 0 ? (
                  <TableRow><TableCell colSpan={7} className="text-center py-8 text-muted-foreground">Nenhum profissional encontrado</TableCell></TableRow>
                ) : filtered.map(p => (
                  <TableRow key={p.id}>
                    <TableCell className="font-medium">{p.full_name}</TableCell>
                    <TableCell>{p.city || '-'}</TableCell>
                    <TableCell>
                      {p.status_aprovacao === 'aprovado' ? (
                        <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">Aprovado</Badge>
                      ) : p.status_aprovacao === 'rejeitado' ? (
                        <Badge variant="destructive">Rejeitado</Badge>
                      ) : (
                        <Badge variant="secondary">Pendente</Badge>
                      )}
                    </TableCell>
                    <TableCell>{statusBadge(p.verification_status)}</TableCell>
                    <TableCell>{accountBadge(p.account_status)}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                        {Number(p.average_rating || 0).toFixed(1)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Button size="sm" variant="ghost" onClick={() => navigate(`/admin/profissional/${p.id}`)}>
                        <Eye className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}