import { useEffect, useState } from 'react';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { Calendar, CheckCircle, XCircle, DollarSign, Users, UserCheck, AlertTriangle, Star } from 'lucide-react';

interface DashboardStats {
  todayBookings: number;
  todayCompleted: number;
  todayCancelled: number;
  todayRevenue: number;
  todayCommission: number;
  totalActiveProfessionals: number;
  totalSuspended: number;
  totalPending: number;
  totalClients: number;
  averageRating: number;
}

interface Alert {
  id: string;
  severity: string;
  title: string;
  message: string;
  created_at: string;
}

export default function AdminDashboard() {
  const [stats, setStats] = useState<DashboardStats>({
    todayBookings: 0, todayCompleted: 0, todayCancelled: 0,
    todayRevenue: 0, todayCommission: 0, totalActiveProfessionals: 0,
    totalSuspended: 0, totalPending: 0, totalClients: 0, averageRating: 0,
  });
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      const today = new Date().toISOString().split('T')[0];

      const [bookingsRes, profilesRes, alertsRes] = await Promise.all([
        supabase.from('bookings').select('status, total_amount, scheduled_date'),
        supabase.from('profiles').select('role, verification_status, account_status, average_rating, is_active'),
        supabase.from('admin_alerts').select('*').eq('is_resolved', false).order('created_at', { ascending: false }).limit(10),
      ]);

      const bookings = bookingsRes.data || [];
      const profiles = profilesRes.data || [];

      const todayBookings = bookings.filter((b: any) => b.scheduled_date === today);
      const professionals = profiles.filter((p: any) => p.role === 'professional');
      const clients = profiles.filter((p: any) => p.role === 'client');

      setStats({
        todayBookings: todayBookings.length,
        todayCompleted: todayBookings.filter((b: any) => b.status === 'completed').length,
        todayCancelled: todayBookings.filter((b: any) => b.status === 'cancelled').length,
        todayRevenue: todayBookings.filter((b: any) => b.status === 'completed').reduce((sum: number, b: any) => sum + Number(b.total_amount), 0),
        todayCommission: todayBookings.filter((b: any) => b.status === 'completed').reduce((sum: number, b: any) => sum + Number(b.total_amount) * 0.2, 0),
        totalActiveProfessionals: professionals.filter((p: any) => p.verification_status === 'verified' && p.account_status === 'active').length,
        totalSuspended: professionals.filter((p: any) => p.account_status === 'suspended').length,
        totalPending: professionals.filter((p: any) => p.verification_status === 'pending' || p.verification_status === 'documents_submitted').length,
        totalClients: clients.length,
        averageRating: professionals.length > 0 ? professionals.reduce((sum: number, p: any) => sum + Number(p.average_rating || 0), 0) / professionals.length : 0,
      });

      setAlerts((alertsRes.data || []) as Alert[]);
      setLoading(false);
    };

    fetchStats();
  }, []);

  const statCards = [
    { title: 'Agendados Hoje', value: stats.todayBookings, icon: Calendar, color: 'text-blue-500' },
    { title: 'Concluídos Hoje', value: stats.todayCompleted, icon: CheckCircle, color: 'text-green-500' },
    { title: 'Cancelamentos Hoje', value: stats.todayCancelled, icon: XCircle, color: 'text-red-500' },
    { title: 'Faturamento Hoje', value: `R$ ${stats.todayRevenue.toFixed(2)}`, icon: DollarSign, color: 'text-emerald-500' },
    { title: 'Comissão Hoje', value: `R$ ${stats.todayCommission.toFixed(2)}`, icon: DollarSign, color: 'text-primary' },
    { title: 'Profissionais Ativos', value: stats.totalActiveProfessionals, icon: UserCheck, color: 'text-green-500' },
    { title: 'Suspensos', value: stats.totalSuspended, icon: AlertTriangle, color: 'text-orange-500' },
    { title: 'Pendentes', value: stats.totalPending, icon: Users, color: 'text-yellow-500' },
    { title: 'Clientes', value: stats.totalClients, icon: Users, color: 'text-blue-500' },
    { title: 'Média Geral', value: stats.averageRating.toFixed(1), icon: Star, color: 'text-yellow-500' },
  ];

  const severityColor: Record<string, string> = {
    critical: 'destructive',
    warning: 'secondary',
    info: 'outline',
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <h2 className="text-2xl font-bold">Dashboard</h2>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {statCards.map((card) => (
            <Card key={card.title}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-xs font-medium text-muted-foreground">{card.title}</CardTitle>
                <card.icon className={`h-4 w-4 ${card.color}`} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{loading ? '...' : card.value}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        {alerts.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-orange-500" /> Alertas
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {alerts.map((alert) => (
                  <div key={alert.id} className="flex items-start gap-3 p-3 rounded-md bg-muted/50">
                    <Badge variant={severityColor[alert.severity] as any || 'outline'}>{alert.severity}</Badge>
                    <div>
                      <p className="font-medium text-sm">{alert.title}</p>
                      <p className="text-xs text-muted-foreground">{alert.message}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </AdminLayout>
  );
}
