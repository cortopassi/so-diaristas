import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { supabase } from '@/integrations/supabase/client';
import { useAdmin } from '@/hooks/useAdmin';
import { toast } from '@/hooks/use-toast';
import { ArrowLeft, CheckCircle, XCircle, Ban, Unlock, Lock, Star } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';

export default function AdminProfissionalDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { logAction, isSuperAdmin, isOperator } = useAdmin();
  const [profile, setProfile] = useState<any>(null);
  const [documents, setDocuments] = useState<any[]>([]);
  const [reviews, setReviews] = useState<any[]>([]);
  const [bookings, setBookings] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [rejectDialog, setRejectDialog] = useState<{ open: boolean; docId?: string }>({ open: false });
  const [rejectReason, setRejectReason] = useState('');

  const fetchData = async () => {
    if (!id) return;
    const [profileRes, docsRes, reviewsRes, bookingsRes] = await Promise.all([
      supabase.from('profiles').select('*').eq('id', id).single(),
      supabase.from('professional_documents').select('*').eq('professional_id', id).order('created_at'),
      supabase.from('reviews').select('*').eq('professional_id', id).order('created_at', { ascending: false }),
      supabase.from('bookings').select('*').eq('professional_id', id).order('created_at', { ascending: false }).limit(20),
    ]);
    setProfile(profileRes.data);
    setDocuments(docsRes.data || []);
    setReviews(reviewsRes.data || []);
    setBookings(bookingsRes.data || []);
    setLoading(false);
  };

  useEffect(() => { fetchData(); }, [id]);

  const approveDocument = async (docId: string) => {
    await supabase.from('professional_documents').update({ status: 'approved', reviewed_at: new Date().toISOString() }).eq('id', docId);
    await logAction('approve_document', 'professional_document', docId);
    toast({ title: 'Documento aprovado' });
    fetchData();
  };

  const rejectDocument = async () => {
    if (!rejectDialog.docId || !rejectReason) return;
    await supabase.from('professional_documents').update({ status: 'rejected', rejection_reason: rejectReason, reviewed_at: new Date().toISOString() }).eq('id', rejectDialog.docId);
    await logAction('reject_document', 'professional_document', rejectDialog.docId, { reason: rejectReason });
    toast({ title: 'Documento rejeitado' });
    setRejectDialog({ open: false });
    setRejectReason('');
    fetchData();
  };

  const approveAll = async () => {
    const pending = documents.filter(d => d.status === 'pending');
    for (const doc of pending) {
      await supabase.from('professional_documents').update({ status: 'approved', reviewed_at: new Date().toISOString() }).eq('id', doc.id);
    }
    await logAction('approve_all_documents', 'profile', id);
    toast({ title: 'Todos os documentos aprovados' });
    fetchData();
  };

  const updateAccountStatus = async (status: string) => {
    await supabase.from('profiles').update({ account_status: status } as any).eq('id', id);
    await logAction(`account_${status}`, 'profile', id);
    toast({ title: `Conta ${status === 'active' ? 'reativada' : status === 'suspended' ? 'suspensa' : 'bloqueada'}` });
    fetchData();
  };

  if (loading) return <AdminLayout><p>Carregando...</p></AdminLayout>;
  if (!profile) return <AdminLayout><p>Profissional não encontrado</p></AdminLayout>;

  const docTypeLabels: Record<string, string> = { rg: 'RG', cpf: 'CPF', address_proof: 'Comprovante Endereço', criminal_record: 'Antecedentes' };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <Button variant="ghost" onClick={() => navigate('/admin/profissionais')}>
          <ArrowLeft className="h-4 w-4 mr-2" /> Voltar
        </Button>

        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold">{profile.full_name}</h2>
          <div className="flex gap-2">
            {isOperator && profile.account_status !== 'active' && (
              <Button size="sm" variant="outline" onClick={() => updateAccountStatus('active')}><Unlock className="h-4 w-4 mr-1" /> Reativar</Button>
            )}
            {isOperator && profile.account_status === 'active' && (
              <Button size="sm" variant="destructive" onClick={() => updateAccountStatus('suspended')}><Lock className="h-4 w-4 mr-1" /> Suspender</Button>
            )}
            {isSuperAdmin && (
              <Button size="sm" variant="destructive" onClick={() => updateAccountStatus('blocked')}><Ban className="h-4 w-4 mr-1" /> Bloquear</Button>
            )}
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <Card>
            <CardHeader><CardTitle>Dados Pessoais</CardTitle></CardHeader>
            <CardContent className="space-y-2 text-sm">
              <p><strong>Telefone:</strong> {profile.phone || '-'}</p>
              <p><strong>Cidade:</strong> {profile.city || '-'}</p>
              <p><strong>Bairro:</strong> {profile.neighborhood || '-'}</p>
              <p><strong>Bio:</strong> {profile.bio || '-'}</p>
              <p><strong>Valor/hora:</strong> R$ {profile.hourly_rate || '-'}</p>
              <p><strong>Pix:</strong> {profile.pix_key || '-'} ({profile.pix_key_type || '-'})</p>
              <p><strong>Verificação:</strong> <Badge variant="outline">{profile.verification_status}</Badge></p>
              <p><strong>Conta:</strong> <Badge variant={profile.account_status === 'active' ? 'outline' : 'destructive'}>{profile.account_status}</Badge></p>
              <p><strong>Contrato aceito:</strong> {profile.terms_accepted_at ? `Sim - ${new Date(profile.terms_accepted_at).toLocaleString('pt-BR')}` : 'Não'}</p>
              <p><strong>Cadastro:</strong> {new Date(profile.created_at).toLocaleString('pt-BR')}</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Documentos</CardTitle>
                {isOperator && documents.some(d => d.status === 'pending') && (
                  <Button size="sm" onClick={approveAll}><CheckCircle className="h-4 w-4 mr-1" /> Aprovar Todos</Button>
                )}
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {documents.length === 0 ? (
                  <p className="text-sm text-muted-foreground">Nenhum documento enviado</p>
                ) : documents.map(doc => (
                  <div key={doc.id} className="flex items-center justify-between p-3 border rounded-md">
                    <div>
                      <p className="font-medium text-sm">{docTypeLabels[doc.document_type] || doc.document_type}</p>
                      <p className="text-xs text-muted-foreground">{doc.file_name}</p>
                      <Badge variant={doc.status === 'approved' ? 'default' : doc.status === 'rejected' ? 'destructive' : 'secondary'} className="mt-1">
                        {doc.status === 'approved' ? 'Aprovado' : doc.status === 'rejected' ? 'Rejeitado' : 'Pendente'}
                      </Badge>
                      {doc.rejection_reason && <p className="text-xs text-destructive mt-1">{doc.rejection_reason}</p>}
                    </div>
                    {isOperator && doc.status === 'pending' && (
                      <div className="flex gap-1">
                        <Button size="icon" variant="ghost" className="text-green-600" onClick={() => approveDocument(doc.id)}>
                          <CheckCircle className="h-4 w-4" />
                        </Button>
                        <Button size="icon" variant="ghost" className="text-red-600" onClick={() => setRejectDialog({ open: true, docId: doc.id })}>
                          <XCircle className="h-4 w-4" />
                        </Button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader><CardTitle>Serviços</CardTitle></CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {(profile.services_offered || []).map((s: string) => <Badge key={s} variant="outline">{s}</Badge>)}
              {(!profile.services_offered || profile.services_offered.length === 0) && <p className="text-sm text-muted-foreground">Nenhum serviço cadastrado</p>}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Avaliações ({reviews.length})</CardTitle></CardHeader>
          <CardContent>
            {reviews.length === 0 ? <p className="text-sm text-muted-foreground">Nenhuma avaliação</p> : (
              <div className="space-y-2">
                {reviews.map(r => (
                  <div key={r.id} className="p-3 border rounded-md">
                    <div className="flex items-center gap-2">
                      <div className="flex">{Array.from({ length: 5 }).map((_, i) => <Star key={i} className={`h-3 w-3 ${i < r.rating ? 'fill-yellow-400 text-yellow-400' : 'text-muted'}`} />)}</div>
                      <span className="text-xs text-muted-foreground">{new Date(r.created_at).toLocaleDateString('pt-BR')}</span>
                    </div>
                    {r.comment && <p className="text-sm mt-1">{r.comment}</p>}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Agendamentos Recentes</CardTitle></CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Serviço</TableHead>
                  <TableHead>Data</TableHead>
                  <TableHead>Valor</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {bookings.length === 0 ? (
                  <TableRow><TableCell colSpan={4} className="text-center text-muted-foreground">Nenhum agendamento</TableCell></TableRow>
                ) : bookings.map(b => (
                  <TableRow key={b.id}>
                    <TableCell>{b.service_type}</TableCell>
                    <TableCell>{new Date(b.scheduled_date).toLocaleDateString('pt-BR')}</TableCell>
                    <TableCell>R$ {Number(b.total_amount).toFixed(2)}</TableCell>
                    <TableCell><Badge variant="outline">{b.status}</Badge></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Dialog open={rejectDialog.open} onOpenChange={(o) => setRejectDialog({ open: o })}>
          <DialogContent>
            <DialogHeader><DialogTitle>Rejeitar Documento</DialogTitle></DialogHeader>
            <Textarea placeholder="Motivo da rejeição (obrigatório)" value={rejectReason} onChange={e => setRejectReason(e.target.value)} />
            <DialogFooter>
              <Button variant="outline" onClick={() => setRejectDialog({ open: false })}>Cancelar</Button>
              <Button variant="destructive" onClick={rejectDocument} disabled={!rejectReason.trim()}>Rejeitar</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </AdminLayout>
  );
}
