import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2, Calendar, MapPin, Clock, Search, LogOut, Star } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Booking } from '@/types/database';
import { ReviewModal } from '@/components/reviews/ReviewModal';

export default function PainelCliente() {
  const navigate = useNavigate();
  const { user, profile, loading: authLoading, signOut } = useAuth();
  const [bookings, setBookings] = useState<(Booking & { hasReview?: boolean })[]>([]);
  const [loadingBookings, setLoadingBookings] = useState(true);
  const [reviewModal, setReviewModal] = useState<{
    isOpen: boolean;
    bookingId: string;
    professionalId: string;
    professionalName: string;
  }>({ isOpen: false, bookingId: '', professionalId: '', professionalName: '' });

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/login');
      return;
    }

    if (user) {
      fetchBookings();
    }
  }, [user, authLoading, navigate]);

  const fetchBookings = async () => {
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select(`
          *,
          professional:profiles!bookings_professional_id_fkey(
            id, full_name, avatar_url, phone
          )
        `)
        .eq('client_id', user!.id)
        .order('created_at', { ascending: false });

      if (error) throw error;

      // Buscar quais bookings já têm review
      const bookingIds = (data || []).map(b => b.id);
      const { data: reviewsData } = await supabase
        .from('reviews')
        .select('booking_id')
        .in('booking_id', bookingIds);

      const reviewedBookingIds = new Set(reviewsData?.map(r => r.booking_id) || []);

      const bookingsWithReviewInfo = (data || []).map(b => ({
        ...b,
        hasReview: reviewedBookingIds.has(b.id),
      }));

      setBookings(bookingsWithReviewInfo as (Booking & { hasReview?: boolean })[]);
    } catch (error) {
      console.error('Erro ao buscar agendamentos:', error);
    } finally {
      setLoadingBookings(false);
    }
  };

  const handleSignOut = async () => {
    await signOut();
    window.location.href = '/';
  };

  const getStatusBadge = (status: string) => {
    const config = {
      pending: { label: 'Aguardando', className: 'bg-yellow-500/10 text-yellow-600 border-yellow-500/20' },
      confirmed: { label: 'Confirmado', className: 'bg-green-500/10 text-green-600 border-green-500/20' },
      completed: { label: 'Concluído', className: 'bg-blue-500/10 text-blue-600 border-blue-500/20' },
      cancelled: { label: 'Cancelado', className: 'bg-red-500/10 text-red-600 border-red-500/20' },
    };
    const { label, className } = config[status as keyof typeof config] || config.pending;
    return <Badge variant="outline" className={className}>{label}</Badge>;
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  const activeBookings = bookings.filter(b => ['pending', 'confirmed'].includes(b.status));
  const pastBookings = bookings.filter(b => ['completed', 'cancelled'].includes(b.status));

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      
      <main className="flex-1 container mx-auto px-4 py-8 pt-24">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold">Olá, {profile?.full_name?.split(' ')[0]}! 👋</h1>
            <p className="text-muted-foreground">Acompanhe seus agendamentos</p>
          </div>
          <div className="flex gap-2">
            <Link to="/servicos">
              <Button>
                <Search className="h-4 w-4 mr-2" />
                Buscar Serviços
              </Button>
            </Link>
            <Link to="/profissionais">
              <Button variant="outline">
                <Search className="h-4 w-4 mr-2" />
                Buscar Profissionais
              </Button>
            </Link>
            <Button variant="outline" onClick={handleSignOut}>
              <LogOut className="h-4 w-4 mr-2" />
              Sair
            </Button>
          </div>
        </div>

        <Tabs defaultValue="ativos" className="space-y-6">
          <TabsList>
            <TabsTrigger value="ativos">
              Ativos ({activeBookings.length})
            </TabsTrigger>
            <TabsTrigger value="historico">
              Histórico ({pastBookings.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="ativos" className="space-y-4">
            {activeBookings.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <Calendar className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
                  <p className="text-muted-foreground mb-4">Você não tem agendamentos ativos</p>
                  <Link to="/profissionais">
                    <Button>
                      <Search className="h-4 w-4 mr-2" />
                      Encontrar Profissional
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ) : (
              activeBookings.map(booking => (
                <Card key={booking.id}>
                  <CardContent className="pt-6">
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white font-bold">
                          {booking.professional?.full_name?.charAt(0) || 'P'}
                        </div>
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <p className="font-semibold">{booking.professional?.full_name}</p>
                            {getStatusBadge(booking.status)}
                          </div>
                          <Badge variant="secondary">{booking.service_type}</Badge>
                          <p className="text-sm text-muted-foreground flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            {format(new Date(booking.scheduled_date), "dd 'de' MMMM", { locale: ptBR })} às {booking.scheduled_time.slice(0, 5)}
                          </p>
                          <p className="text-sm text-muted-foreground flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            {booking.hours}h de serviço
                          </p>
                          <p className="text-sm text-muted-foreground flex items-center gap-1">
                            <MapPin className="h-3 w-3" />
                            {booking.address}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-2xl font-bold text-primary">
                          R$ {booking.total_amount.toFixed(2)}
                        </p>
                        {booking.status === 'pending' && (
                          <p className="text-xs text-muted-foreground">
                            Aguardando confirmação
                          </p>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </TabsContent>

          <TabsContent value="historico" className="space-y-4">
            {pastBookings.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <p className="text-muted-foreground">Nenhum agendamento no histórico</p>
                </CardContent>
              </Card>
            ) : (
              pastBookings.map(booking => (
                <Card key={booking.id}>
                  <CardContent className="pt-6">
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center text-muted-foreground font-bold">
                          {booking.professional?.full_name?.charAt(0) || 'P'}
                        </div>
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <p className="font-semibold">{booking.professional?.full_name}</p>
                            {getStatusBadge(booking.status)}
                          </div>
                          <Badge variant="outline">{booking.service_type}</Badge>
                          <p className="text-sm text-muted-foreground">
                            {format(new Date(booking.scheduled_date), "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <p className="text-lg font-semibold">
                          R$ {booking.total_amount.toFixed(2)}
                        </p>
                        {booking.status === 'completed' && !booking.hasReview && (
                          <Button
                            size="sm"
                            onClick={() => setReviewModal({
                              isOpen: true,
                              bookingId: booking.id,
                              professionalId: booking.professional_id,
                              professionalName: booking.professional?.full_name || 'Profissional',
                            })}
                          >
                            <Star className="h-4 w-4 mr-1" />
                            Avaliar
                          </Button>
                        )}
                        {booking.hasReview && (
                          <Badge variant="secondary" className="gap-1">
                            <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                            Avaliado
                          </Badge>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </TabsContent>
        </Tabs>
      </main>

      <Footer />

      <ReviewModal
        isOpen={reviewModal.isOpen}
        onClose={() => setReviewModal({ ...reviewModal, isOpen: false })}
        bookingId={reviewModal.bookingId}
        professionalId={reviewModal.professionalId}
        professionalName={reviewModal.professionalName}
        onSuccess={fetchBookings}
      />
    </div>
  );
}
