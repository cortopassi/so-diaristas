import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { Loader2, ArrowLeft, Star, MapPin, ShieldCheck, Calendar, Clock, DollarSign, CheckCircle2 } from 'lucide-react';
import { format, addDays, isBefore, startOfDay } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface ProfessionalProfile {
  id: string;
  full_name: string;
  avatar_url: string | null;
  city: string | null;
  neighborhood: string | null;
  average_rating: number | null;
  total_reviews: number | null;
  verification_status: string | null;
  phone: string | null;
}

interface ProfService {
  id: string;
  service_id: string;
  price: number;
  charge_type: string;
  handles_emergency: boolean;
  service: { id: string; name: string } | null;
}

interface Availability {
  day_of_week: number;
  start_time: string;
  end_time: string;
  is_active: boolean;
}

const DAY_NAMES: Record<number, string> = {
  0: 'Domingo', 1: 'Segunda', 2: 'Terça', 3: 'Quarta',
  4: 'Quinta', 5: 'Sexta', 6: 'Sábado',
};

export default function Agendar() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user, profile: clientProfile } = useAuth();

  const [professional, setProfessional] = useState<ProfessionalProfile | null>(null);
  const [services, setServices] = useState<ProfService[]>([]);
  const [availability, setAvailability] = useState<Availability[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  // Form
  const [selectedServiceId, setSelectedServiceId] = useState('');
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');
  const [hours, setHours] = useState(4);
  const [address, setAddress] = useState('');
  const [notes, setNotes] = useState('');

  useEffect(() => {
    if (!user) {
      toast.error('Faça login para agendar');
      navigate('/login');
      return;
    }
    if (id) fetchData();
  }, [id, user]);

  useEffect(() => {
    if (clientProfile) {
      const parts = [
        (clientProfile as any).rua,
        (clientProfile as any).numero,
        (clientProfile as any).complemento,
        clientProfile.neighborhood,
        clientProfile.city,
      ].filter(Boolean);
      if (parts.length > 0) setAddress(parts.join(', '));
    }
  }, [clientProfile]);

  const fetchData = async () => {
    try {
      const [profRes, svcRes, availRes] = await Promise.all([
        supabase.from('profiles').select('id, full_name, avatar_url, city, neighborhood, average_rating, total_reviews, verification_status, phone').eq('id', id!).single(),
        supabase.from('professional_services').select('id, service_id, price, charge_type, handles_emergency, service:services!professional_services_service_id_fkey(id, name)').eq('professional_id', id!).eq('is_active', true),
        supabase.from('professional_availability').select('day_of_week, start_time, end_time, is_active').eq('professional_id', id!).eq('is_active', true),
      ]);

      if (profRes.error) throw profRes.error;
      setProfessional(profRes.data as ProfessionalProfile);

      const svcData = (svcRes.data || []).map((s: any) => ({
        ...s,
        service: Array.isArray(s.service) ? s.service[0] : s.service,
      }));
      setServices(svcData as ProfService[]);
      setAvailability((availRes.data || []) as Availability[]);
    } catch (err) {
      console.error('Erro ao carregar dados:', err);
      toast.error('Erro ao carregar profissional');
    } finally {
      setLoading(false);
    }
  };

  const selectedService = services.find(s => s.id === selectedServiceId);
  const totalAmount = selectedService ? selectedService.charge_type === 'hour' ? selectedService.price * hours : selectedService.price : 0;

  // Get available dates (next 30 days, matching availability days, not today)
  const getAvailableDates = () => {
    const availDays = new Set(availability.map(a => a.day_of_week));
    const dates: string[] = [];
    const tomorrow = addDays(startOfDay(new Date()), 1);
    for (let i = 0; i < 30; i++) {
      const d = addDays(tomorrow, i);
      if (availDays.has(d.getDay())) {
        dates.push(format(d, 'yyyy-MM-dd'));
      }
    }
    return dates;
  };

  // Get available times for selected date
  const getAvailableTimes = () => {
    if (!selectedDate) return [];
    const dayOfWeek = new Date(selectedDate + 'T12:00:00').getDay();
    const dayAvail = availability.filter(a => a.day_of_week === dayOfWeek && a.is_active);
    const times: string[] = [];
    dayAvail.forEach(a => {
      const startHour = parseInt(a.start_time.split(':')[0]);
      const endHour = parseInt(a.end_time.split(':')[0]);
      for (let h = startHour; h < endHour; h++) {
        times.push(`${h.toString().padStart(2, '0')}:00`);
      }
    });
    return times;
  };

  const handleSubmit = async () => {
    if (!selectedServiceId) { toast.error('Selecione um serviço'); return; }
    if (!selectedDate) { toast.error('Selecione uma data'); return; }
    if (!selectedTime) { toast.error('Selecione um horário'); return; }
    if (!address.trim()) { toast.error('Endereço é obrigatório'); return; }

    setSubmitting(true);
    try {
      const { error } = await supabase.from('bookings').insert({
        client_id: user!.id,
        professional_id: professional!.id,
        service_type: selectedService?.service?.name || 'Serviço',
        scheduled_date: selectedDate,
        scheduled_time: selectedTime,
        hours,
        total_amount: totalAmount,
        address,
        notes: notes || null,
        status: 'pending',
      });

      if (error) throw error;
      setSuccess(true);
      toast.success('Agendamento criado com sucesso!');
    } catch (err: any) {
      console.error('Erro ao criar agendamento:', err);
      toast.error('Erro ao criar agendamento', { description: err.message });
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <Header />
        <main className="flex-1 flex items-center justify-center"><Loader2 className="h-8 w-8 animate-spin text-primary" /></main>
        <Footer />
      </div>
    );
  }

  if (!professional) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <Header />
        <main className="flex-1 container mx-auto px-4 py-8 pt-24 text-center">
          <p className="text-muted-foreground">Profissional não encontrado</p>
          <Button variant="outline" onClick={() => navigate(-1)} className="mt-4"><ArrowLeft className="h-4 w-4 mr-2" /> Voltar</Button>
        </main>
        <Footer />
      </div>
    );
  }

  if (success) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/5 to-secondary/5 p-4">
        <Card className="w-full max-w-md text-center">
          <CardHeader>
            <CheckCircle2 className="h-16 w-16 text-green-500 mx-auto mb-4" />
            <CardTitle>Agendamento Confirmado!</CardTitle>
            <CardDescription>Sua solicitação foi enviada para {professional.full_name}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-muted rounded-lg p-4 text-left space-y-2">
              <p className="text-sm"><strong>Serviço:</strong> {selectedService?.service?.name}</p>
              <p className="text-sm"><strong>Data:</strong> {format(new Date(selectedDate + 'T12:00:00'), "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}</p>
              <p className="text-sm"><strong>Horário:</strong> {selectedTime}</p>
              <p className="text-sm"><strong>Valor:</strong> R$ {totalAmount.toFixed(2)}</p>
            </div>
            <p className="text-sm text-muted-foreground">Aguarde a confirmação do profissional. Você receberá uma notificação.</p>
            <div className="flex gap-2">
              <Button onClick={() => navigate('/painel-cliente')} className="flex-1">Meu Painel</Button>
              <Button variant="outline" onClick={() => navigate('/servicos')} className="flex-1">Buscar Mais</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const availableDates = getAvailableDates();
  const availableTimes = getAvailableTimes();

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      <main className="flex-1 container mx-auto px-4 py-8 pt-24 max-w-2xl">
        <Button variant="ghost" onClick={() => navigate(-1)} className="mb-4">
          <ArrowLeft className="h-4 w-4 mr-2" /> Voltar
        </Button>

        {/* Professional Header */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white text-xl font-bold flex-shrink-0">
                {professional.avatar_url ? (
                  <img src={professional.avatar_url} alt="" className="w-full h-full rounded-full object-cover" />
                ) : professional.full_name.charAt(0)}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-xl font-bold">{professional.full_name}</h2>
                  {professional.verification_status === 'verified' && <ShieldCheck className="h-4 w-4 text-green-500" />}
                </div>
                <p className="text-sm text-muted-foreground flex items-center gap-1">
                  <MapPin className="h-3 w-3" /> {professional.neighborhood}, {professional.city}
                </p>
                <div className="flex items-center gap-1 mt-1">
                  <Star className="h-3.5 w-3.5 fill-yellow-400 text-yellow-400" />
                  <span className="text-sm font-medium">{(professional.average_rating || 0).toFixed(1)}</span>
                  <span className="text-xs text-muted-foreground">({professional.total_reviews || 0} avaliações)</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Booking Form */}
        <div className="space-y-6">
          {/* Step 1: Select Service */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center">1</span>
                Escolha o serviço
              </CardTitle>
            </CardHeader>
            <CardContent>
              {services.length === 0 ? (
                <p className="text-muted-foreground text-sm">Este profissional não tem serviços cadastrados.</p>
              ) : (
                <div className="grid gap-2">
                  {services.map(svc => (
                    <div
                      key={svc.id}
                      onClick={() => setSelectedServiceId(svc.id)}
                      className={`p-3 rounded-lg border cursor-pointer transition-all ${
                        selectedServiceId === svc.id ? 'border-primary bg-primary/5 ring-1 ring-primary' : 'border-border hover:border-primary/50'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">{svc.service?.name || 'Serviço'}</p>
                          <div className="flex items-center gap-2 mt-1">
                            {svc.handles_emergency && (
                              <Badge variant="outline" className="text-xs text-orange-600 border-orange-300">Emergência</Badge>
                            )}
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-bold text-primary">R$ {svc.price.toFixed(2)}</p>
                          <p className="text-xs text-muted-foreground">/{svc.charge_type === 'hour' ? 'hora' : 'período'}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Step 2: Select Date */}
          {selectedServiceId && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center">2</span>
                  Escolha a data
                </CardTitle>
              </CardHeader>
              <CardContent>
                {availableDates.length === 0 ? (
                  <p className="text-muted-foreground text-sm">Nenhuma data disponível nos próximos 30 dias.</p>
                ) : (
                  <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                    {availableDates.slice(0, 16).map(date => {
                      const d = new Date(date + 'T12:00:00');
                      return (
                        <Button
                          key={date}
                          variant={selectedDate === date ? 'default' : 'outline'}
                          size="sm"
                          onClick={() => { setSelectedDate(date); setSelectedTime(''); }}
                          className="flex flex-col h-auto py-2"
                        >
                          <span className="text-xs">{DAY_NAMES[d.getDay()]}</span>
                          <span className="font-bold">{format(d, 'dd/MM')}</span>
                        </Button>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Step 3: Select Time */}
          {selectedDate && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center">3</span>
                  Escolha o horário
                </CardTitle>
              </CardHeader>
              <CardContent>
                {availableTimes.length === 0 ? (
                  <p className="text-muted-foreground text-sm">Nenhum horário disponível nesta data.</p>
                ) : (
                  <div className="flex flex-wrap gap-2">
                    {availableTimes.map(time => (
                      <Button
                        key={time}
                        variant={selectedTime === time ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => setSelectedTime(time)}
                      >
                        {time}
                      </Button>
                    ))}
                  </div>
                )}

                {selectedService?.charge_type === 'hour' && (
                  <div className="mt-4 space-y-2">
                    <Label>Duração (horas)</Label>
                    <Select value={hours.toString()} onValueChange={v => setHours(parseInt(v))}>
                      <SelectTrigger className="w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {[2, 3, 4, 5, 6, 8].map(h => (
                          <SelectItem key={h} value={h.toString()}>{h} horas</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Step 4: Address & Notes */}
          {selectedTime && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center">4</span>
                  Local e observações
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Endereço do serviço *</Label>
                  <Input value={address} onChange={e => setAddress(e.target.value)} placeholder="Rua, número, bairro, cidade" />
                </div>
                <div className="space-y-2">
                  <Label>Observações (opcional)</Label>
                  <Textarea value={notes} onChange={e => setNotes(e.target.value)} placeholder="Instruções especiais, detalhes do serviço..." rows={3} />
                </div>
              </CardContent>
            </Card>
          )}

          {/* Summary & Confirm */}
          {selectedTime && address.trim() && (
            <Card className="border-primary">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-primary" />
                  Resumo do Agendamento
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Serviço</span>
                  <span className="font-medium">{selectedService?.service?.name}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Data</span>
                  <span className="font-medium">{format(new Date(selectedDate + 'T12:00:00'), "dd 'de' MMMM", { locale: ptBR })}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Horário</span>
                  <span className="font-medium">{selectedTime}</span>
                </div>
                {selectedService?.charge_type === 'hour' && (
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Duração</span>
                    <span className="font-medium">{hours}h</span>
                  </div>
                )}
                <div className="border-t pt-3 flex justify-between items-center">
                  <span className="font-semibold">Total</span>
                  <span className="text-2xl font-bold text-primary">R$ {totalAmount.toFixed(2)}</span>
                </div>

                <Button onClick={handleSubmit} disabled={submitting} className="w-full" size="lg">
                  {submitting ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <CheckCircle2 className="h-4 w-4 mr-2" />}
                  Confirmar Agendamento
                </Button>
                <p className="text-xs text-center text-muted-foreground">
                  Pagamento seguro via PIX · Taxa de 20% para a plataforma
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
      <Footer />
    </div>
  );
}
