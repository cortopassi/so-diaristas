import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Link } from 'react-router-dom';
import { Search, Shield, Calendar, Star, Sparkles, Brush, Home, Hammer, Sofa, PartyPopper, CheckCircle, ArrowRight } from 'lucide-react';
import { SERVICES, CONTACT } from '@/lib/constants';
import { InstallBanner } from '@/components/pwa/InstallBanner';
import { OfflineIndicator } from '@/components/pwa/OfflineIndicator';

const iconMap: Record<string, React.ElementType> = {
  Sparkles, Brush, Home, Hammer, Sofa, PartyPopper,
};

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <OfflineIndicator />
      <Header />

      {/* Hero Section */}
      <section className="pt-24 pb-16 md:pt-32 md:pb-24 bg-gradient-soft">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-6 animate-fade-in">
              Encontre o{' '}
              <span className="text-gradient">profissional ideal</span>{' '}
              para cuidar da sua casa
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Conectamos você aos melhores diaristas da sua região. 
              Profissionais verificados, agendamento online e atendimento 7 dias por semana.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/profissionais">
                <Button size="lg" className="bg-secondary hover:bg-secondary/90 text-lg px-8">
                  <Search className="mr-2 h-5 w-5" />
                  Buscar Profissionais
                </Button>
              </Link>
              <Link to="/cadastro">
                <Button size="lg" variant="outline" className="text-lg px-8">
                  Sou Profissional
                </Button>
              </Link>
              <Link to="/admin">
                <Button size="lg" variant="ghost" className="text-lg px-8 gap-2">
                  <Shield className="h-5 w-5" />
                  Painel Admin
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { icon: Search, title: 'Busca Facilitada', desc: 'Encontre profissionais por proximidade, avaliação ou valor.' },
              { icon: Shield, title: 'Segurança', desc: 'Profissionais verificados com processo rigoroso de checagem.' },
              { icon: Calendar, title: 'Agendamento Online', desc: 'Programe o dia, hora e carga horária diretamente na plataforma.' },
            ].map((item) => (
              <Card key={item.title} className="border-0 shadow-soft hover:shadow-glow transition-shadow duration-300">
                <CardContent className="p-6 text-center">
                  <div className="w-14 h-14 rounded-2xl bg-accent flex items-center justify-center mx-auto mb-4">
                    <item.icon className="w-7 h-7 text-secondary" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">{item.title}</h3>
                  <p className="text-muted-foreground">{item.desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Services */}
      <section id="servicos" className="py-16 bg-muted/50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Nossos Serviços</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Serviços contratados por hora. Defina a carga horária e contrate o profissional ideal.
            </p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
            {SERVICES.map((service) => {
              const Icon = iconMap[service.icon] || Sparkles;
              return (
                <Card key={service.id} className="h-full border-0 shadow-soft hover:shadow-glow hover:-translate-y-1 transition-all duration-300 cursor-pointer">
                  <CardContent className="p-6 flex flex-col items-center text-center">
                    <div className="w-12 h-12 rounded-xl bg-secondary/10 flex items-center justify-center mb-4">
                      <Icon className="w-6 h-6 text-secondary" />
                    </div>
                    <h3 className="font-semibold">{service.label}</h3>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* How it Works */}
      <section id="como-funciona" className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Como Funciona</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              { step: '1', title: 'Busque', desc: 'Encontre profissionais na sua região' },
              { step: '2', title: 'Compare', desc: 'Veja avaliações, preços e serviços' },
              { step: '3', title: 'Agende', desc: 'Escolha data, hora e carga horária' },
              { step: '4', title: 'Confirme', desc: 'O profissional recebe e confirma' },
            ].map((item) => (
              <div key={item.step} className="text-center">
                <div className="w-16 h-16 rounded-full bg-primary text-primary-foreground flex items-center justify-center mx-auto mb-4 text-2xl font-bold">
                  {item.step}
                </div>
                <h3 className="text-lg font-semibold mb-2">{item.title}</h3>
                <p className="text-muted-foreground">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Pronto para começar?
          </h2>
          <p className="text-primary-foreground/80 mb-8 max-w-xl mx-auto">
            Junte-se a milhares de clientes satisfeitos ou cadastre-se como profissional.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/profissionais">
              <Button size="lg" className="bg-secondary hover:bg-secondary/90">
                Buscar Profissionais
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <a href={`https://wa.me/${CONTACT.whatsapp}`} target="_blank" rel="noopener noreferrer">
              <Button size="lg" variant="outline" className="border-primary-foreground text-primary-foreground hover:bg-primary-foreground/10">
                Falar no WhatsApp
              </Button>
            </a>
          </div>
        </div>
      </section>

      <Footer />
      <InstallBanner />
    </div>
  );
};

export default Index;
