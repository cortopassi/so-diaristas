import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { toast } from 'sonner';
import { Loader2, MapPin, CheckCircle2, ArrowRight, ArrowLeft, ExternalLink, DollarSign } from 'lucide-react';
import { formatCPF, validateCPF } from '@/lib/cpfValidator';
import { fetchCep, formatCep } from '@/lib/viaCep';
import { generateOTP } from '@/lib/otp';

const TOTAL_STEPS = 9;

const PIX_KEY_TYPES = [
  { value: 'cpf', label: 'CPF' },
  { value: 'email', label: 'Email' },
  { value: 'phone', label: 'Telefone' },
  { value: 'random', label: 'Chave Aleatória' },
];

const ANTECEDENTES_LINKS: Record<string, string> = {
  AC: 'https://www.tjac.jus.br/', AL: 'https://www.tjal.jus.br/', AP: 'https://www.tjap.jus.br/',
  AM: 'https://www.tjam.jus.br/', BA: 'https://www.tjba.jus.br/', CE: 'https://www.tjce.jus.br/',
  DF: 'https://www.tjdft.jus.br/', ES: 'https://www.tjes.jus.br/', GO: 'https://www.tjgo.jus.br/',
  MA: 'https://www.tjma.jus.br/', MT: 'https://www.tjmt.jus.br/', MS: 'https://www.tjms.jus.br/',
  MG: 'https://www.tjmg.jus.br/', PA: 'https://www.tjpa.jus.br/', PB: 'https://www.tjpb.jus.br/',
  PR: 'https://www.tjpr.jus.br/', PE: 'https://www.tjpe.jus.br/', PI: 'https://www.tjpi.jus.br/',
  RJ: 'https://www.tjrj.jus.br/', RN: 'https://www.tjrn.jus.br/', RS: 'https://www.tjrs.jus.br/',
  RO: 'https://www.tjro.jus.br/', RR: 'https://www.tjrr.jus.br/', SC: 'https://www.tjsc.jus.br/',
  SP: 'https://www.tjsp.jus.br/', SE: 'https://www.tjse.jus.br/', TO: 'https://www.tjto.jus.br/',
};

const DIAS_SEMANA = [
  { value: 1, label: 'Segunda' },
  { value: 2, label: 'Terça' },
  { value: 3, label: 'Quarta' },
  { value: 4, label: 'Quinta' },
  { value: 5, label: 'Sexta' },
  { value: 6, label: 'Sábado' },
  { value: 0, label: 'Domingo' },
];

interface DBCategory {
  id: string;
  name: string;
  description: string | null;
}

interface DBSubcategory {
  id: string;
  category_id: string;
  name: string;
}

interface DBService {
  id: string;
  name: string;
  description: string | null;
  category_id: string | null;
  subcategory_id: string | null;
  tag_api: string | null;
}

interface ServiceConfig {
  price: string;
  chargeType: 'hour' | 'period';
}

export default function CadastroProfissional() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [cepLoading, setCepLoading] = useState(false);
  const [otpCode, setOtpCode] = useState('');
  const [showOtp, setShowOtp] = useState(false);

  // DB services data
  const [dbCategories, setDbCategories] = useState<DBCategory[]>([]);
  const [dbSubcategories, setDbSubcategories] = useState<DBSubcategory[]>([]);
  const [dbServices, setDbServices] = useState<DBService[]>([]);
  const [servicesLoading, setServicesLoading] = useState(true);

  // Step 1: Dados Pessoais
  const [fullName, setFullName] = useState('');
  const [cpf, setCpf] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');

  // Step 2: Endereço
  const [cep, setCep] = useState('');
  const [rua, setRua] = useState('');
  const [numero, setNumero] = useState('');
  const [complemento, setComplemento] = useState('');
  const [bairro, setBairro] = useState('');
  const [cidade, setCidade] = useState('');
  const [estado, setEstado] = useState('');
  const [latitude, setLatitude] = useState<number | null>(null);
  const [longitude, setLongitude] = useState<number | null>(null);
  const [geoLoading, setGeoLoading] = useState(false);

  // Step 3: Documentação
  const [fotoFile, setFotoFile] = useState<File | null>(null);
  const [autorizaImagem, setAutorizaImagem] = useState(false);
  const [rgFrenteFile, setRgFrenteFile] = useState<File | null>(null);
  const [rgVersoFile, setRgVersoFile] = useState<File | null>(null);
  const [comprovanteFile, setComprovanteFile] = useState<File | null>(null);
  const [antecedentesFile, setAntecedentesFile] = useState<File | null>(null);

  // Step 4: PIX
  const [pixKeyType, setPixKeyType] = useState('');
  const [pixKey, setPixKey] = useState('');

  // Step 5: Termos
  const [termoAceite, setTermoAceite] = useState(false);

  // Step 6: Serviços (selected service UUIDs)
  const [selectedServices, setSelectedServices] = useState<string[]>([]);

  // Step 7: Per-service pricing (keyed by service UUID)
  const [serviceConfigs, setServiceConfigs] = useState<Record<string, ServiceConfig>>({});

  // Step 8: Disponibilidade
  const [disponibilidade, setDisponibilidade] = useState<Record<string, string[]>>({});

  // Fetch DB services using direct fetch (bypasses Supabase client hanging issue)
  const [servicesError, setServicesError] = useState('');
  const [servicesLoaded, setServicesLoaded] = useState(false);
  
  const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
  const SUPABASE_KEY = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;
  
  const fetchTable = async (table: string) => {
    const res = await fetch(
      `${SUPABASE_URL}/rest/v1/${table}?is_active=eq.true&order=name.asc`,
      {
        headers: {
          'apikey': SUPABASE_KEY,
          'Authorization': `Bearer ${SUPABASE_KEY}`,
        },
      }
    );
    if (!res.ok) throw new Error(`Erro ao carregar ${table}: ${res.statusText}`);
    return res.json();
  };

  useEffect(() => {
    if (step !== 6 || servicesLoaded) return;
    
    let cancelled = false;
    
    const doFetch = async () => {
      setServicesLoading(true);
      setServicesError('');
      
      try {
        const [cats, subcats, svcs] = await Promise.all([
          fetchTable('service_categories'),
          fetchTable('service_subcategories'),
          fetchTable('services'),
        ]);
        
        if (cancelled) return;
        
        setDbCategories(cats as DBCategory[]);
        setDbSubcategories(subcats as DBSubcategory[]);
        setDbServices(svcs as DBService[]);
        setServicesLoaded(true);
      } catch (err: any) {
        if (!cancelled) {
          console.error('Fetch services error:', err);
          setServicesError(err?.message || 'Erro ao carregar serviços.');
        }
      } finally {
        if (!cancelled) {
          setServicesLoading(false);
        }
      }
    };
    
    doFetch();
    
    return () => { cancelled = true; };
  }, [step, servicesLoaded]);
  
  const retryLoadServices = () => {
    setServicesLoaded(false);
  };

  const formatPhone = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    if (numbers.length <= 2) return numbers;
    if (numbers.length <= 7) return `(${numbers.slice(0, 2)}) ${numbers.slice(2)}`;
    return `(${numbers.slice(0, 2)}) ${numbers.slice(2, 7)}-${numbers.slice(7, 11)}`;
  };

  const handleCepChange = async (value: string) => {
    const formatted = formatCep(value);
    setCep(formatted);
    const clean = value.replace(/\D/g, '');
    if (clean.length === 8) {
      setCepLoading(true);
      const data = await fetchCep(clean);
      if (data) {
        setRua(data.logradouro);
        setBairro(data.bairro);
        setCidade(data.localidade);
        setEstado(data.uf);
      } else {
        toast.error('CEP não encontrado');
      }
      setCepLoading(false);
    }
  };

  const handleGeolocation = () => {
    if (!navigator.geolocation) {
      toast.error('Geolocalização não suportada');
      return;
    }
    setGeoLoading(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLatitude(pos.coords.latitude);
        setLongitude(pos.coords.longitude);
        setGeoLoading(false);
        toast.success('Localização capturada!');
      },
      () => {
        setGeoLoading(false);
        toast.error('Não foi possível obter a localização');
      }
    );
  };

  const toggleDisponibilidade = (dia: number, periodo: string) => {
    const key = dia.toString();
    setDisponibilidade(prev => {
      const current = prev[key] || [];
      if (current.includes(periodo)) {
        return { ...prev, [key]: current.filter(p => p !== periodo) };
      }
      return { ...prev, [key]: [...current, periodo] };
    });
  };

  const toggleService = (serviceId: string) => {
    setSelectedServices(prev => {
      if (prev.includes(serviceId)) {
        // Remove config
        setServiceConfigs(c => {
          const copy = { ...c };
          delete copy[serviceId];
          return copy;
        });
        return prev.filter(id => id !== serviceId);
      } else {
        // Initialize config if not exists
        setServiceConfigs(c => ({
          ...c,
          [serviceId]: c[serviceId] || { price: '', chargeType: 'hour' },
        }));
        return [...prev, serviceId];
      }
    });
  };

  const updateServiceConfig = (serviceId: string, field: keyof ServiceConfig, value: string) => {
    setServiceConfigs(prev => ({
      ...prev,
      [serviceId]: { ...prev[serviceId], [field]: value },
    }));
  };

  const validateCurrentStep = (): boolean => {
    switch (step) {
      case 1:
        if (!fullName.trim()) { toast.error('Nome é obrigatório'); return false; }
        if (!validateCPF(cpf)) { toast.error('CPF inválido'); return false; }
        if (!phone.trim()) { toast.error('Telefone é obrigatório'); return false; }
        if (!email.trim()) { toast.error('E-mail é obrigatório'); return false; }
        return true;
      case 2:
        if (!cep.trim() || !cidade.trim()) { toast.error('CEP e endereço são obrigatórios'); return false; }
        if (!numero.trim()) { toast.error('Número é obrigatório'); return false; }
        // Geolocalização é opcional - pode ser ativada depois
        return true;
      case 3:
        if (!autorizaImagem) { toast.error('Autorização de imagem é obrigatória'); return false; }
        // Foto e documentos podem ser enviados depois
        return true;
      case 4:
        if (!pixKeyType) { toast.error('Tipo de chave PIX é obrigatório'); return false; }
        if (!pixKey.trim()) { toast.error('Chave PIX é obrigatória'); return false; }
        return true;
      case 5:
        if (!termoAceite) { toast.error('Você precisa aceitar os termos'); return false; }
        return true;
      case 6:
        if (selectedServices.length === 0) { toast.error('Selecione pelo menos um serviço'); return false; }
        return true;
      case 7: {
        const selected = Array.from(selectedServices);
        for (const svcId of selected) {
          const config = serviceConfigs[svcId];
          if (!config?.price || parseFloat(config.price) <= 0) {
            const svc = dbServices.find(s => s.id === svcId);
            toast.error(`Defina o valor para: ${svc?.name || 'serviço'}`);
            return false;
          }
        }
        return true;
      }
      case 8: {
        const hasAny = Object.values(disponibilidade).some(v => v.length > 0);
        if (!hasAny) { toast.error('Defina pelo menos um horário disponível'); return false; }
        return true;
      }
      default:
        return true;
    }
  };

  const nextStep = () => {
    if (validateCurrentStep()) setStep(s => Math.min(s + 1, TOTAL_STEPS));
  };

  const prevStep = () => setStep(s => Math.max(s - 1, 1));

  const uploadFile = async (file: File, path: string): Promise<string | null> => {
    try {
      const { data, error } = await supabase.storage
        .from('professional-documents')
        .upload(path, file, { upsert: true });
      if (error) throw error;
      return data?.path || null;
    } catch (e) {
      console.error('[DEBUG] Upload failed:', e);
      return null;
    }
  };

  const handleFinalSubmit = async () => {
    if (!validateCurrentStep()) return;
    setLoading(true);

    try {
      // Build services data
      const selectedServiceNames = Array.from(selectedServices).map(svcId => {
        const svc = dbServices.find(s => s.id === svcId);
        return svc?.name || svcId;
      });

      const professionalServices = Array.from(selectedServices).map(svcId => {
        const config = serviceConfigs[svcId];
        return {
          service_id: svcId,
          charge_type: config.chargeType,
          price: config.price,
        };
      });

      // Call edge function that handles everything atomically
      // File uploads are skipped here - professional uploads docs later from their panel
      const res = await fetch(`${SUPABASE_URL}/functions/v1/register-professional`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${SUPABASE_KEY}`,
        },
        body: JSON.stringify({
          email,
          fullName,
          phone,
          cpf,
          cep,
          rua,
          numero,
          complemento,
          bairro,
          cidade,
          estado,
          latitude,
          longitude,
          pixKey,
          pixKeyType,
          autorizaImagem,
          fotoUrl: '',
          rgFrenteUrl: '',
          rgVersoUrl: '',
          comprovanteUrl: '',
          antecedentesUrl: '',
          selectedServiceNames,
          professionalServices,
        }),
      });

      let result: any;
      try {
        result = await res.json();
      } catch {
        result = { error: 'Resposta inválida do servidor' };
      }
      console.log('[DEBUG] Register result:', result);

      if (!res.ok) {
        if (result.code === 'cpf_exists' || result.code === 'email_exists') {
          toast.error('Você já possui um cadastro.', { description: 'Use a tela de login para acessar sua conta.' });
          setLoading(false);
          navigate('/login');
          return;
        }
        toast.error('Erro ao criar conta', { description: result.error || `Erro ${res.status}` });
        setLoading(false);
        return;
      }

      setOtpCode(result.otpCode);
      setShowOtp(true);
      setStep(TOTAL_STEPS);
      toast.success('Cadastro realizado com sucesso! Aguarde aprovação.');
    } catch (error: any) {
      console.error('[DEBUG] Erro no cadastro profissional:', error);
      toast.error('Erro ao criar conta', { description: error.message });
    } finally {
      setLoading(false);
    }
  };

  // Completion screen
  if (showOtp && step === TOTAL_STEPS) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/5 to-secondary/5 p-4">
        <Card className="w-full max-w-md text-center">
          <CardHeader>
            <CheckCircle2 className="h-16 w-16 text-secondary mx-auto mb-4" />
            <CardTitle>Cadastro Enviado!</CardTitle>
            <CardDescription>
              Seu perfil está <strong>EM ANÁLISE</strong>. Você será notificado após a aprovação.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-muted rounded-lg p-6">
              <p className="text-sm text-muted-foreground mb-2">Seu código de acesso:</p>
              <p className="text-4xl font-bold tracking-widest text-primary">{otpCode}</p>
              <p className="text-xs text-muted-foreground mt-2">Válido por 5 minutos</p>
            </div>
            <Button onClick={() => navigate('/login')} className="w-full">
              Ir para Login
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Helpers for step 6 DB-based rendering
  const getSubcatsForCategory = (catId: string) => dbSubcategories.filter(sc => sc.category_id === catId);
  const getServicesForSubcat = (subcatId: string) => dbServices.filter(s => s.subcategory_id === subcatId);
  const getDirectServices = (catId: string) => dbServices.filter(s => s.category_id === catId && !s.subcategory_id);

  const countSelectedInCategory = (catId: string) => {
    return dbServices.filter(s => s.category_id === catId && selectedServices.includes(s.id)).length;
  };

  // For step 8 availability periods
  const periodos = ['manha', 'tarde', 'noite'];
  const periodoLabels: Record<string, string> = {
    'manha': 'Manhã', 'tarde': 'Tarde', 'noite': 'Noite',
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-secondary/5 p-4 py-12">
      <div className="max-w-2xl mx-auto">
        {/* Progress */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium">Etapa {step} de {TOTAL_STEPS - 1}</span>
            <span className="text-sm text-muted-foreground">
              {Math.round((step / (TOTAL_STEPS - 1)) * 100)}%
            </span>
          </div>
          <div className="w-full bg-muted rounded-full h-2">
            <div
              className="bg-gradient-to-r from-primary to-secondary h-2 rounded-full transition-all duration-300"
              style={{ width: `${(step / (TOTAL_STEPS - 1)) * 100}%` }}
            />
          </div>
        </div>

        <Card>
          {/* STEP 1: Dados Pessoais */}
          {step === 1 && (
            <>
              <CardHeader>
                <CardTitle>1. Dados Pessoais</CardTitle>
                <CardDescription>Informações obrigatórias para seu cadastro</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Nome completo *</Label>
                  <Input value={fullName} onChange={(e) => setFullName(e.target.value)} placeholder="Maria da Silva" />
                </div>
                <div className="space-y-2">
                  <Label>CPF *</Label>
                  <Input value={cpf} onChange={(e) => setCpf(formatCPF(e.target.value))} placeholder="000.000.000-00" maxLength={14} />
                </div>
                <div className="space-y-2">
                  <Label>Telefone (WhatsApp) *</Label>
                  <Input value={phone} onChange={(e) => setPhone(formatPhone(e.target.value))} placeholder="(47) 99999-9999" maxLength={15} />
                </div>
                <div className="space-y-2">
                  <Label>E-mail *</Label>
                  <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="seu@email.com" />
                </div>
              </CardContent>
            </>
          )}

          {/* STEP 2: Endereço + Geo */}
          {step === 2 && (
            <>
              <CardHeader>
                <CardTitle>2. Endereço + Geolocalização</CardTitle>
                <CardDescription>Seu endereço completo e localização</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>CEP *</Label>
                  <div className="relative">
                    <Input value={cep} onChange={(e) => handleCepChange(e.target.value)} placeholder="00000-000" maxLength={9} />
                    {cepLoading && <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 animate-spin" />}
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Rua</Label>
                  <Input value={rua} readOnly className="bg-muted" />
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label>Número *</Label>
                    <Input value={numero} onChange={(e) => setNumero(e.target.value)} placeholder="123" />
                  </div>
                  <div className="space-y-2 col-span-2">
                    <Label>Complemento</Label>
                    <Input value={complemento} onChange={(e) => setComplemento(e.target.value)} placeholder="Apto 101" />
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2"><Label>Bairro</Label><Input value={bairro} readOnly className="bg-muted" /></div>
                  <div className="space-y-2"><Label>Cidade</Label><Input value={cidade} readOnly className="bg-muted" /></div>
                  <div className="space-y-2"><Label>Estado</Label><Input value={estado} readOnly className="bg-muted" /></div>
                </div>
                <Button
                  type="button"
                  variant={latitude ? 'secondary' : 'outline'}
                  onClick={handleGeolocation}
                  disabled={geoLoading}
                  className="w-full"
                >
                  {geoLoading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <MapPin className="h-4 w-4 mr-2" />}
                  {latitude ? '📍 Localização capturada!' : 'Ativar minha localização (opcional)'}
                </Button>
              </CardContent>
            </>
          )}

          {/* STEP 3: Documentação */}
          {step === 3 && (
            <>
              <CardHeader>
                <CardTitle>3. Documentação</CardTitle>
                <CardDescription>Envie seus documentos para verificação</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Foto de rosto *</Label>
                  <Input type="file" accept="image/*" onChange={(e) => setFotoFile(e.target.files?.[0] || null)} />
                  <div className="flex items-center space-x-2 mt-2">
                    <Checkbox id="autoriza" checked={autorizaImagem} onCheckedChange={(v) => setAutorizaImagem(v === true)} />
                    <label htmlFor="autoriza" className="text-sm">Autorizo a exibição da minha imagem no site *</label>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>RG frente (pode enviar depois)</Label>
                  <Input type="file" accept="image/*,.pdf" onChange={(e) => setRgFrenteFile(e.target.files?.[0] || null)} />
                </div>
                <div className="space-y-2">
                  <Label>RG verso (pode enviar depois)</Label>
                  <Input type="file" accept="image/*,.pdf" onChange={(e) => setRgVersoFile(e.target.files?.[0] || null)} />
                </div>
                <div className="space-y-2">
                  <Label>Comprovante de residência (pode enviar depois)</Label>
                  <Input type="file" accept="image/*,.pdf" onChange={(e) => setComprovanteFile(e.target.files?.[0] || null)} />
                </div>
                <div className="space-y-2">
                  <Label>Antecedentes criminais (pode enviar depois)</Label>
                  {estado && ANTECEDENTES_LINKS[estado] && (
                    <a
                      href={ANTECEDENTES_LINKS[estado]}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-1 text-sm text-primary hover:underline mb-2"
                    >
                      <ExternalLink className="h-3 w-3" />
                      Obter certidão no site do TJ-{estado}
                    </a>
                  )}
                  <Input type="file" accept=".pdf,image/*" onChange={(e) => setAntecedentesFile(e.target.files?.[0] || null)} />
                  <p className="text-xs text-muted-foreground">Baixe a certidão no site oficial e faça o upload aqui.</p>
                </div>
              </CardContent>
            </>
          )}

          {/* STEP 4: Chave PIX */}
          {step === 4 && (
            <>
              <CardHeader>
                <CardTitle>4. Chave PIX</CardTitle>
                <CardDescription>Configure seu recebimento</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Tipo de chave *</Label>
                  <Select value={pixKeyType} onValueChange={setPixKeyType}>
                    <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                    <SelectContent>
                      {PIX_KEY_TYPES.map(t => (
                        <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Chave PIX *</Label>
                  <Input value={pixKey} onChange={(e) => setPixKey(e.target.value)} placeholder="Sua chave PIX" />
                </div>
                <div className="bg-muted rounded-lg p-3 text-sm text-muted-foreground">
                  💰 Os pagamentos serão realizados via sistema Split Asaas com taxa de <strong>20%</strong> sobre o valor do serviço.
                </div>
              </CardContent>
            </>
          )}

          {/* STEP 5: Termos */}
          {step === 5 && (
            <>
              <CardHeader>
                <CardTitle>5. Termo de Aceite</CardTitle>
                <CardDescription>Leia e aceite os termos da plataforma</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="bg-muted rounded-lg p-4 text-sm space-y-2">
                  <p>Ao utilizar a plataforma Só Diaristas, você concorda que:</p>
                  <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                    <li>A plataforma retém <strong>20%</strong> sobre cada serviço realizado via sistema split Asaas.</li>
                    <li>Os pagamentos são processados automaticamente e 80% é transferido para sua chave PIX.</li>
                    <li>Seu perfil só será visível após aprovação documental pela equipe.</li>
                    <li>Você se compromete a manter seus documentos atualizados.</li>
                  </ul>
                </div>
                <div className="flex items-start space-x-2">
                  <Checkbox id="termos" checked={termoAceite} onCheckedChange={(v) => setTermoAceite(v === true)} />
                  <label htmlFor="termos" className="text-sm leading-tight">
                    Declaro estar ciente que a plataforma Só Diaristas retém 20% sobre cada serviço realizado via sistema split Asaas. *
                  </label>
                </div>
              </CardContent>
            </>
          )}

          {/* STEP 6: Serviços (from DB) */}
          {step === 6 && (
            <>
              <CardHeader>
                <CardTitle>6. Serviços</CardTitle>
                <CardDescription>
                  Selecione os serviços que você realiza ({selectedServices.length} selecionados)
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-1 max-h-[28rem] overflow-y-auto">
                {servicesLoading ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="h-6 w-6 animate-spin text-primary" />
                    <span className="ml-2 text-sm text-muted-foreground">Carregando serviços...</span>
                  </div>
                ) : servicesError ? (
                  <div className="text-center py-8 text-destructive">
                    <p className="text-sm">{servicesError}</p>
                    <Button variant="outline" size="sm" className="mt-2" onClick={retryLoadServices}>Tentar novamente</Button>
                  </div>
                ) : dbCategories.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <p className="text-sm">Nenhuma categoria de serviço disponível.</p>
                    <Button variant="outline" size="sm" className="mt-2" onClick={retryLoadServices}>Tentar novamente</Button>
                  </div>
                ) : (
                  <Accordion type="multiple" className="w-full">
                    {dbCategories.map(cat => {
                      const subcats = getSubcatsForCategory(cat.id);
                      const directSvcs = getDirectServices(cat.id);
                      const selectedCount = countSelectedInCategory(cat.id);

                      return (
                        <AccordionItem key={cat.id} value={cat.id}>
                          <AccordionTrigger className="text-sm font-semibold">
                            <span className="flex items-center gap-2">
                              {cat.name}
                              {selectedCount > 0 && (
                                <Badge variant="default" className="text-xs">{selectedCount}</Badge>
                              )}
                            </span>
                          </AccordionTrigger>
                          <AccordionContent>
                            <div className="space-y-1 pl-2">
                              {/* Direct services (no subcategory) */}
                              {directSvcs.map(svc => (
                                <div key={svc.id} className="flex items-center space-x-2 py-1">
                                  <Checkbox
                                    checked={selectedServices.includes(svc.id)}
                                    onCheckedChange={() => toggleService(svc.id)}
                                  />
                                  <label className="text-sm cursor-pointer" onClick={() => toggleService(svc.id)}>
                                    {svc.name}
                                  </label>
                                </div>
                              ))}

                              {/* Subcategories */}
                              {subcats.length > 0 && (
                                <Accordion type="multiple" className="w-full">
                                  {subcats.map(subcat => {
                                    const svcs = getServicesForSubcat(subcat.id);
                                    return (
                                      <AccordionItem key={subcat.id} value={subcat.id}>
                                        <AccordionTrigger className="text-xs font-medium text-muted-foreground py-2">
                                          {subcat.name}
                                        </AccordionTrigger>
                                        <AccordionContent>
                                          <div className="space-y-1 pl-3">
                                            {svcs.map(svc => (
                                              <div key={svc.id} className="flex items-center space-x-2 py-1">
                                                <Checkbox
                                                  checked={selectedServices.includes(svc.id)}
                                                  onCheckedChange={() => toggleService(svc.id)}
                                                />
                                                <label className="text-sm cursor-pointer" onClick={() => toggleService(svc.id)}>
                                                  {svc.name}
                                                </label>
                                              </div>
                                            ))}
                                          </div>
                                        </AccordionContent>
                                      </AccordionItem>
                                    );
                                  })}
                                </Accordion>
                              )}
                            </div>
                          </AccordionContent>
                        </AccordionItem>
                      );
                    })}
                  </Accordion>
                )}
              </CardContent>
            </>
          )}

          {/* STEP 7: Valor e tipo de cobrança POR SERVIÇO */}
          {step === 7 && (
            <>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5" />
                  7. Valores por Serviço
                </CardTitle>
                <CardDescription>
                  Defina o valor e tipo de cobrança para cada serviço selecionado
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4 max-h-[28rem] overflow-y-auto">
                {Array.from(selectedServices).map(svcId => {
                  const svc = dbServices.find(s => s.id === svcId);
                  const config = serviceConfigs[svcId] || { price: '', chargeType: 'hour' };
                  const cat = dbCategories.find(c => c.id === svc?.category_id);

                  return (
                    <div key={svcId} className="border rounded-lg p-4 space-y-3">
                      <div>
                        <p className="font-medium text-sm">{svc?.name}</p>
                        {cat && <p className="text-xs text-muted-foreground">{cat.name}</p>}
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-1">
                          <Label className="text-xs">Tipo de cobrança</Label>
                          <RadioGroup
                            value={config.chargeType}
                            onValueChange={(v) => updateServiceConfig(svcId, 'chargeType', v)}
                            className="flex gap-3"
                          >
                            <div className="flex items-center space-x-1">
                              <RadioGroupItem value="hour" id={`hour-${svcId}`} />
                              <Label htmlFor={`hour-${svcId}`} className="text-xs">Por hora</Label>
                            </div>
                            <div className="flex items-center space-x-1">
                              <RadioGroupItem value="period" id={`period-${svcId}`} />
                              <Label htmlFor={`period-${svcId}`} className="text-xs">Por período</Label>
                            </div>
                          </RadioGroup>
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs">
                            Valor (R$) {config.chargeType === 'hour' ? '/hora' : '/período'}
                          </Label>
                          <Input
                            type="number"
                            placeholder="0,00"
                            value={config.price}
                            onChange={(e) => updateServiceConfig(svcId, 'price', e.target.value)}
                            min="1"
                            className="h-9"
                          />
                        </div>
                      </div>
                    </div>
                  );
                })}
                {selectedServices.length === 0 && (
                  <p className="text-sm text-muted-foreground text-center py-8">
                    Nenhum serviço selecionado. Volte à etapa anterior.
                  </p>
                )}
              </CardContent>
            </>
          )}

          {/* STEP 8: Disponibilidade */}
          {step === 8 && (
            <>
              <CardHeader>
                <CardTitle>8. Disponibilidade</CardTitle>
                <CardDescription>Defina seus dias e horários de atendimento</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {DIAS_SEMANA.map(dia => (
                  <div key={dia.value} className="flex items-center gap-3 border rounded-lg p-3">
                    <span className="font-medium w-24 text-sm">{dia.label}</span>
                    <div className="flex gap-2 flex-wrap">
                      {periodos.map(periodo => (
                        <Badge
                          key={periodo}
                          variant={(disponibilidade[dia.value.toString()] || []).includes(periodo) ? 'default' : 'outline'}
                          className="cursor-pointer"
                          onClick={() => toggleDisponibilidade(dia.value, periodo)}
                        >
                          {periodoLabels[periodo]}
                        </Badge>
                      ))}
                    </div>
                  </div>
                ))}
              </CardContent>
            </>
          )}

          {/* Navigation */}
          <div className="flex justify-between p-6 pt-0">
            {step > 1 && (
              <Button variant="outline" onClick={prevStep}>
                <ArrowLeft className="h-4 w-4 mr-2" />
                Voltar
              </Button>
            )}
            <div className="ml-auto">
              {step < 8 ? (
                <Button onClick={nextStep}>
                  Próximo
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Button>
              ) : step === 8 ? (
                <Button onClick={handleFinalSubmit} disabled={loading}>
                  {loading && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                  Finalizar Cadastro
                </Button>
              ) : null}
            </div>
          </div>
        </Card>

        <p className="text-center text-sm text-muted-foreground mt-4">
          Já tem conta? <a href="/login" className="text-primary hover:underline">Entrar</a>
          {' · '}
          <a href="/cadastro-cliente" className="text-secondary hover:underline">Sou cliente</a>
        </p>
      </div>
    </div>
  );
}
