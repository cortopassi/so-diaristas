import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ReviewsList } from '@/components/reviews/ReviewsList';
import { Loader2, Star, MapPin, Clock, ArrowLeft, ShieldCheck, Zap, DollarSign } from 'lucide-react';

interface ProfService {
  id: string;
  price: number;
  charge_type: string;
  handles_emergency: boolean;
  service: { name: string } | null;
}

export default function PerfilProfissional() {
  const { id } = useParams<{ id: string }>();
  const [professional, setProfessional] = useState<any>(null);
  const [services, setServices] = useState<ProfService[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id) fetchData();
  }, [id]);

  const fetchData = async () => {
    try {
      const [profRes, svcRes] = await Promise.all([
        supabase.from('profiles').select('*').eq('id', id!).eq('role', 'professional').eq('is_active', true).single(),
        supabase.from('professional_services').select('id, price, charge_type, handles_emergency, service:services!professional_services_service_id_fkey(name)').eq('professional_id', id!).eq('is_active', true),
      ]);

      if (profRes.error) throw profRes.error;
      setProfessional(profRes.data);

      const svcData = (svcRes.data || []).map((s: any) => ({
        ...s,
        service: Array.isArray(s.service) ? s.service[0] : s.service,
      }));
      setServices(svcData as ProfService[]);
    } catch (error) {
      console.error('Erro ao buscar profissional:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!professional) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <Header />
        <main className="flex-1 container mx-auto px-4 py-8 pt-24">
          <Card>
            <CardContent className="py-12 text-center">
              <p className="text-muted-foreground mb-4">Profissional não encontrado</p>
              <Link to="/profissionais">
                <Button variant="outline"><ArrowLeft className="h-4 w-4 mr-2" />Voltar para busca</Button>
              </Link>
            </CardContent>
          </Card>
        </main>
        <Footer />
      </div>
    );
  }

  const lowestPrice = services.length > 0 ? Math.min(...services.map(s => s.price)) : null;

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      
      <main className="flex-1 container mx-auto px-4 py-8 pt-24">
        <Link to="/profissionais" className="inline-flex items-center text-muted-foreground hover:text-foreground mb-6">
          <ArrowLeft className="h-4 w-4 mr-2" /> Voltar para busca
        </Link>

        <div className="grid md:grid-cols-3 gap-8">
          <div className="md:col-span-2 space-y-6">
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col sm:flex-row gap-6">
                  <div className="flex-shrink-0">
                    <div className="w-24 h-24 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white text-3xl font-bold">
                      {professional.avatar_url ? (
                        <img src={professional.avatar_url} alt={professional.full_name} className="w-full h-full rounded-full object-cover" />
                      ) : professional.full_name.charAt(0)}
                    </div>
                  </div>

                  <div className="flex-1 space-y-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <h1 className="text-2xl font-bold">{professional.full_name}</h1>
                        {professional.verification_status === 'verified' && <ShieldCheck className="h-5 w-5 text-green-500" />}
                      </div>
                      {(professional.city || professional.neighborhood) && (
                        <p className="text-muted-foreground flex items-center gap-1 mt-1">
                          <MapPin className="h-4 w-4" />
                          {[professional.neighborhood, professional.city].filter(Boolean).join(', ')}
                        </p>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      <div className="flex gap-0.5">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Star key={star} className={`h-5 w-5 ${star <= Math.round(professional.average_rating || 0) ? 'fill-yellow-400 text-yellow-400' : 'text-muted-foreground/30'}`} />
                        ))}
                      </div>
                      <span className="font-semibold">{(professional.average_rating || 0).toFixed(1)}</span>
                      <span className="text-muted-foreground">({professional.total_reviews} avaliações)</span>
                    </div>
                  </div>
                </div>

                {professional.bio && (
                  <div className="mt-6 pt-6 border-t">
                    <h3 className="font-semibold mb-2">Sobre</h3>
                    <p className="text-muted-foreground">{professional.bio}</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Services from DB */}
            {services.length > 0 && (
              <Card>
                <CardContent className="pt-6">
                  <h3 className="font-semibold mb-4 flex items-center gap-2">
                    <DollarSign className="h-4 w-4" /> Serviços Oferecidos
                  </h3>
                  <div className="space-y-3">
                    {services.map(svc => (
                      <div key={svc.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{svc.service?.name || 'Serviço'}</span>
                          {svc.handles_emergency && (
                            <Badge variant="outline" className="text-xs text-orange-600 border-orange-300">
                              <Zap className="h-3 w-3 mr-0.5" /> Emergência
                            </Badge>
                          )}
                        </div>
                        <div className="text-right">
                          <span className="font-bold text-primary">R$ {svc.price.toFixed(2)}</span>
                          <span className="text-xs text-muted-foreground ml-1">/{svc.charge_type === 'hour' ? 'hora' : 'período'}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            <ReviewsList professionalId={professional.id} limit={20} />
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <Card className="sticky top-24">
              <CardContent className="pt-6 space-y-4">
                {lowestPrice !== null && (
                  <div className="text-center">
                    <p className="text-sm text-muted-foreground">A partir de</p>
                    <p className="text-3xl font-bold text-primary">R$ {lowestPrice.toFixed(2)}</p>
                    <p className="text-sm text-muted-foreground flex items-center justify-center gap-1">
                      <Clock className="h-4 w-4" /> por hora/período
                    </p>
                  </div>
                )}

                <Link to={`/agendar/${professional.id}`}>
                  <Button className="w-full" size="lg">Contratar Agora</Button>
                </Link>

                <p className="text-xs text-center text-muted-foreground">
                  Pagamento seguro via PIX
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
