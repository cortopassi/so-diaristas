import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2, LogOut } from 'lucide-react';
import { StatsCards } from '@/components/professional/StatsCards';
import { BookingsList } from '@/components/professional/BookingsList';
import { ProfileForm } from '@/components/professional/ProfileForm';
import { DocumentUpload } from '@/components/professional/DocumentUpload';
import { TermsAcceptance } from '@/components/professional/TermsAcceptance';
import { ServiceSelection } from '@/components/professional/ServiceSelection';
import { AvailabilityManager } from '@/components/professional/AvailabilityManager';
import { Booking } from '@/types/database';

export default function PainelProfissional() {
  const navigate = useNavigate();
  const { user, profile, loading: authLoading, signOut } = useAuth();
  const [pendingCount, setPendingCount] = useState(0);

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/login');
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (profile?.id) {
      fetchPendingCount();
    }
  }, [profile?.id]);

  const fetchPendingCount = async () => {
    if (!profile?.id) return;

    try {
      const { count } = await supabase
        .from('bookings')
        .select('*', { count: 'exact', head: true })
        .eq('professional_id', profile.id)
        .eq('status', 'pending');

      setPendingCount(count || 0);
    } catch (error) {
      console.error('Erro ao buscar contagem:', error);
    }
  };

  const handleSignOut = async () => {
    await signOut();
    window.location.href = '/';
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      
      <main className="flex-1 container mx-auto px-4 py-8 pt-24">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold">Olá, {profile?.full_name?.split(' ')[0]}! 👋</h1>
            <p className="text-muted-foreground">Gerencie seu perfil e agendamentos</p>
          </div>
          <Button variant="outline" onClick={handleSignOut}>
            <LogOut className="h-4 w-4 mr-2" />
            Sair
          </Button>
        </div>

        <StatsCards />

        <Tabs defaultValue="solicitacoes" className="space-y-6">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="solicitacoes" className="relative">
              Solicitações
              {pendingCount > 0 && (
                <span className="absolute -top-1 -right-1 h-5 w-5 rounded-full bg-destructive text-destructive-foreground text-xs flex items-center justify-center">
                  {pendingCount}
                </span>
              )}
            </TabsTrigger>
            <TabsTrigger value="historico">Histórico</TabsTrigger>
            <TabsTrigger value="servicos">Serviços</TabsTrigger>
            <TabsTrigger value="agenda">Agenda</TabsTrigger>
            <TabsTrigger value="documentos">Documentos</TabsTrigger>
            <TabsTrigger value="perfil">Meu Perfil</TabsTrigger>
          </TabsList>

          <TabsContent value="solicitacoes">
            <BookingsList type="pending" />
          </TabsContent>

          <TabsContent value="historico">
            <BookingsList type="history" />
          </TabsContent>

          <TabsContent value="servicos">
            <ServiceSelection />
          </TabsContent>

          <TabsContent value="agenda">
            <AvailabilityManager />
          </TabsContent>

          <TabsContent value="documentos" className="space-y-6">
            <TermsAcceptance />
            <DocumentUpload />
          </TabsContent>

          <TabsContent value="perfil">
            <ProfileForm />
          </TabsContent>
        </Tabs>
      </main>

      <Footer />
    </div>
  );
}
