import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { Loader2, Upload, FileText, CheckCircle, XCircle, Clock, AlertCircle } from 'lucide-react';
import { ProfessionalDocument, DocumentType, DocumentStatus } from '@/types/database';

const DOCUMENT_TYPES: { type: DocumentType; label: string; description: string }[] = [
  { type: 'rg', label: 'RG (Identidade)', description: 'Frente e verso do documento' },
  { type: 'cpf', label: 'CPF', description: 'Documento ou comprovante com CPF' },
  { type: 'address_proof', label: 'Comprovante de Endereço', description: 'Conta de luz, água ou telefone (últimos 3 meses)' },
  { type: 'criminal_record', label: 'Antecedentes Criminais', description: 'Certidão de antecedentes criminais' },
];

export function DocumentUpload() {
  const { user, profile } = useAuth();
  const [documents, setDocuments] = useState<ProfessionalDocument[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState<DocumentType | null>(null);

  useEffect(() => {
    if (profile?.id) {
      fetchDocuments();
    }
  }, [profile?.id]);

  const fetchDocuments = async () => {
    if (!profile?.id) return;

    try {
      const { data, error } = await supabase
        .from('professional_documents')
        .select('*')
        .eq('professional_id', profile.id);

      if (error) throw error;
      setDocuments((data || []) as ProfessionalDocument[]);
    } catch (error) {
      console.error('Erro ao buscar documentos:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleUpload = async (type: DocumentType, file: File) => {
    if (!user || !profile) return;

    setUploading(type);

    try {
      // Upload file to storage
      const fileExt = file.name.split('.').pop();
      const fileName = `${type}_${Date.now()}.${fileExt}`;
      const filePath = `${user.id}/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('professional-documents')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      // Get signed URL (defense in depth - bucket is private)
      const { data: signedUrlData, error: signedUrlError } = await supabase.storage
        .from('professional-documents')
        .createSignedUrl(filePath, 60 * 60 * 4); // 4 hours

      if (signedUrlError) throw signedUrlError;
      const fileUrl = signedUrlData.signedUrl;

      // Check if document already exists
      const existingDoc = documents.find(d => d.document_type === type);

      if (existingDoc) {
        // Update existing document
        const { error } = await supabase
          .from('professional_documents')
          .update({
            file_url: filePath,
            file_name: file.name,
            status: 'pending',
            rejection_reason: null,
          })
          .eq('id', existingDoc.id);

        if (error) throw error;
      } else {
        // Insert new document
        const { error } = await supabase
          .from('professional_documents')
          .insert({
            professional_id: profile.id,
            document_type: type,
            file_url: filePath,
            file_name: file.name,
            status: 'pending',
          });

        if (error) throw error;
      }

      toast.success('Documento enviado com sucesso!');
      fetchDocuments();
    } catch (error: any) {
      console.error('Erro ao enviar documento:', error);
      toast.error('Erro ao enviar documento: ' + error.message);
    } finally {
      setUploading(null);
    }
  };

  const getDocumentByType = (type: DocumentType) => {
    return documents.find(d => d.document_type === type);
  };

  const getStatusBadge = (status: DocumentStatus) => {
    const config = {
      pending: { label: 'Em análise', className: 'bg-yellow-500/10 text-yellow-600 border-yellow-500/20', icon: Clock },
      approved: { label: 'Aprovado', className: 'bg-green-500/10 text-green-600 border-green-500/20', icon: CheckCircle },
      rejected: { label: 'Rejeitado', className: 'bg-red-500/10 text-red-600 border-red-500/20', icon: XCircle },
    };
    const { label, className, icon: Icon } = config[status];
    return (
      <Badge variant="outline" className={className}>
        <Icon className="h-3 w-3 mr-1" />
        {label}
      </Badge>
    );
  };

  const getVerificationStatusInfo = () => {
    const status = (profile as any)?.verification_status || 'pending';
    const config: Record<string, { label: string; className: string; description: string }> = {
      pending: { 
        label: 'Pendente', 
        className: 'bg-yellow-500/10 text-yellow-600 border-yellow-500/20',
        description: 'Envie todos os documentos para verificação'
      },
      documents_submitted: { 
        label: 'Em Análise', 
        className: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
        description: 'Seus documentos estão sendo analisados'
      },
      verified: { 
        label: 'Verificado', 
        className: 'bg-green-500/10 text-green-600 border-green-500/20',
        description: 'Perfil verificado - você pode receber clientes!'
      },
      rejected: { 
        label: 'Rejeitado', 
        className: 'bg-red-500/10 text-red-600 border-red-500/20',
        description: 'Algum documento foi rejeitado. Verifique e reenvie.'
      },
    };
    return config[status] || config.pending;
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="py-8 flex justify-center">
          <Loader2 className="h-6 w-6 animate-spin text-primary" />
        </CardContent>
      </Card>
    );
  }

  const verificationInfo = getVerificationStatusInfo();

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Documentos e Verificação
            </CardTitle>
            <CardDescription>
              Envie seus documentos para liberar seu perfil para clientes
            </CardDescription>
          </div>
          <Badge variant="outline" className={verificationInfo.className}>
            {verificationInfo.label}
          </Badge>
        </div>
        <p className="text-sm text-muted-foreground mt-2">
          {verificationInfo.description}
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        {DOCUMENT_TYPES.map(({ type, label, description }) => {
          const doc = getDocumentByType(type);
          const isUploading = uploading === type;

          return (
            <div key={type} className="border rounded-lg p-4 space-y-3">
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-medium">{label}</p>
                  <p className="text-sm text-muted-foreground">{description}</p>
                </div>
                {doc && getStatusBadge(doc.status)}
              </div>

              {doc?.rejection_reason && (
                <div className="flex items-start gap-2 p-3 bg-red-500/10 rounded-lg">
                  <AlertCircle className="h-4 w-4 text-red-600 mt-0.5" />
                  <p className="text-sm text-red-600">{doc.rejection_reason}</p>
                </div>
              )}

              {doc && doc.status !== 'rejected' ? (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <FileText className="h-4 w-4" />
                  <span>{doc.file_name}</span>
                </div>
              ) : (
                <div className="space-y-2">
                  <Label htmlFor={`file-${type}`} className="sr-only">
                    Upload {label}
                  </Label>
                  <div className="flex gap-2">
                    <Input
                      id={`file-${type}`}
                      type="file"
                      accept="image/*,.pdf"
                      disabled={isUploading}
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          if (file.size > 5 * 1024 * 1024) {
                            toast.error('Arquivo muito grande. Máximo 5MB.');
                            return;
                          }
                          handleUpload(type, file);
                        }
                      }}
                      className="flex-1"
                    />
                    {isUploading && <Loader2 className="h-5 w-5 animate-spin" />}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Formatos aceitos: JPG, PNG, PDF. Máximo 5MB.
                  </p>
                </div>
              )}
            </div>
          );
        })}

        <div className="pt-4 border-t">
          <div className="flex items-start gap-3 p-4 bg-primary/5 rounded-lg">
            <AlertCircle className="h-5 w-5 text-primary mt-0.5" />
            <div className="text-sm">
              <p className="font-medium">Importante</p>
              <ul className="list-disc list-inside text-muted-foreground mt-1 space-y-1">
                <li>Todos os documentos são obrigatórios para ativar seu perfil</li>
                <li>Seus dados são protegidos e usados apenas para verificação</li>
                <li>A análise pode levar até 48 horas úteis</li>
              </ul>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
