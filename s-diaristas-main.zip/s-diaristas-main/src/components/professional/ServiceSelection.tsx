import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { toast } from 'sonner';
import { Loader2, Briefcase, DollarSign, Zap, Check } from 'lucide-react';

interface Category {
  id: string;
  name: string;
  description: string | null;
}

interface Subcategory {
  id: string;
  category_id: string;
  name: string;
}

interface Service {
  id: string;
  name: string;
  description: string | null;
  category_id: string | null;
  subcategory_id: string | null;
  tag_api: string | null;
}

interface ProfessionalService {
  id: string;
  service_id: string;
  charge_type: string;
  price: number;
  handles_emergency: boolean;
  is_active: boolean;
  custom_description: string | null;
}

export function ServiceSelection() {
  const { profile } = useAuth();
  const [categories, setCategories] = useState<Category[]>([]);
  const [subcategories, setSubcategories] = useState<Subcategory[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [myServices, setMyServices] = useState<ProfessionalService[]>([]);
  const [loading, setLoading] = useState(true);

  // Modal state
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [chargeType, setChargeType] = useState<string>('hour');
  const [price, setPrice] = useState('');
  const [emergency, setEmergency] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetchData();
  }, [profile?.id]);

  const fetchData = async () => {
    if (!profile?.id) return;
    const [catsRes, subcatsRes, svcsRes, myRes] = await Promise.all([
      supabase.from('service_categories').select('*').eq('is_active', true).order('name'),
      supabase.from('service_subcategories').select('*').eq('is_active', true).order('name'),
      supabase.from('services').select('*').eq('is_active', true).order('name'),
      supabase.from('professional_services').select('*').eq('professional_id', profile.id),
    ]);
    setCategories((catsRes.data || []) as Category[]);
    setSubcategories((subcatsRes.data || []) as Subcategory[]);
    setServices((svcsRes.data || []) as Service[]);
    setMyServices((myRes.data || []) as ProfessionalService[]);
    setLoading(false);
  };

  const getMyService = (serviceId: string) => myServices.find(ms => ms.service_id === serviceId);

  const openServiceModal = (svc: Service) => {
    const existing = getMyService(svc.id);
    setSelectedService(svc);
    setChargeType(existing?.charge_type || 'hour');
    setPrice(existing?.price?.toString() || '');
    setEmergency(existing?.handles_emergency || false);
    setModalOpen(true);
  };

  const saveService = async () => {
    if (!selectedService || !profile?.id || !price) return;
    setSaving(true);
    try {
      const existing = getMyService(selectedService.id);
      const data = {
        professional_id: profile.id,
        service_id: selectedService.id,
        charge_type: chargeType,
        price: parseFloat(price),
        handles_emergency: emergency,
        is_active: true,
      };

      if (existing) {
        await supabase.from('professional_services').update(data).eq('id', existing.id);
      } else {
        await supabase.from('professional_services').insert(data);
      }
      toast.success('Serviço salvo com sucesso!');
      setModalOpen(false);
      fetchData();
    } catch (err) {
      toast.error('Erro ao salvar serviço');
    } finally {
      setSaving(false);
    }
  };

  const toggleServiceActive = async (profServiceId: string, currentActive: boolean) => {
    await supabase.from('professional_services').update({ is_active: !currentActive }).eq('id', profServiceId);
    fetchData();
  };

  const removeService = async (profServiceId: string) => {
    await supabase.from('professional_services').delete().eq('id', profServiceId);
    toast.success('Serviço removido');
    fetchData();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  const getSubcatsForCategory = (catId: string) => subcategories.filter(sc => sc.category_id === catId);
  const getServicesForSubcat = (subcatId: string) => services.filter(s => s.subcategory_id === subcatId);
  // Services without subcategory directly under category
  const getDirectServices = (catId: string) => services.filter(s => s.category_id === catId && !s.subcategory_id);

  const activeCount = myServices.filter(ms => ms.is_active).length;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Briefcase className="h-5 w-5" />
            Meus Serviços
          </CardTitle>
          <CardDescription>
            Selecione os serviços que você oferece e defina seus preços.
            Você tem <strong>{activeCount}</strong> serviço{activeCount !== 1 ? 's' : ''} ativo{activeCount !== 1 ? 's' : ''}.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Accordion type="multiple" className="w-full">
            {categories.map(cat => (
              <AccordionItem key={cat.id} value={cat.id}>
                <AccordionTrigger className="text-base font-semibold">
                  {cat.name}
                  {myServices.some(ms => {
                    const svc = services.find(s => s.id === ms.service_id);
                    return svc?.category_id === cat.id && ms.is_active;
                  }) && (
                    <Badge variant="default" className="ml-2">
                      {myServices.filter(ms => {
                        const svc = services.find(s => s.id === ms.service_id);
                        return svc?.category_id === cat.id && ms.is_active;
                      }).length} ativo(s)
                    </Badge>
                  )}
                </AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-4 pl-2">
                    {/* Direct services */}
                    {getDirectServices(cat.id).map(svc => (
                      <ServiceRow
                        key={svc.id}
                        service={svc}
                        myService={getMyService(svc.id)}
                        onSelect={() => openServiceModal(svc)}
                        onToggle={(id, active) => toggleServiceActive(id, active)}
                        onRemove={removeService}
                      />
                    ))}

                    {/* Subcategories */}
                    <Accordion type="multiple" className="w-full">
                      {getSubcatsForCategory(cat.id).map(subcat => (
                        <AccordionItem key={subcat.id} value={subcat.id}>
                          <AccordionTrigger className="text-sm font-medium text-muted-foreground">
                            {subcat.name}
                          </AccordionTrigger>
                          <AccordionContent>
                            <div className="space-y-3 pl-2">
                              {getServicesForSubcat(subcat.id).map(svc => (
                                <ServiceRow
                                  key={svc.id}
                                  service={svc}
                                  myService={getMyService(svc.id)}
                                  onSelect={() => openServiceModal(svc)}
                                  onToggle={(id, active) => toggleServiceActive(id, active)}
                                  onRemove={removeService}
                                />
                              ))}
                            </div>
                          </AccordionContent>
                        </AccordionItem>
                      ))}
                    </Accordion>
                  </div>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </CardContent>
      </Card>

      {/* Modal de configuração do serviço */}
      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Configurar Serviço</DialogTitle>
          </DialogHeader>
          {selectedService && (
            <div className="space-y-4">
              <p className="font-medium">{selectedService.name}</p>
              {selectedService.description && (
                <p className="text-sm text-muted-foreground">{selectedService.description}</p>
              )}

              <div className="space-y-3">
                <Label>Tipo de cobrança</Label>
                <RadioGroup value={chargeType} onValueChange={setChargeType}>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="hour" id="hour" />
                    <Label htmlFor="hour">Por hora</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="period" id="period" />
                    <Label htmlFor="period">Por período (diária/visita)</Label>
                  </div>
                </RadioGroup>
              </div>

              <div className="space-y-2">
                <Label>Valor (R$)</Label>
                <Input
                  type="number"
                  placeholder={chargeType === 'hour' ? 'Valor por hora' : 'Valor por período'}
                  value={price}
                  onChange={e => setPrice(e.target.value)}
                  min="1"
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label>Atende emergência?</Label>
                  <p className="text-xs text-muted-foreground">Disponível para atendimentos urgentes</p>
                </div>
                <Switch checked={emergency} onCheckedChange={setEmergency} />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setModalOpen(false)}>Cancelar</Button>
            <Button onClick={saveService} disabled={saving || !price}>
              {saving ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <Check className="h-4 w-4 mr-1" />}
              Salvar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function ServiceRow({
  service,
  myService,
  onSelect,
  onToggle,
  onRemove,
}: {
  service: Service;
  myService?: ProfessionalService;
  onSelect: () => void;
  onToggle: (id: string, active: boolean) => void;
  onRemove: (id: string) => void;
}) {
  return (
    <div className="flex items-center justify-between py-2 px-3 rounded-lg border bg-card hover:bg-accent/50 transition-colors">
      <div className="flex items-center gap-3">
        {myService ? (
          <div className={`w-2 h-2 rounded-full ${myService.is_active ? 'bg-green-500' : 'bg-muted-foreground'}`} />
        ) : (
          <Checkbox checked={false} onCheckedChange={() => onSelect()} />
        )}
        <div>
          <p className="text-sm font-medium">{service.name}</p>
          {myService && (
            <div className="flex items-center gap-2 mt-0.5">
              <Badge variant="secondary" className="text-xs">
                <DollarSign className="h-3 w-3 mr-0.5" />
                R$ {myService.price.toFixed(2)}/{myService.charge_type === 'hour' ? 'h' : 'período'}
              </Badge>
              {myService.handles_emergency && (
                <Badge variant="outline" className="text-xs text-orange-600 border-orange-300">
                  <Zap className="h-3 w-3 mr-0.5" /> Emergência
                </Badge>
              )}
            </div>
          )}
        </div>
      </div>
      {myService && (
        <div className="flex items-center gap-2">
          <Switch
            checked={myService.is_active}
            onCheckedChange={() => onToggle(myService.id, myService.is_active)}
          />
          <Button size="sm" variant="ghost" onClick={() => onSelect()}>
            Editar
          </Button>
        </div>
      )}
    </div>
  );
}
