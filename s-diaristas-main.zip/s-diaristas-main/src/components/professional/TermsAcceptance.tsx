import { useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { ScrollArea } from '@/components/ui/scroll-area';
import { toast } from 'sonner';
import { Loader2, FileCheck, CheckCircle } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export function TermsAcceptance() {
  const { profile, updateProfile } = useAuth();
  const [accepted, setAccepted] = useState(false);
  const [saving, setSaving] = useState(false);

  const termsAcceptedAt = (profile as any)?.terms_accepted_at;

  const handleAcceptTerms = async () => {
    if (!accepted) {
      toast.error('Você precisa aceitar os termos para continuar');
      return;
    }

    setSaving(true);
    try {
      const { error } = await updateProfile({
        // @ts-ignore
        terms_accepted_at: new Date().toISOString(),
      });

      if (error) throw error;
      toast.success('Termos aceitos com sucesso!');
    } catch (error) {
      toast.error('Erro ao aceitar termos');
      console.error(error);
    } finally {
      setSaving(false);
    }
  };

  if (termsAcceptedAt) {
    return (
      <Card className="border-green-500/30">
        <CardContent className="pt-6">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-green-500/10">
              <CheckCircle className="h-5 w-5 text-green-600" />
            </div>
            <div>
              <p className="font-medium">Termos aceitos</p>
              <p className="text-sm text-muted-foreground">
                Você aceitou os termos em {format(new Date(termsAcceptedAt), "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-yellow-500/30">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileCheck className="h-5 w-5" />
          Termos de Uso e Condições
        </CardTitle>
        <CardDescription>
          Leia e aceite os termos para começar a atender
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <ScrollArea className="h-64 border rounded-lg p-4">
          <div className="space-y-4 text-sm">
            <h3 className="font-semibold">1. Cadastro e Verificação</h3>
            <p className="text-muted-foreground">
              Ao se cadastrar como profissional na plataforma Só Diaristas, você concorda em fornecer 
              informações verdadeiras e atualizadas, incluindo documentos pessoais e certidão de 
              antecedentes criminais. A verificação de antecedentes é obrigatória para ativação do perfil.
            </p>

            <h3 className="font-semibold">2. Taxa de Serviço</h3>
            <p className="text-muted-foreground">
              A plataforma Só Diaristas retém automaticamente uma taxa de <strong>15% (quinze por cento)</strong> sobre 
              o valor total de cada serviço realizado. Os <strong>85% restantes</strong> serão transferidos para 
              sua conta via PIX após a confirmação do serviço pelo cliente.
            </p>

            <h3 className="font-semibold">3. Responsabilidades do Profissional</h3>
            <ul className="list-disc list-inside text-muted-foreground space-y-1">
              <li>Manter seu calendário de disponibilidade atualizado</li>
              <li>Comparecer aos serviços agendados pontualmente</li>
              <li>Prestar serviços com qualidade e profissionalismo</li>
              <li>Manter comunicação respeitosa com os clientes</li>
              <li>Zelar pelos pertences e propriedade do cliente</li>
            </ul>

            <h3 className="font-semibold">4. Cancelamentos</h3>
            <p className="text-muted-foreground">
              Cancelamentos devem ser comunicados com no mínimo 24 horas de antecedência. 
              Cancelamentos frequentes ou sem justificativa podem resultar em suspensão da conta.
            </p>

            <h3 className="font-semibold">5. Pagamentos</h3>
            <p className="text-muted-foreground">
              O pagamento é processado através da plataforma. Você receberá automaticamente via PIX 
              após o cliente confirmar a conclusão do serviço. É obrigatório manter sua chave PIX 
              atualizada no sistema.
            </p>

            <h3 className="font-semibold">6. Privacidade e Dados</h3>
            <p className="text-muted-foreground">
              As informações do cliente (endereço, telefone) só serão liberadas após o pagamento 
              e confirmação da contratação. Você se compromete a usar esses dados apenas para 
              a prestação do serviço.
            </p>

            <h3 className="font-semibold">7. Avaliações</h3>
            <p className="text-muted-foreground">
              Após cada serviço, os clientes poderão avaliar seu trabalho. Mantenha um padrão 
              de qualidade para garantir boas avaliações e mais oportunidades.
            </p>
          </div>
        </ScrollArea>

        <div className="flex items-start space-x-3 pt-2">
          <Checkbox
            id="accept-terms"
            checked={accepted}
            onCheckedChange={(checked) => setAccepted(checked === true)}
          />
          <Label htmlFor="accept-terms" className="text-sm leading-relaxed cursor-pointer">
            Li e aceito os Termos de Uso, a Política de Privacidade e concordo com a 
            <strong> taxa de 15%</strong> sobre os serviços realizados.
          </Label>
        </div>

        <Button onClick={handleAcceptTerms} disabled={!accepted || saving} className="w-full">
          {saving ? (
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
          ) : (
            <FileCheck className="h-4 w-4 mr-2" />
          )}
          Aceitar Termos e Continuar
        </Button>
      </CardContent>
    </Card>
  );
}
