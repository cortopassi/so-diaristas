import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { Loader2, Save, DollarSign } from 'lucide-react';

const SERVICES = [
  'Limpeza Residencial',
  'Limpeza Comercial',
  'Passadoria',
  'Cozinha',
  'Organização',
  'Pós-obra',
];

const PIX_KEY_TYPES = [
  { value: 'cpf', label: 'CPF' },
  { value: 'cnpj', label: 'CNPJ' },
  { value: 'email', label: 'Email' },
  { value: 'phone', label: 'Telefone' },
  { value: 'random', label: 'Chave Aleatória' },
];

export function ProfileForm() {
  const { profile, updateProfile } = useAuth();
  const [saving, setSaving] = useState(false);

  // Form state
  const [bio, setBio] = useState('');
  const [hourlyRate, setHourlyRate] = useState('');
  const [city, setCity] = useState('');
  const [neighborhood, setNeighborhood] = useState('');
  const [servicesOffered, setServicesOffered] = useState<string[]>([]);
  const [pixKey, setPixKey] = useState('');
  const [pixKeyType, setPixKeyType] = useState('');

  useEffect(() => {
    if (profile) {
      setBio(profile.bio || '');
      setHourlyRate(profile.hourly_rate?.toString() || '');
      setCity(profile.city || '');
      setNeighborhood(profile.neighborhood || '');
      setServicesOffered(profile.services_offered || []);
      setPixKey((profile as any).pix_key || '');
      setPixKeyType((profile as any).pix_key_type || '');
    }
  }, [profile]);

  const handleSaveProfile = async () => {
    setSaving(true);
    try {
      const { error } = await updateProfile({
        bio,
        hourly_rate: hourlyRate ? parseFloat(hourlyRate) : null,
        city,
        neighborhood,
        services_offered: servicesOffered,
        // @ts-ignore
        pix_key: pixKey,
        pix_key_type: pixKeyType,
      });

      if (error) throw error;
      toast.success('Perfil atualizado com sucesso!');
    } catch (error) {
      toast.error('Erro ao salvar perfil');
      console.error(error);
    } finally {
      setSaving(false);
    }
  };

  const toggleService = (service: string) => {
    setServicesOffered(prev =>
      prev.includes(service)
        ? prev.filter(s => s !== service)
        : [...prev, service]
    );
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Informações Profissionais</CardTitle>
          <CardDescription>
            Complete seu perfil para atrair mais clientes
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label>Sobre você (habilidades e experiência)</Label>
            <Textarea
              placeholder="Conte sobre sua experiência, habilidades e diferenciais. Ex: Tenho 5 anos de experiência com limpeza residencial, sou organizada e pontual..."
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              rows={4}
            />
            <p className="text-xs text-muted-foreground">
              Descreva suas habilidades e atribuições para que os clientes conheçam seu trabalho
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Valor por hora (R$)</Label>
              <Input
                type="number"
                placeholder="50"
                value={hourlyRate}
                onChange={(e) => setHourlyRate(e.target.value)}
              />
              <p className="text-xs text-muted-foreground">
                Defina o valor que você cobra por hora de trabalho
              </p>
            </div>
            <div className="space-y-2">
              <Label>Cidade</Label>
              <Input
                placeholder="São Paulo"
                value={city}
                onChange={(e) => setCity(e.target.value)}
              />
            </div>
            <div className="space-y-2 md:col-span-2">
              <Label>Bairro</Label>
              <Input
                placeholder="Centro"
                value={neighborhood}
                onChange={(e) => setNeighborhood(e.target.value)}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Serviços oferecidos</Label>
            <div className="flex flex-wrap gap-2">
              {SERVICES.map(service => (
                <Badge
                  key={service}
                  variant={servicesOffered.includes(service) ? 'default' : 'outline'}
                  className="cursor-pointer"
                  onClick={() => toggleService(service)}
                >
                  {service}
                </Badge>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="border-secondary/30">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="h-5 w-5 text-secondary" />
            Configuração PIX
          </CardTitle>
          <CardDescription>
            Configure sua chave PIX para receber os pagamentos automaticamente (85% do valor)
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Tipo da chave</Label>
              <Select value={pixKeyType} onValueChange={setPixKeyType}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o tipo" />
                </SelectTrigger>
                <SelectContent>
                  {PIX_KEY_TYPES.map(type => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Chave PIX</Label>
              <Input
                placeholder={
                  pixKeyType === 'cpf' ? '000.000.000-00' :
                  pixKeyType === 'email' ? 'seu@email.com' :
                  pixKeyType === 'phone' ? '(11) 99999-9999' :
                  'Sua chave PIX'
                }
                value={pixKey}
                onChange={(e) => setPixKey(e.target.value)}
              />
            </div>
          </div>
          <p className="text-xs text-muted-foreground">
            💡 Quando um cliente pagar, 85% será transferido automaticamente para esta chave.
          </p>
        </CardContent>
      </Card>

      <Button onClick={handleSaveProfile} disabled={saving} className="w-full md:w-auto">
        {saving ? (
          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
        ) : (
          <Save className="h-4 w-4 mr-2" />
        )}
        Salvar alterações
      </Button>
    </div>
  );
}
