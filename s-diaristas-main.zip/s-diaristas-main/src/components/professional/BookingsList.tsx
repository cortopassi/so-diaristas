import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { Loader2, CheckCircle, XCircle, Clock, MapPin } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Booking } from '@/types/database';

interface BookingsListProps {
  type: 'pending' | 'history';
}

export function BookingsList({ type }: BookingsListProps) {
  const { profile } = useAuth();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (profile?.id) {
      fetchBookings();
    }
  }, [profile?.id]);

  const fetchBookings = async () => {
    if (!profile?.id) return;

    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('professional_id', profile.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setBookings((data || []) as Booking[]);
    } catch (error) {
      console.error('Erro ao buscar agendamentos:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleBookingAction = async (bookingId: string, action: 'confirmed' | 'cancelled') => {
    try {
      const { error } = await supabase
        .from('bookings')
        .update({ status: action })
        .eq('id', bookingId);

      if (error) throw error;

      toast.success(action === 'confirmed' ? 'Serviço aceito!' : 'Serviço recusado');
      fetchBookings();
    } catch (error) {
      toast.error('Erro ao atualizar agendamento');
      console.error(error);
    }
  };

  const getStatusBadge = (status: string) => {
    const config = {
      pending: { label: 'Pendente', className: 'bg-yellow-500/10 text-yellow-600 border-yellow-500/20' },
      confirmed: { label: 'Confirmado', className: 'bg-green-500/10 text-green-600 border-green-500/20' },
      completed: { label: 'Concluído', className: 'bg-blue-500/10 text-blue-600 border-blue-500/20' },
      cancelled: { label: 'Cancelado', className: 'bg-red-500/10 text-red-600 border-red-500/20' },
    };
    const { label, className } = config[status as keyof typeof config] || config.pending;
    return <Badge variant="outline" className={className}>{label}</Badge>;
  };

  const filteredBookings = type === 'pending' 
    ? bookings.filter(b => b.status === 'pending')
    : bookings.filter(b => b.status !== 'pending');

  if (loading) {
    return (
      <Card>
        <CardContent className="py-12 flex justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </CardContent>
      </Card>
    );
  }

  if (filteredBookings.length === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center">
          <Clock className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
          <p className="text-muted-foreground">
            {type === 'pending' ? 'Nenhuma solicitação pendente' : 'Nenhum agendamento no histórico'}
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {filteredBookings.map(booking => (
        <Card key={booking.id} className={type === 'pending' ? 'border-yellow-500/30' : ''}>
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Badge variant="secondary">{booking.service_type}</Badge>
                  {getStatusBadge(booking.status)}
                </div>
                <p className="font-medium">
                  {format(new Date(booking.scheduled_date), "dd 'de' MMMM", { locale: ptBR })} às {booking.scheduled_time.slice(0, 5)}
                </p>
                <p className="text-sm text-muted-foreground flex items-center gap-1">
                  <MapPin className="h-3 w-3" />
                  {booking.address}
                </p>
                <p className="text-sm text-muted-foreground">
                  {booking.hours}h de serviço • <span className="font-semibold text-foreground">R$ {booking.total_amount.toFixed(2)}</span>
                </p>
                {booking.notes && (
                  <p className="text-sm text-muted-foreground italic">"{booking.notes}"</p>
                )}
              </div>
              {type === 'pending' && (
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    className="border-red-500/30 text-red-600 hover:bg-red-500/10"
                    onClick={() => handleBookingAction(booking.id, 'cancelled')}
                  >
                    <XCircle className="h-4 w-4 mr-2" />
                    Recusar
                  </Button>
                  <Button
                    className="bg-green-600 hover:bg-green-700"
                    onClick={() => handleBookingAction(booking.id, 'confirmed')}
                  >
                    <CheckCircle className="h-4 w-4 mr-2" />
                    Aceitar
                  </Button>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
