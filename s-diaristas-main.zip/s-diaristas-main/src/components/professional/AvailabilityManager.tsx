import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { toast } from 'sonner';
import { Loader2, Clock, Save } from 'lucide-react';

const DAYS = [
  { value: 1, label: 'Segunda-feira' },
  { value: 2, label: 'Terça-feira' },
  { value: 3, label: 'Quarta-feira' },
  { value: 4, label: 'Quinta-feira' },
  { value: 5, label: 'Sexta-feira' },
  { value: 6, label: 'Sábado' },
  { value: 0, label: 'Domingo' },
];

interface Availability {
  id?: string;
  day_of_week: number;
  start_time: string;
  end_time: string;
  is_active: boolean;
}

export function AvailabilityManager() {
  const { profile } = useAuth();
  const [schedule, setSchedule] = useState<Map<number, Availability>>(new Map());
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (profile?.id) fetchAvailability();
  }, [profile?.id]);

  const fetchAvailability = async () => {
    const { data } = await supabase
      .from('professional_availability')
      .select('*')
      .eq('professional_id', profile!.id);

    const map = new Map<number, Availability>();
    DAYS.forEach(d => {
      const existing = (data || []).find((a: any) => a.day_of_week === d.value);
      map.set(d.value, existing ? {
        id: existing.id,
        day_of_week: existing.day_of_week,
        start_time: existing.start_time,
        end_time: existing.end_time,
        is_active: existing.is_active,
      } : {
        day_of_week: d.value,
        start_time: '08:00',
        end_time: '18:00',
        is_active: false,
      });
    });
    setSchedule(map);
    setLoading(false);
  };

  const updateDay = (day: number, field: string, value: any) => {
    setSchedule(prev => {
      const newMap = new Map(prev);
      const current = newMap.get(day)!;
      newMap.set(day, { ...current, [field]: value });
      return newMap;
    });
  };

  const saveSchedule = async () => {
    if (!profile?.id) return;
    setSaving(true);
    try {
      for (const [, avail] of schedule) {
        if (avail.id) {
          await supabase.from('professional_availability')
            .update({ start_time: avail.start_time, end_time: avail.end_time, is_active: avail.is_active })
            .eq('id', avail.id);
        } else if (avail.is_active) {
          await supabase.from('professional_availability').insert({
            professional_id: profile.id,
            day_of_week: avail.day_of_week,
            start_time: avail.start_time,
            end_time: avail.end_time,
            is_active: true,
          });
        }
      }
      toast.success('Agenda salva com sucesso!');
      fetchAvailability();
    } catch {
      toast.error('Erro ao salvar agenda');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <div className="flex justify-center py-8"><Loader2 className="h-6 w-6 animate-spin text-primary" /></div>;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Clock className="h-5 w-5" />
          Disponibilidade Semanal
        </CardTitle>
        <CardDescription>Defina os dias e horários em que você está disponível para trabalhar.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {DAYS.map(day => {
          const avail = schedule.get(day.value)!;
          return (
            <div key={day.value} className="flex items-center gap-3 py-2 px-3 rounded-lg border">
              <Switch checked={avail.is_active} onCheckedChange={v => updateDay(day.value, 'is_active', v)} />
              <span className={`w-32 text-sm font-medium ${!avail.is_active ? 'text-muted-foreground' : ''}`}>
                {day.label}
              </span>
              {avail.is_active && (
                <div className="flex items-center gap-2">
                  <Input
                    type="time"
                    value={avail.start_time}
                    onChange={e => updateDay(day.value, 'start_time', e.target.value)}
                    className="w-28"
                  />
                  <span className="text-muted-foreground text-sm">até</span>
                  <Input
                    type="time"
                    value={avail.end_time}
                    onChange={e => updateDay(day.value, 'end_time', e.target.value)}
                    className="w-28"
                  />
                </div>
              )}
            </div>
          );
        })}
        <Button onClick={saveSchedule} disabled={saving} className="w-full mt-4">
          {saving ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Save className="h-4 w-4 mr-2" />}
          Salvar Agenda
        </Button>
      </CardContent>
    </Card>
  );
}
