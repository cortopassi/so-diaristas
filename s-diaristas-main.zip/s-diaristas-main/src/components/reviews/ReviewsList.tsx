import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent } from '@/components/ui/card';
import { Star, User } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Skeleton } from '@/components/ui/skeleton';

interface Review {
  id: string;
  rating: number;
  comment: string | null;
  created_at: string;
  client: {
    full_name: string;
    avatar_url: string | null;
  } | null;
}

interface ReviewsListProps {
  professionalId: string;
  limit?: number;
  showTitle?: boolean;
}

export function ReviewsList({ professionalId, limit = 10, showTitle = true }: ReviewsListProps) {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchReviews();
  }, [professionalId]);

  const fetchReviews = async () => {
    try {
      // Buscar reviews
      const { data: reviewsData, error: reviewsError } = await supabase
        .from('reviews')
        .select('id, rating, comment, created_at, client_id')
        .eq('professional_id', professionalId)
        .order('created_at', { ascending: false })
        .limit(limit);

      if (reviewsError) throw reviewsError;

      // Buscar perfis dos clientes
      const clientIds = [...new Set(reviewsData?.map(r => r.client_id) || [])];
      
      let clientsMap: Record<string, { full_name: string; avatar_url: string | null }> = {};
      if (clientIds.length > 0) {
        const { data: clientsData } = await supabase
          .from('profiles')
          .select('user_id, full_name, avatar_url')
          .in('user_id', clientIds);

        clientsData?.forEach(c => {
          clientsMap[c.user_id] = { full_name: c.full_name, avatar_url: c.avatar_url };
        });
      }

      const formattedReviews: Review[] = (reviewsData || []).map(r => ({
        id: r.id,
        rating: r.rating,
        comment: r.comment,
        created_at: r.created_at,
        client: clientsMap[r.client_id] || null,
      }));

      setReviews(formattedReviews);
    } catch (error) {
      console.error('Erro ao buscar avaliações:', error);
    } finally {
      setLoading(false);
    }
  };

  const renderStars = (rating: number) => {
    return (
      <div className="flex gap-0.5">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`h-4 w-4 ${
              star <= rating
                ? 'fill-yellow-400 text-yellow-400'
                : 'text-muted-foreground/30'
            }`}
          />
        ))}
      </div>
    );
  };

  if (loading) {
    return (
      <div className="space-y-4">
        {showTitle && <h3 className="font-semibold text-lg">Avaliações</h3>}
        {[1, 2, 3].map((i) => (
          <Card key={i}>
            <CardContent className="pt-4">
              <div className="flex gap-3">
                <Skeleton className="h-10 w-10 rounded-full" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-3 w-20" />
                  <Skeleton className="h-12 w-full" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (reviews.length === 0) {
    return (
      <div className="space-y-4">
        {showTitle && <h3 className="font-semibold text-lg">Avaliações</h3>}
        <Card>
          <CardContent className="py-8 text-center">
            <Star className="h-12 w-12 mx-auto text-muted-foreground/30 mb-3" />
            <p className="text-muted-foreground">Nenhuma avaliação ainda</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {showTitle && (
        <h3 className="font-semibold text-lg">
          Avaliações ({reviews.length})
        </h3>
      )}
      {reviews.map((review) => (
        <Card key={review.id}>
          <CardContent className="pt-4">
            <div className="flex gap-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center flex-shrink-0">
                {review.client?.avatar_url ? (
                  <img
                    src={review.client.avatar_url}
                    alt={review.client.full_name}
                    className="w-full h-full rounded-full object-cover"
                  />
                ) : (
                  <User className="h-5 w-5 text-muted-foreground" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="font-medium truncate">
                      {review.client?.full_name || 'Cliente'}
                    </p>
                    {renderStars(review.rating)}
                  </div>
                  <span className="text-xs text-muted-foreground whitespace-nowrap">
                    {format(new Date(review.created_at), "dd 'de' MMM", { locale: ptBR })}
                  </span>
                </div>
                {review.comment && (
                  <p className="text-sm text-muted-foreground mt-2">
                    {review.comment}
                  </p>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
