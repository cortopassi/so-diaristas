import { Link } from 'react-router-dom';
import { Instagram, Facebook, Phone, Mail, MapPin } from 'lucide-react';
import { CONTACT } from '@/lib/constants';
import logoSoDiaristas from '@/assets/logo-so-diaristas.jpeg';

export function Footer() {
  return (
    <footer className="bg-primary text-primary-foreground py-16">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <img src={logoSoDiaristas} alt="Só Diaristas" className="h-10 w-auto rounded-lg brightness-110" />
            </div>
            <p className="text-primary-foreground/80">
              Conectamos você aos melhores profissionais de limpeza da sua região.
            </p>
          </div>

          {/* Links */}
          <div className="space-y-4">
            <h4 className="font-semibold text-lg">Links Rápidos</h4>
            <nav className="flex flex-col gap-2">
              <Link to="/profissionais" className="text-primary-foreground/80 hover:text-primary-foreground transition-colors">
                Buscar Profissionais
              </Link>
              <Link to="/cadastro" className="text-primary-foreground/80 hover:text-primary-foreground transition-colors">
                Seja um Profissional
              </Link>
              <a href="#como-funciona" className="text-primary-foreground/80 hover:text-primary-foreground transition-colors">
                Como Funciona
              </a>
            </nav>
          </div>

          {/* Contact */}
          <div className="space-y-4">
            <h4 className="font-semibold text-lg">Contato</h4>
            <div className="space-y-3 text-primary-foreground/80">
              <a href={`tel:${CONTACT.phone}`} className="flex items-center gap-2 hover:text-primary-foreground transition-colors">
                <Phone className="w-4 h-4" />
                {CONTACT.phone}
              </a>
              <a href={`mailto:${CONTACT.email}`} className="flex items-center gap-2 hover:text-primary-foreground transition-colors">
                <Mail className="w-4 h-4" />
                {CONTACT.email}
              </a>
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 mt-1 flex-shrink-0" />
                <span className="text-sm">{CONTACT.address}</span>
              </div>
            </div>
          </div>

          {/* Social */}
          <div className="space-y-4">
            <h4 className="font-semibold text-lg">Redes Sociais</h4>
            <div className="flex gap-4">
              <a
                href={CONTACT.instagram}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-primary-foreground/10 flex items-center justify-center hover:bg-secondary transition-colors"
              >
                <Instagram className="w-5 h-5" />
              </a>
              <a
                href={CONTACT.facebook}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-primary-foreground/10 flex items-center justify-center hover:bg-secondary transition-colors"
              >
                <Facebook className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-primary-foreground/20 mt-12 pt-8 text-center text-primary-foreground/60">
          <p>&copy; {new Date().getFullYear()} Só Diaristas. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  );
}
