import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Menu, X, Shield } from 'lucide-react';
import logoSoDiaristas from '@/assets/logo-so-diaristas.jpeg';
import { useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useAdmin } from '@/hooks/useAdmin';
import { NotificationBell } from '@/components/notifications/NotificationBell';

export function Header() {
  const [isOpen, setIsOpen] = useState(false);
  const { user, profile } = useAuth();
  const { isAdmin } = useAdmin();

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-lg border-b border-border">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center gap-2">
            <img src={logoSoDiaristas} alt="Só Diaristas" className="h-10 w-auto rounded-lg" />
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-6">
            <a href="#servicos" className="text-muted-foreground hover:text-foreground transition-colors">
              Serviços
            </a>
            <a href="#como-funciona" className="text-muted-foreground hover:text-foreground transition-colors">
              Como Funciona
            </a>
            <a href="#depoimentos" className="text-muted-foreground hover:text-foreground transition-colors">
              Depoimentos
            </a>
            <Link to="/profissionais">
              <Button variant="outline">Buscar Profissionais</Button>
            </Link>
            {user ? (
              <>
                <NotificationBell />
                {isAdmin && (
                  <Link to="/admin">
                    <Button variant="ghost" size="sm" className="text-muted-foreground">
                      <Shield className="h-4 w-4" />
                    </Button>
                  </Link>
                )}
                <Link to={profile?.role === 'professional' ? '/painel-profissional' : '/painel-cliente'}>
                  <Button className="bg-secondary hover:bg-secondary/90">Meu Painel</Button>
                </Link>
              </>
            ) : (
              <Link to="/login">
                <Button className="bg-secondary hover:bg-secondary/90">Entrar</Button>
              </Link>
            )}
          </nav>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2"
            onClick={() => setIsOpen(!isOpen)}
            aria-label="Toggle menu"
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Nav */}
        {isOpen && (
          <nav className="md:hidden py-4 border-t border-border flex flex-col gap-4">
            <a href="#servicos" className="text-muted-foreground hover:text-foreground transition-colors">
              Serviços
            </a>
            <a href="#como-funciona" className="text-muted-foreground hover:text-foreground transition-colors">
              Como Funciona
            </a>
            <a href="#depoimentos" className="text-muted-foreground hover:text-foreground transition-colors">
              Depoimentos
            </a>
            <Link to="/profissionais">
              <Button variant="outline" className="w-full">Buscar Profissionais</Button>
            </Link>
            {user ? (
              <>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">Notificações:</span>
                  <NotificationBell />
                </div>
                {isAdmin && (
                  <Link to="/admin">
                    <Button variant="outline" className="w-full">
                      <Shield className="h-4 w-4 mr-2" />
                      Admin
                    </Button>
                  </Link>
                )}
                <Link to={profile?.role === 'professional' ? '/painel-profissional' : '/painel-cliente'}>
                  <Button className="w-full bg-secondary hover:bg-secondary/90">Meu Painel</Button>
                </Link>
              </>
            ) : (
              <Link to="/login">
                <Button className="w-full bg-secondary hover:bg-secondary/90">Entrar</Button>
              </Link>
            )}
          </nav>
        )}
      </div>
    </header>
  );
}
