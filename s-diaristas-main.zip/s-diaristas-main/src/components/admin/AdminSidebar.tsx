import {
  LayoutDashboard, Users, UserCheck, Layers, Calendar, DollarSign, Shield, MapPin, Bell, UserCog, Home, LogOut
} from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { NavLink } from '@/components/NavLink';
import {
  Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent, SidebarGroupLabel,
  SidebarMenu, SidebarMenuButton, SidebarMenuItem,
} from '@/components/ui/sidebar';
import { useAdmin } from '@/hooks/useAdmin';
import { supabase } from '@/integrations/supabase/client';
import logo from '@/assets/logo-so-diaristas.jpeg';
import { Button } from '@/components/ui/button';

const menuItems = [
  { title: 'Dashboard', url: '/admin', icon: LayoutDashboard, roles: [] as string[] },
  { title: 'Profissionais', url: '/admin/profissionais', icon: UserCheck, roles: [] },
  { title: 'Clientes', url: '/admin/clientes', icon: Users, roles: [] },
  { title: 'Serviços', url: '/admin/servicos', icon: Layers, roles: ['super_admin', 'operator'] },
  { title: 'Agendamentos', url: '/admin/agendamentos', icon: Calendar, roles: [] },
  { title: 'Financeiro', url: '/admin/financeiro', icon: DollarSign, roles: ['super_admin', 'financial'] },
  { title: 'Gestores', url: '/admin/gestores', icon: UserCog, roles: ['super_admin'] },
  { title: 'Segurança', url: '/admin/seguranca', icon: Shield, roles: ['super_admin'] },
  { title: 'Cidades', url: '/admin/cidades', icon: MapPin, roles: ['super_admin', 'operator'] },
  { title: 'Alertas', url: '/admin/alertas', icon: Bell, roles: [] },
];

export function AdminSidebar() {
  const { roles, isSuperAdmin } = useAdmin();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await supabase.auth.signOut();
    sessionStorage.removeItem('admin_authenticated');
    window.location.href = '/admin/login';
  };

  const visibleItems = menuItems.filter(item =>
    item.roles.length === 0 || isSuperAdmin || item.roles.some(r => roles.includes(r as any))
  );

  return (
    <Sidebar className="border-r">
      <SidebarContent className="flex flex-col h-full">
        {/* Logo + Voltar ao site */}
        <div className="p-4 border-b">
          <Link to="/" className="flex items-center gap-3 group">
            <img src={logo} alt="Só Diaristas" className="h-10 w-10 rounded-lg object-cover" />
            <div className="flex flex-col">
              <span className="text-sm font-bold text-foreground">Só Diaristas</span>
              <span className="text-xs text-muted-foreground group-hover:text-primary flex items-center gap-1">
                <Home className="h-3 w-3" /> Voltar ao site
              </span>
            </div>
          </Link>
        </div>

        <SidebarGroup>
          <SidebarGroupLabel className="text-xs uppercase tracking-wider font-bold">
            Painel Admin
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {visibleItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild>
                    <NavLink
                      to={item.url}
                      end={item.url === '/admin'}
                      className="flex items-center gap-3 px-3 py-2 rounded-md hover:bg-muted/50 text-muted-foreground"
                      activeClassName="bg-primary/10 text-primary font-medium"
                    >
                      <item.icon className="h-4 w-4" />
                      <span>{item.title}</span>
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {/* Logout button - fixed at bottom */}
        <div className="mt-auto p-4 border-t">
          <button
            type="button"
            onClick={() => {
              supabase.auth.signOut().then(() => {
                sessionStorage.removeItem('admin_authenticated');
                window.location.href = '/admin/login';
              });
            }}
            className="w-full flex items-center gap-3 px-3 py-2 rounded-md text-sm text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors"
          >
            <LogOut className="h-4 w-4" />
            Sair do Painel
          </button>
        </div>
      </SidebarContent>
    </Sidebar>
  );
}
