import { ReactNode, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { SidebarProvider, SidebarTrigger } from '@/components/ui/sidebar';
import { AdminSidebar } from './AdminSidebar';
import { Loader2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

interface AdminLayoutProps {
  children: ReactNode;
  requiredRole?: 'super_admin' | 'operator' | 'financial' | 'support';
}

export function AdminLayout({ children }: AdminLayoutProps) {
  const navigate = useNavigate();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkAuth = async () => {
      const adminAuth = sessionStorage.getItem('admin_authenticated');
      if (adminAuth !== 'true') {
        navigate('/admin/login');
        setLoading(false);
        return;
      }

      // Also verify there's a valid Supabase session (required for RLS)
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        console.warn('[AdminLayout] sessionStorage set but no Supabase session — redirecting to login');
        sessionStorage.removeItem('admin_authenticated');
        navigate('/admin/login');
        setLoading(false);
        return;
      }

      // Verify the user has an admin role
      const { data: roles } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', session.user.id);

      if (!roles || roles.length === 0) {
        console.warn('[AdminLayout] User has no admin roles');
        sessionStorage.removeItem('admin_authenticated');
        await supabase.auth.signOut();
        navigate('/admin/login');
        setLoading(false);
        return;
      }

      setIsAuthenticated(true);
      setLoading(false);
    };

    checkAuth();
  }, [navigate]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!isAuthenticated) return null;

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full">
        <AdminSidebar />
        <main className="flex-1 overflow-auto">
          <header className="sticky top-0 z-10 flex items-center h-14 border-b bg-background px-4">
            <SidebarTrigger />
            <h1 className="ml-4 text-lg font-semibold">Admin - SÓ Diaristas</h1>
          </header>
          <div className="p-6">
            {children}
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}
