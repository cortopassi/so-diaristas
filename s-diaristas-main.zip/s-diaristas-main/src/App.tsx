import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/hooks/useAuth";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import Install from "./pages/Install";
import LoginOTP from "./pages/LoginOTP";
import Cadastro from "./pages/Cadastro";
import CadastroCliente from "./pages/CadastroCliente";
import CadastroProfissional from "./pages/CadastroProfissional";
import PainelProfissional from "./pages/PainelProfissional";
import PainelCliente from "./pages/PainelCliente";
import PerfilProfissional from "./pages/PerfilProfissional";
import Profissionais from "./pages/Profissionais";
import BuscarServicos from "./pages/BuscarServicos";
import Agendar from "./pages/Agendar";
import AdminDashboard from "./pages/admin/AdminDashboard";
import AdminProfissionais from "./pages/admin/AdminProfissionais";
import AdminProfissionalDetail from "./pages/admin/AdminProfissionalDetail";
import AdminClientes from "./pages/admin/AdminClientes";
import AdminClienteDetail from "./pages/admin/AdminClienteDetail";
import AdminServicos from "./pages/admin/AdminServicos";
import AdminAgendamentos from "./pages/admin/AdminAgendamentos";
import AdminFinanceiro from "./pages/admin/AdminFinanceiro";
import AdminSeguranca from "./pages/admin/AdminSeguranca";
import AdminCidades from "./pages/admin/AdminCidades";
import AdminAlertas from "./pages/admin/AdminAlertas";
import AdminGestores from "./pages/admin/AdminGestores";
import AdminLogin from "./pages/admin/AdminLogin";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/install" element={<Install />} />
            <Route path="/login" element={<LoginOTP />} />
            <Route path="/cadastro" element={<Cadastro />} />
            <Route path="/cadastro-cliente" element={<CadastroCliente />} />
            <Route path="/cadastro-profissional" element={<CadastroProfissional />} />
            <Route path="/painel-profissional" element={<PainelProfissional />} />
            <Route path="/painel-cliente" element={<PainelCliente />} />
            <Route path="/profissional/:id" element={<PerfilProfissional />} />
            <Route path="/profissionais" element={<Profissionais />} />
            <Route path="/servicos" element={<BuscarServicos />} />
            <Route path="/agendar/:id" element={<Agendar />} />
            {/* Admin Routes */}
            <Route path="/admin/login" element={<AdminLogin />} />
            <Route path="/admin" element={<AdminDashboard />} />
            <Route path="/admin/profissionais" element={<AdminProfissionais />} />
            <Route path="/admin/profissional/:id" element={<AdminProfissionalDetail />} />
            <Route path="/admin/clientes" element={<AdminClientes />} />
            <Route path="/admin/cliente/:id" element={<AdminClienteDetail />} />
            <Route path="/admin/servicos" element={<AdminServicos />} />
            <Route path="/admin/agendamentos" element={<AdminAgendamentos />} />
            <Route path="/admin/financeiro" element={<AdminFinanceiro />} />
            <Route path="/admin/gestores" element={<AdminGestores />} />
            <Route path="/admin/seguranca" element={<AdminSeguranca />} />
            <Route path="/admin/cidades" element={<AdminCidades />} />
            <Route path="/admin/alertas" element={<AdminAlertas />} />
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
