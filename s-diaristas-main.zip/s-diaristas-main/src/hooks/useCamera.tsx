import { useState, useCallback, useRef } from 'react';

interface CameraState {
  photo: string | null;
  loading: boolean;
  error: string | null;
}

export function useCamera() {
  const [state, setState] = useState<CameraState>({
    photo: null,
    loading: false,
    error: null,
  });
  
  const inputRef = useRef<HTMLInputElement | null>(null);

  const capturePhoto = useCallback(() => {
    if (!inputRef.current) {
      // Create input element for camera
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = 'image/*';
      input.capture = 'environment'; // Use rear camera
      inputRef.current = input;

      input.addEventListener('change', (e) => {
        const target = e.target as HTMLInputElement;
        const file = target.files?.[0];
        
        if (file) {
          setState(prev => ({ ...prev, loading: true, error: null }));
          
          const reader = new FileReader();
          reader.onload = () => {
            setState({
              photo: reader.result as string,
              loading: false,
              error: null,
            });
          };
          reader.onerror = () => {
            setState(prev => ({
              ...prev,
              loading: false,
              error: 'Erro ao ler a imagem',
            }));
          };
          reader.readAsDataURL(file);
        }
      });
    }

    inputRef.current.click();
  }, []);

  const selectFromGallery = useCallback(() => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.multiple = false;

    input.addEventListener('change', (e) => {
      const target = e.target as HTMLInputElement;
      const file = target.files?.[0];
      
      if (file) {
        setState(prev => ({ ...prev, loading: true, error: null }));
        
        const reader = new FileReader();
        reader.onload = () => {
          setState({
            photo: reader.result as string,
            loading: false,
            error: null,
          });
        };
        reader.onerror = () => {
          setState(prev => ({
            ...prev,
            loading: false,
            error: 'Erro ao ler a imagem',
          }));
        };
        reader.readAsDataURL(file);
      }
    });

    input.click();
  }, []);

  const clearPhoto = useCallback(() => {
    setState({
      photo: null,
      loading: false,
      error: null,
    });
  }, []);

  const clearError = useCallback(() => {
    setState(prev => ({ ...prev, error: null }));
  }, []);

  return {
    ...state,
    capturePhoto,
    selectFromGallery,
    clearPhoto,
    clearError,
    isSupported: 'mediaDevices' in navigator || 'capture' in document.createElement('input'),
  };
}
