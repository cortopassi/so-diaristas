import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';

export type AdminRole = 'super_admin' | 'operator' | 'financial' | 'support';

export function useAdmin() {
  const { user } = useAuth();
  const [roles, setRoles] = useState<AdminRole[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    if (!user) {
      setRoles([]);
      setIsAdmin(false);
      setLoading(false);
      return;
    }

    const fetchRoles = async () => {
      const { data, error } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', user.id);

      if (!error && data) {
        const userRoles = data.map((r: any) => r.role as AdminRole);
        setRoles(userRoles);
        setIsAdmin(userRoles.length > 0);
      }
      setLoading(false);
    };

    fetchRoles();
  }, [user]);

  const hasRole = (role: AdminRole) => roles.includes(role);
  const isSuperAdmin = hasRole('super_admin');
  const isOperator = hasRole('operator') || isSuperAdmin;
  const isFinancial = hasRole('financial') || isSuperAdmin;
  const isSupport = hasRole('support') || isSuperAdmin;

  const logAction = async (action: string, targetType?: string, targetId?: string, details?: Record<string, any>) => {
    if (!user) return;
    await supabase.from('admin_logs').insert({
      admin_user_id: user.id,
      action,
      target_type: targetType,
      target_id: targetId,
      details,
    });
  };

  return { roles, loading, isAdmin, isSuperAdmin, isOperator, isFinancial, isSupport, hasRole, logAction };
}
