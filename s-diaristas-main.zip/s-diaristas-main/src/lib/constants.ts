export const SERVICES = [
  { id: 'limpeza-padrao', label: 'Limpeza Padrão', icon: 'Sparkles' },
  { id: 'limpeza-pesada', label: 'Limpeza Pesada', icon: 'Brush' },
  { id: 'limpeza-pos-aluguel', label: 'Limpeza Pós Aluguel', icon: 'Home' },
  { id: 'limpeza-pos-obra', label: 'Limpeza Pós Obra', icon: 'Hammer' },
  { id: 'higienizacao-estofados', label: 'Higienização de Estofados', icon: 'Sofa' },
  { id: 'salao-festas', label: 'Salão de Festas', icon: 'PartyPopper' },
] as const;

export const CITIES = [
  'Jaraguá do Sul',
  'Joinville',
  'Blumenau',
  'Florianópolis',
  'Curitiba',
  'São Paulo',
] as const;

export const CONTACT = {
  phone: '(47) 99173-9141',
  whatsapp: '5547991739141',
  email: 'sodiaristas@sodiaristas.com.br',
  address: 'Rua João Pomianowiski 147, sala 01, Chico de Paula, Jaraguá do Sul, SC - CEP 89254-810',
  instagram: 'https://www.instagram.com/sodiaristas/',
  facebook: 'https://www.facebook.com/sodiaristasjaraguadosul',
} as const;

export const PLANS = [
  {
    id: 'start',
    name: 'Start',
    price: 9.90,
    features: [
      'Perfil básico na plataforma',
      'Até 5 agendamentos/mês',
      'Suporte via chat',
      'Visibilidade na busca',
    ],
    highlighted: false,
  },
  {
    id: 'gold',
    name: 'Gold',
    price: 19.90,
    features: [
      'Perfil destacado',
      'Até 20 agendamentos/mês',
      'Suporte prioritário',
      'Destaque nas buscas',
      'Estatísticas de visualização',
      'Selo verificado',
    ],
    highlighted: true,
  },
  {
    id: 'prime',
    name: 'Prime',
    price: 49.90,
    features: [
      'Perfil premium',
      'Agendamentos ilimitados',
      'Suporte 24/7',
      'Topo das buscas',
      'Analytics completo',
      'Selo verificado premium',
      'Destaque na home',
      'Divulgação nas redes sociais',
    ],
    highlighted: false,
  },
] as const;
