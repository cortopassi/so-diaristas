export interface ServiceItem {
  id: string;
  categoria: string;
  subcategoria: string;
  nome: string;
  descricao?: string;
  tag_api?: string;
}

export const SERVICE_CATALOG: ServiceItem[] = [
  // CATEGORIA 1: LIMPEZA E HIGIENIZAÇÃO
  { id: 'limp-res-faxina-padrao', categoria: 'Limpeza e Higienização', subcategoria: 'Limpeza Residencial', nome: 'Faxina Padrão (Manutenção/Dia a dia)' },
  { id: 'limp-res-faxina-pesada', categoria: 'Limpeza e Higienização', subcategoria: 'Limpeza Residencial', nome: 'Faxina Pesada (Faxinão/Limpeza Profunda)' },
  { id: 'limp-res-pre-pos-mudanca', categoria: 'Limpeza e Higienização', subcategoria: 'Limpeza Residencial', nome: 'Limpeza Pré/Pós Mudança (Imóvel vazio)' },
  { id: 'limp-res-pos-obra', categoria: 'Limpeza e Higienização', subcategoria: 'Limpeza Residencial', nome: 'Limpeza Pós-Obra (Remoção de resíduos finos)' },
  { id: 'limp-res-passadoria', categoria: 'Limpeza e Higienização', subcategoria: 'Limpeza Residencial', nome: 'Passadoria de Roupas (Passadeira)' },

  { id: 'limp-com-escritorios', categoria: 'Limpeza e Higienização', subcategoria: 'Limpeza Comercial & Corporativa', nome: 'Limpeza de Escritórios e Consultórios' },
  { id: 'limp-com-condominios', categoria: 'Limpeza e Higienização', subcategoria: 'Limpeza Comercial & Corporativa', nome: 'Limpeza de Condomínios (Áreas comuns/Hall)' },
  { id: 'limp-com-vitrines', categoria: 'Limpeza e Higienização', subcategoria: 'Limpeza Comercial & Corporativa', nome: 'Limpeza de Vitrines e Fachadas Baixas' },
  { id: 'limp-com-escolas', categoria: 'Limpeza e Higienização', subcategoria: 'Limpeza Comercial & Corporativa', nome: 'Limpeza de Escolas e Academias' },

  { id: 'limp-hig-sofas', categoria: 'Limpeza e Higienização', subcategoria: 'Higienização Especializada (Estofados/Têxteis)', nome: 'Lavagem de Sofás e Poltronas a Seco' },
  { id: 'limp-hig-colchoes', categoria: 'Limpeza e Higienização', subcategoria: 'Higienização Especializada (Estofados/Têxteis)', nome: 'Lavagem de Colchões (Anti-ácaro)' },
  { id: 'limp-hig-tapetes', categoria: 'Limpeza e Higienização', subcategoria: 'Higienização Especializada (Estofados/Têxteis)', nome: 'Lavagem de Tapetes e Carpetes' },
  { id: 'limp-hig-veiculos', categoria: 'Limpeza e Higienização', subcategoria: 'Higienização Especializada (Estofados/Têxteis)', nome: 'Higienização de Interiores de Veículos' },

  { id: 'limp-ind-galpoes', categoria: 'Limpeza e Higienização', subcategoria: 'Limpeza Industrial (Técnica)', nome: 'Limpeza de Galpões Logísticos (Pisos epóxi/concreto)' },
  { id: 'limp-ind-maquinario', categoria: 'Limpeza e Higienização', subcategoria: 'Limpeza Industrial (Técnica)', nome: 'Limpeza de Maquinário Externo' },
  { id: 'limp-ind-cozinhas', categoria: 'Limpeza e Higienização', subcategoria: 'Limpeza Industrial (Técnica)', nome: 'Limpeza de Cozinhas Industriais (Desengordurante pesado)' },

  // CATEGORIA 2: MANUTENÇÃO E REPAROS (MARIDO DE ALUGUEL)
  { id: 'man-ele-chuveiros', categoria: 'Manutenção e Reparos', subcategoria: 'Elétrica Rápida (Baixa Tensão)', nome: 'Troca de Chuveiros e Resistências' },
  { id: 'man-ele-tomadas', categoria: 'Manutenção e Reparos', subcategoria: 'Elétrica Rápida (Baixa Tensão)', nome: 'Instalação de Tomadas e Interruptores' },
  { id: 'man-ele-luminarias', categoria: 'Manutenção e Reparos', subcategoria: 'Elétrica Rápida (Baixa Tensão)', nome: 'Instalação de Luminárias e Lustres' },
  { id: 'man-ele-disjuntores', categoria: 'Manutenção e Reparos', subcategoria: 'Elétrica Rápida (Baixa Tensão)', nome: 'Troca de Disjuntores Residenciais' },

  { id: 'man-hid-torneiras', categoria: 'Manutenção e Reparos', subcategoria: 'Hidráulica Rápida', nome: 'Troca de Torneiras e Sifões' },
  { id: 'man-hid-descargas', categoria: 'Manutenção e Reparos', subcategoria: 'Hidráulica Rápida', nome: 'Reparo de Vazamentos em Descargas (Caixa acoplada)' },
  { id: 'man-hid-desentupimento', categoria: 'Manutenção e Reparos', subcategoria: 'Hidráulica Rápida', nome: 'Desentupimento Simples (Pias e Ralos)' },
  { id: 'man-hid-maquinas', categoria: 'Manutenção e Reparos', subcategoria: 'Hidráulica Rápida', nome: 'Instalação de Máquinas de Lavar/Lava-louças' },

  { id: 'man-mont-moveis', categoria: 'Manutenção e Reparos', subcategoria: 'Montagem e Instalação', nome: 'Montagem de Móveis Novos (Guarda-roupas, mesas)' },
  { id: 'man-mont-tv', categoria: 'Manutenção e Reparos', subcategoria: 'Montagem e Instalação', nome: 'Instalação de Suportes de TV e Prateleiras' },
  { id: 'man-mont-cortinas', categoria: 'Manutenção e Reparos', subcategoria: 'Montagem e Instalação', nome: 'Instalação de Cortinas e Persianas' },
  { id: 'man-mont-varais', categoria: 'Manutenção e Reparos', subcategoria: 'Montagem e Instalação', nome: 'Instalação de Varais de Teto/Parede' },

  { id: 'man-rep-pintura', categoria: 'Manutenção e Reparos', subcategoria: 'Pequenos Reparos (Alvenaria/Pintura)', nome: 'Pintura de Pequenos Ambientes (Parede única/Retoques)' },
  { id: 'man-rep-buracos', categoria: 'Manutenção e Reparos', subcategoria: 'Pequenos Reparos (Alvenaria/Pintura)', nome: 'Reparo de Buracos e Fissuras (Massa corrida)' },
  { id: 'man-rep-fechaduras', categoria: 'Manutenção e Reparos', subcategoria: 'Pequenos Reparos (Alvenaria/Pintura)', nome: 'Troca de Fechaduras e Maçanetas' },
  { id: 'man-rep-rejunte', categoria: 'Manutenção e Reparos', subcategoria: 'Pequenos Reparos (Alvenaria/Pintura)', nome: 'Rejunte de Pisos e Azulejos' },

  // CATEGORIA 3: JARDINAGEM E ÁREAS EXTERNAS
  { id: 'jard-man-grama', categoria: 'Jardinagem e Áreas Externas', subcategoria: 'Manutenção de Jardim', nome: 'Corte de Grama (Gramados planos)' },
  { id: 'jard-man-poda', categoria: 'Jardinagem e Áreas Externas', subcategoria: 'Manutenção de Jardim', nome: 'Poda de Arbustos e Cercas Vivas (Até 2 metros)' },
  { id: 'jard-man-ervas', categoria: 'Jardinagem e Áreas Externas', subcategoria: 'Manutenção de Jardim', nome: 'Remoção de Ervas Daninhas' },
  { id: 'jard-man-folhas', categoria: 'Jardinagem e Áreas Externas', subcategoria: 'Manutenção de Jardim', nome: 'Limpeza e Recolhimento de Folhas' },

  { id: 'jard-pais-flores', categoria: 'Jardinagem e Áreas Externas', subcategoria: 'Paisagismo e Plantio', nome: 'Plantio de Flores e Mudas' },
  { id: 'jard-pais-hortas', categoria: 'Jardinagem e Áreas Externas', subcategoria: 'Paisagismo e Plantio', nome: 'Criação de Hortas Verticais/Domésticas' },
  { id: 'jard-pais-adubacao', categoria: 'Jardinagem e Áreas Externas', subcategoria: 'Paisagismo e Plantio', nome: 'Adubação e Controle de Pragas (Simples)' },

  { id: 'jard-ext-piscinas', categoria: 'Jardinagem e Áreas Externas', subcategoria: 'Limpeza de Áreas Externas (Hardscape)', nome: 'Limpeza de Piscinas (Tratamento químico/Aspiração)' },
  { id: 'jard-ext-calcadas', categoria: 'Jardinagem e Áreas Externas', subcategoria: 'Limpeza de Áreas Externas (Hardscape)', nome: 'Lavagem de Calçadas e Decks (Alta pressão/WAP)' },
  { id: 'jard-ext-calhas', categoria: 'Jardinagem e Áreas Externas', subcategoria: 'Limpeza de Áreas Externas (Hardscape)', nome: 'Limpeza de Calhas e Telhados Baixos' },

  // CATEGORIA 4: CLIMATIZAÇÃO
  { id: 'clim-ar-limpeza', categoria: 'Climatização', subcategoria: 'Ar Condicionado', nome: 'Limpeza de Filtros e Higienização (Split)' },
  { id: 'clim-ar-instalacao', categoria: 'Climatização', subcategoria: 'Ar Condicionado', nome: 'Instalação de Ar Condicionado (Split/Janela)' },
  { id: 'clim-ar-manutencao', categoria: 'Climatização', subcategoria: 'Ar Condicionado', nome: 'Manutenção Preventiva (Carga de Gás)' },

  // CATEGORIA 5: PISCINAS E ÁREAS DE LAZER
  { id: 'pisc-limp-completa', categoria: 'Piscinas e Áreas de Lazer', subcategoria: 'Limpeza e Tratamento da Água', nome: 'Limpeza Completa (Física + Química)', descricao: 'Aspiração, peneira, escovação e aplicação de cloro/algicida.', tag_api: 'PISC_LIMP_COMPLETA' },
  { id: 'pisc-recupera-verde', categoria: 'Piscinas e Áreas de Lazer', subcategoria: 'Limpeza e Tratamento da Água', nome: 'Tratamento de Choque (Água Verde)', descricao: 'Recuperação emergencial de água parada/verde.', tag_api: 'PISC_RECUPERA_VERDE' },
  { id: 'pisc-quimica', categoria: 'Piscinas e Áreas de Lazer', subcategoria: 'Limpeza e Tratamento da Água', nome: 'Apenas Controle Químico', descricao: 'Medição e correção de pH, Alcalinidade e Cloro (sem aspiração).', tag_api: 'PISC_QUIMICA' },

  { id: 'pisc-filtro-areia', categoria: 'Piscinas e Áreas de Lazer', subcategoria: 'Manutenção de Equipamentos', nome: 'Troca de Areia do Filtro', descricao: 'Substituição do elemento filtrante (recomendado a cada 1-2 anos).', tag_api: 'PISC_FILTRO_AREIA' },
  { id: 'pisc-bomba-reparo', categoria: 'Piscinas e Áreas de Lazer', subcategoria: 'Manutenção de Equipamentos', nome: 'Reparo e Instalação de Bombas', descricao: 'Conserto de motor queimado, barulho ou troca de selo mecânico.', tag_api: 'PISC_BOMBA_REPARO' },
  { id: 'pisc-aquecimento', categoria: 'Piscinas e Áreas de Lazer', subcategoria: 'Manutenção de Equipamentos', nome: 'Instalação de Aquecimento', descricao: 'Instalação de trocador de calor ou placas solares.', tag_api: 'PISC_AQUECIMENTO' },

  { id: 'pisc-rejunte', categoria: 'Piscinas e Áreas de Lazer', subcategoria: 'Estrutural e Revestimento', nome: 'Troca de Rejunte Subaquático', descricao: 'Reparo do rejunte sem precisar esvaziar a piscina.', tag_api: 'PISC_REJUNTE' },
  { id: 'pisc-azulejo', categoria: 'Piscinas e Áreas de Lazer', subcategoria: 'Estrutural e Revestimento', nome: 'Reposição de Pastilhas/Azulejos', descricao: 'Colagem de peças soltas.', tag_api: 'PISC_AZULEJO' },
  { id: 'pisc-vazamento', categoria: 'Piscinas e Áreas de Lazer', subcategoria: 'Estrutural e Revestimento', nome: 'Detecção de Vazamentos (Caça-Vazamento)', descricao: 'Teste de estanqueidade para achar furos.', tag_api: 'PISC_VAZAMENTO' },
];

// Helper functions
export function getCategories(): string[] {
  return [...new Set(SERVICE_CATALOG.map(s => s.categoria))];
}

export function getSubcategorias(categoria: string): string[] {
  return [...new Set(SERVICE_CATALOG.filter(s => s.categoria === categoria).map(s => s.subcategoria))];
}

export function getServicos(categoria: string, subcategoria: string): ServiceItem[] {
  return SERVICE_CATALOG.filter(s => s.categoria === categoria && s.subcategoria === subcategoria);
}

export function getServicosByCategoria(categoria: string): ServiceItem[] {
  return SERVICE_CATALOG.filter(s => s.categoria === categoria);
}
