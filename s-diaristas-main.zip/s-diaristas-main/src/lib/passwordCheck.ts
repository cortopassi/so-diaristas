/**
 * Check if a password has been found in known data breaches
 * using the HaveIBeenPwned API with k-anonymity (only first 5 chars of SHA-1 hash are sent).
 * This means the full password never leaves the client.
 */
export async function isPasswordLeaked(password: string): Promise<boolean> {
  try {
    const encoder = new TextEncoder();
    const data = encoder.encode(password);
    const hashBuffer = await crypto.subtle.digest('SHA-1', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('').toUpperCase();

    const prefix = hashHex.slice(0, 5);
    const suffix = hashHex.slice(5);

    const response = await fetch(`https://api.pwnedpasswords.com/range/${prefix}`);
    if (!response.ok) return false; // fail open to not block signups

    const text = await response.text();
    const lines = text.split('\n');

    return lines.some(line => {
      const [hashSuffix] = line.split(':');
      return hashSuffix.trim() === suffix;
    });
  } catch {
    return false; // fail open on network errors
  }
}
