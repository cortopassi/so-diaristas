
## Corrigir a Pagina Admin que nao Carrega

### Problema
A pagina `/admin` fica presa em um spinner de carregamento infinito. O `AdminLayout` bloqueia toda a renderizacao enquanto o estado de `loading` do auth esta `true`, e a chamada `getSession()` do Supabase nao resolve, mantendo o spinner para sempre.

A pagina inicial (`/`) funciona porque renderiza o conteudo independentemente do estado de loading.

### Solucao

**1. Adicionar timeout ao `useAuth`**
- Se `getSession()` nao resolver em 5 segundos, forcar `loading = false` com `user = null`
- Isso garante que a pagina nao fique travada infinitamente

**2. Melhorar o `AdminLayout` para nao ficar preso**
- Adicionar um timeout visual: apos 3 segundos de loading, mostrar uma mensagem com link para login
- Se o usuario nao estiver autenticado, redirecionar imediatamente para `/login` em vez de ficar no spinner

### Detalhes Tecnicos

**`src/hooks/useAuth.tsx`** - Adicionar timeout de seguranca:
- Usar `setTimeout` de 5 segundos dentro do `useEffect`
- Se o loading ainda for `true` apos o timeout, forcar `setLoading(false)`
- Limpar o timeout no cleanup do effect

**`src/components/admin/AdminLayout.tsx`** - Melhorar experiencia de loading:
- Adicionar estado `showTimeout` que ativa apos 3 segundos
- Quando ativado, mostrar mensagem "Carregamento demorado" com botao para ir ao login
- Manter o redirect automatico para `/login` quando loading termina sem usuario

### Arquivos a Alterar
- `src/hooks/useAuth.tsx` (adicionar timeout)
- `src/components/admin/AdminLayout.tsx` (melhorar UX de loading)
