
-- 1. Fix SECURITY DEFINER helper functions with proper validation

CREATE OR REPLACE FUNCTION public.is_client()
RETURNS boolean
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF auth.uid() IS NULL THEN
    RETURN false;
  END IF;
  RETURN EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE user_id = auth.uid() AND role = 'client'
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.is_professional()
RETURNS boolean
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF auth.uid() IS NULL THEN
    RETURN false;
  END IF;
  RETURN EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE user_id = auth.uid() AND role = 'professional'
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.get_my_profile_id()
RETURNS uuid
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _user_id UUID;
  _profile_id UUID;
BEGIN
  _user_id := auth.uid();
  IF _user_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;
  
  SELECT id INTO _profile_id 
  FROM public.profiles 
  WHERE user_id = _user_id;
  
  IF _profile_id IS NULL THEN
    RAISE EXCEPTION 'Profile not found';
  END IF;
  
  RETURN _profile_id;
END;
$$;

-- 2. Add explicit deny INSERT policy on payments table
CREATE POLICY "Payments can only be created by service role"
ON public.payments FOR INSERT
WITH CHECK (false);

-- 3. Fix overly permissive RLS: notifications INSERT with CHECK(true)
-- Replace with a service-role-only policy (triggers use SECURITY DEFINER)
DROP POLICY IF EXISTS "System can create notifications" ON public.notifications;
CREATE POLICY "System can create notifications"
ON public.notifications FOR INSERT
WITH CHECK (false);
