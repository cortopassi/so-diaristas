
-- =============================================
-- SISTEMA ADMINISTRATIVO - ESTRUTURA COMPLETA
-- =============================================

-- 1. Enum de roles admin
CREATE TYPE public.app_role AS ENUM ('super_admin', 'operator', 'financial', 'support');

-- 2. Tabela de roles
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- 3. Funções de verificação de role (SECURITY DEFINER para evitar recursão)
CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$ SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role) $$;

CREATE OR REPLACE FUNCTION public.is_any_admin(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$ SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id) $$;

-- 4. RLS para user_roles
CREATE POLICY "Admins can view roles" ON public.user_roles FOR SELECT USING (public.is_any_admin(auth.uid()));
CREATE POLICY "Super admins can insert roles" ON public.user_roles FOR INSERT WITH CHECK (public.has_role(auth.uid(), 'super_admin'));
CREATE POLICY "Super admins can update roles" ON public.user_roles FOR UPDATE USING (public.has_role(auth.uid(), 'super_admin'));
CREATE POLICY "Super admins can delete roles" ON public.user_roles FOR DELETE USING (public.has_role(auth.uid(), 'super_admin'));

-- 5. Cidades para expansão
CREATE TABLE public.cities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  state TEXT NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(name, state)
);
ALTER TABLE public.cities ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Cities viewable by all" ON public.cities FOR SELECT USING (true);
CREATE POLICY "Admins can insert cities" ON public.cities FOR INSERT WITH CHECK (public.is_any_admin(auth.uid()));
CREATE POLICY "Admins can update cities" ON public.cities FOR UPDATE USING (public.is_any_admin(auth.uid()));
CREATE POLICY "Admins can delete cities" ON public.cities FOR DELETE USING (public.is_any_admin(auth.uid()));

-- 6. Categorias de serviço
CREATE TABLE public.service_categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.service_categories ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Categories viewable by all" ON public.service_categories FOR SELECT USING (true);
CREATE POLICY "Admins can insert categories" ON public.service_categories FOR INSERT WITH CHECK (public.is_any_admin(auth.uid()));
CREATE POLICY "Admins can update categories" ON public.service_categories FOR UPDATE USING (public.is_any_admin(auth.uid()));

-- 7. Serviços gerenciados pelo admin
CREATE TABLE public.services (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id UUID REFERENCES public.service_categories(id),
  name TEXT NOT NULL,
  description TEXT,
  tag_api TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.services ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Services viewable by all" ON public.services FOR SELECT USING (true);
CREATE POLICY "Admins can insert services" ON public.services FOR INSERT WITH CHECK (public.is_any_admin(auth.uid()));
CREATE POLICY "Admins can update services" ON public.services FOR UPDATE USING (public.is_any_admin(auth.uid()));

-- 8. Logs de ações admin
CREATE TABLE public.admin_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_user_id UUID NOT NULL,
  action TEXT NOT NULL,
  target_type TEXT,
  target_id UUID,
  details JSONB,
  ip_address TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.admin_logs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins can view logs" ON public.admin_logs FOR SELECT USING (public.is_any_admin(auth.uid()));
CREATE POLICY "Admins can create logs" ON public.admin_logs FOR INSERT WITH CHECK (public.is_any_admin(auth.uid()));

-- 9. Versões de contrato
CREATE TABLE public.contract_versions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  version TEXT NOT NULL,
  content TEXT NOT NULL,
  is_current BOOLEAN NOT NULL DEFAULT false,
  force_new_acceptance BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by UUID
);
ALTER TABLE public.contract_versions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Contracts viewable by authenticated" ON public.contract_versions FOR SELECT TO authenticated USING (true);
CREATE POLICY "Super admins can insert contracts" ON public.contract_versions FOR INSERT WITH CHECK (public.has_role(auth.uid(), 'super_admin'));
CREATE POLICY "Super admins can update contracts" ON public.contract_versions FOR UPDATE USING (public.has_role(auth.uid(), 'super_admin'));

-- 10. Notas/advertências de clientes
CREATE TABLE public.client_notes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_profile_id UUID REFERENCES public.profiles(id) NOT NULL,
  admin_user_id UUID NOT NULL,
  note_type TEXT NOT NULL DEFAULT 'observation',
  content TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.client_notes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins can view client notes" ON public.client_notes FOR SELECT USING (public.is_any_admin(auth.uid()));
CREATE POLICY "Admins can create client notes" ON public.client_notes FOR INSERT WITH CHECK (public.is_any_admin(auth.uid()));

-- 11. Status de conta no perfil (ativo, suspenso, bloqueado)
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS account_status TEXT NOT NULL DEFAULT 'active';

-- 12. Alertas internos do admin
CREATE TABLE public.admin_alerts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  alert_type TEXT NOT NULL,
  severity TEXT NOT NULL DEFAULT 'info',
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  target_type TEXT,
  target_id UUID,
  is_resolved BOOLEAN NOT NULL DEFAULT false,
  resolved_by UUID,
  resolved_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.admin_alerts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins can view alerts" ON public.admin_alerts FOR SELECT USING (public.is_any_admin(auth.uid()));
CREATE POLICY "Admins can update alerts" ON public.admin_alerts FOR UPDATE USING (public.is_any_admin(auth.uid()));
CREATE POLICY "Admins can insert alerts" ON public.admin_alerts FOR INSERT WITH CHECK (public.is_any_admin(auth.uid()));

-- 13. Acesso admin às tabelas existentes
CREATE POLICY "Admins can view all profiles" ON public.profiles FOR SELECT USING (public.is_any_admin(auth.uid()));
CREATE POLICY "Admins can update all profiles" ON public.profiles FOR UPDATE USING (public.is_any_admin(auth.uid()));
CREATE POLICY "Admins can view all bookings" ON public.bookings FOR SELECT USING (public.is_any_admin(auth.uid()));
CREATE POLICY "Admins can update all bookings" ON public.bookings FOR UPDATE USING (public.is_any_admin(auth.uid()));
CREATE POLICY "Admins can view all payments" ON public.payments FOR SELECT USING (public.is_any_admin(auth.uid()));
CREATE POLICY "Admins can view all documents" ON public.professional_documents FOR SELECT USING (public.is_any_admin(auth.uid()));
CREATE POLICY "Admins can update all documents" ON public.professional_documents FOR UPDATE USING (public.is_any_admin(auth.uid()));
CREATE POLICY "Admins can view all notifications" ON public.notifications FOR SELECT USING (public.is_any_admin(auth.uid()));

-- 14. Triggers para updated_at
CREATE TRIGGER update_cities_updated_at BEFORE UPDATE ON public.cities FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_service_categories_updated_at BEFORE UPDATE ON public.service_categories FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_services_updated_at BEFORE UPDATE ON public.services FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
