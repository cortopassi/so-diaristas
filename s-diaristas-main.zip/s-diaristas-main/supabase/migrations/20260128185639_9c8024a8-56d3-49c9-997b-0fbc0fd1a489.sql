-- Criar bucket para documentos das profissionais
INSERT INTO storage.buckets (id, name, public)
VALUES ('professional-documents', 'professional-documents', false);

-- RLS para o bucket - apenas a própria profissional pode fazer upload
CREATE POLICY "Professionals can upload own documents"
ON storage.objects
FOR INSERT
WITH CHECK (
  bucket_id = 'professional-documents' AND
  auth.uid()::text = (storage.foldername(name))[1]
);

-- Profissionais podem ver seus próprios documentos
CREATE POLICY "Professionals can view own documents"
ON storage.objects
FOR SELECT
USING (
  bucket_id = 'professional-documents' AND
  auth.uid()::text = (storage.foldername(name))[1]
);

-- Profissionais podem deletar seus próprios documentos
CREATE POLICY "Professionals can delete own documents"
ON storage.objects
FOR DELETE
USING (
  bucket_id = 'professional-documents' AND
  auth.uid()::text = (storage.foldername(name))[1]
);

-- Tabela para armazenar documentos enviados
CREATE TABLE public.professional_documents (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  professional_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  document_type TEXT NOT NULL, -- 'rg', 'cpf', 'address_proof', 'criminal_record'
  file_url TEXT NOT NULL,
  file_name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending', -- 'pending', 'approved', 'rejected'
  rejection_reason TEXT,
  reviewed_at TIMESTAMP WITH TIME ZONE,
  reviewed_by UUID,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(professional_id, document_type)
);

-- Adicionar colunas de verificação no perfil
ALTER TABLE public.profiles
ADD COLUMN IF NOT EXISTS verification_status TEXT DEFAULT 'pending', -- 'pending', 'documents_submitted', 'verified', 'rejected'
ADD COLUMN IF NOT EXISTS terms_accepted_at TIMESTAMP WITH TIME ZONE,
ADD COLUMN IF NOT EXISTS criminal_record_checked_at TIMESTAMP WITH TIME ZONE,
ADD COLUMN IF NOT EXISTS criminal_record_status TEXT; -- 'pending', 'clean', 'flagged'

-- Habilitar RLS
ALTER TABLE public.professional_documents ENABLE ROW LEVEL SECURITY;

-- Políticas RLS para documentos
CREATE POLICY "Professionals can view own documents"
ON public.professional_documents
FOR SELECT
USING (professional_id = get_my_profile_id());

CREATE POLICY "Professionals can insert own documents"
ON public.professional_documents
FOR INSERT
WITH CHECK (professional_id = get_my_profile_id());

CREATE POLICY "Professionals can update own documents"
ON public.professional_documents
FOR UPDATE
USING (professional_id = get_my_profile_id() AND status = 'pending');

-- Trigger para atualizar updated_at
CREATE TRIGGER update_professional_documents_updated_at
BEFORE UPDATE ON public.professional_documents
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Função para atualizar status de verificação do perfil
CREATE OR REPLACE FUNCTION public.update_profile_verification_status()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  docs_count INTEGER;
  approved_count INTEGER;
  rejected_count INTEGER;
BEGIN
  -- Contar documentos
  SELECT 
    COUNT(*),
    COUNT(*) FILTER (WHERE status = 'approved'),
    COUNT(*) FILTER (WHERE status = 'rejected')
  INTO docs_count, approved_count, rejected_count
  FROM public.professional_documents
  WHERE professional_id = NEW.professional_id;
  
  -- Atualizar status do perfil
  IF rejected_count > 0 THEN
    UPDATE public.profiles SET verification_status = 'rejected' WHERE id = NEW.professional_id;
  ELSIF approved_count >= 4 THEN -- RG, CPF, Comprovante, Antecedentes
    UPDATE public.profiles SET verification_status = 'verified' WHERE id = NEW.professional_id;
  ELSIF docs_count > 0 THEN
    UPDATE public.profiles SET verification_status = 'documents_submitted' WHERE id = NEW.professional_id;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Trigger para atualizar verificação
CREATE TRIGGER update_verification_on_document_change
AFTER INSERT OR UPDATE ON public.professional_documents
FOR EACH ROW
EXECUTE FUNCTION public.update_profile_verification_status();