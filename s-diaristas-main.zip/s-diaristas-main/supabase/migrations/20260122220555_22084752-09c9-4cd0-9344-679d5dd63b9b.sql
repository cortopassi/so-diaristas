-- Adicionar campo de chave PIX no perfil das profissionais
ALTER TABLE public.profiles 
ADD COLUMN IF NOT EXISTS pix_key TEXT,
ADD COLUMN IF NOT EXISTS pix_key_type TEXT CHECK (pix_key_type IN ('cpf', 'cnpj', 'email', 'phone', 'random'));

-- Adicionar campos de split na tabela de pagamentos
ALTER TABLE public.payments 
ADD COLUMN IF NOT EXISTS platform_fee NUMERIC DEFAULT 0,
ADD COLUMN IF NOT EXISTS professional_amount NUMERIC DEFAULT 0,
ADD COLUMN IF NOT EXISTS asaas_payment_id TEXT,
ADD COLUMN IF NOT EXISTS asaas_transfer_id TEXT;

-- Criar tabela de notificações
CREATE TABLE IF NOT EXISTS public.notifications (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('booking_request', 'booking_accepted', 'booking_rejected', 'booking_completed', 'payment_received', 'review_received')),
  related_booking_id UUID REFERENCES public.bookings(id) ON DELETE CASCADE,
  is_read BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Habilitar RLS na tabela de notificações
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

-- Política: usuários podem ver suas próprias notificações
CREATE POLICY "Users can view own notifications" 
ON public.notifications 
FOR SELECT 
USING (user_id = auth.uid());

-- Política: usuários podem atualizar suas próprias notificações (marcar como lida)
CREATE POLICY "Users can update own notifications" 
ON public.notifications 
FOR UPDATE 
USING (user_id = auth.uid());

-- Política: sistema pode criar notificações (via service role)
CREATE POLICY "System can create notifications" 
ON public.notifications 
FOR INSERT 
WITH CHECK (true);

-- Habilitar realtime para notificações
ALTER PUBLICATION supabase_realtime ADD TABLE public.notifications;

-- Criar função para notificar profissional quando receber booking
CREATE OR REPLACE FUNCTION public.notify_booking_request()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  professional_user_id UUID;
  client_name TEXT;
BEGIN
  -- Buscar user_id do profissional
  SELECT user_id INTO professional_user_id 
  FROM public.profiles 
  WHERE id = NEW.professional_id;
  
  -- Buscar nome do cliente
  SELECT full_name INTO client_name 
  FROM public.profiles 
  WHERE user_id = NEW.client_id;
  
  -- Criar notificação para o profissional
  INSERT INTO public.notifications (user_id, title, message, type, related_booking_id)
  VALUES (
    professional_user_id,
    'Nova solicitação de serviço!',
    'Você recebeu uma nova solicitação de ' || COALESCE(client_name, 'um cliente') || ' para ' || NEW.service_type,
    'booking_request',
    NEW.id
  );
  
  RETURN NEW;
END;
$$;

-- Trigger para notificar quando booking é criado
DROP TRIGGER IF EXISTS on_booking_created ON public.bookings;
CREATE TRIGGER on_booking_created
  AFTER INSERT ON public.bookings
  FOR EACH ROW
  EXECUTE FUNCTION public.notify_booking_request();

-- Criar função para notificar cliente quando booking é aceito/rejeitado
CREATE OR REPLACE FUNCTION public.notify_booking_status_change()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  professional_name TEXT;
  notification_title TEXT;
  notification_message TEXT;
  notification_type TEXT;
BEGIN
  -- Só notificar se status mudou
  IF OLD.status = NEW.status THEN
    RETURN NEW;
  END IF;
  
  -- Buscar nome do profissional
  SELECT full_name INTO professional_name 
  FROM public.profiles 
  WHERE id = NEW.professional_id;
  
  -- Definir mensagem baseada no novo status
  CASE NEW.status
    WHEN 'confirmed' THEN
      notification_title := 'Serviço confirmado!';
      notification_message := COALESCE(professional_name, 'A profissional') || ' aceitou sua solicitação de ' || NEW.service_type;
      notification_type := 'booking_accepted';
    WHEN 'cancelled' THEN
      notification_title := 'Serviço cancelado';
      notification_message := 'Sua solicitação de ' || NEW.service_type || ' foi cancelada';
      notification_type := 'booking_rejected';
    WHEN 'completed' THEN
      notification_title := 'Serviço concluído!';
      notification_message := 'O serviço de ' || NEW.service_type || ' foi marcado como concluído';
      notification_type := 'booking_completed';
    ELSE
      RETURN NEW;
  END CASE;
  
  -- Criar notificação para o cliente
  INSERT INTO public.notifications (user_id, title, message, type, related_booking_id)
  VALUES (
    NEW.client_id,
    notification_title,
    notification_message,
    notification_type,
    NEW.id
  );
  
  RETURN NEW;
END;
$$;

-- Trigger para notificar mudança de status
DROP TRIGGER IF EXISTS on_booking_status_changed ON public.bookings;
CREATE TRIGGER on_booking_status_changed
  AFTER UPDATE ON public.bookings
  FOR EACH ROW
  EXECUTE FUNCTION public.notify_booking_status_change();