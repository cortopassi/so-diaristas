
-- 1. Tabela de subcategorias
CREATE TABLE public.service_subcategories (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  category_id UUID NOT NULL REFERENCES public.service_categories(id),
  name TEXT NOT NULL,
  description TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.service_subcategories ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Subcategories viewable by all" ON public.service_subcategories FOR SELECT USING (true);
CREATE POLICY "Admins can insert subcategories" ON public.service_subcategories FOR INSERT WITH CHECK (is_any_admin(auth.uid()));
CREATE POLICY "Admins can update subcategories" ON public.service_subcategories FOR UPDATE USING (is_any_admin(auth.uid()));

-- 2. Adicionar subcategory_id na tabela services (nullable para compatibilidade)
ALTER TABLE public.services ADD COLUMN subcategory_id UUID REFERENCES public.service_subcategories(id);

-- 3. Tabela de serviços do profissional (preços individuais)
CREATE TABLE public.professional_services (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  professional_id UUID NOT NULL REFERENCES public.profiles(id),
  service_id UUID NOT NULL REFERENCES public.services(id),
  charge_type TEXT NOT NULL DEFAULT 'hour' CHECK (charge_type IN ('hour', 'period')),
  price NUMERIC NOT NULL CHECK (price > 0),
  custom_description TEXT,
  handles_emergency BOOLEAN NOT NULL DEFAULT false,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(professional_id, service_id)
);
ALTER TABLE public.professional_services ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Professional services viewable by all" ON public.professional_services FOR SELECT USING (true);
CREATE POLICY "Professionals can insert own services" ON public.professional_services FOR INSERT WITH CHECK (professional_id = get_my_profile_id());
CREATE POLICY "Professionals can update own services" ON public.professional_services FOR UPDATE USING (professional_id = get_my_profile_id());
CREATE POLICY "Professionals can delete own services" ON public.professional_services FOR DELETE USING (professional_id = get_my_profile_id());
CREATE POLICY "Admins can manage professional services" ON public.professional_services FOR ALL USING (is_any_admin(auth.uid()));

-- 4. Disponibilidade semanal do profissional
CREATE TABLE public.professional_availability (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  professional_id UUID NOT NULL REFERENCES public.profiles(id),
  day_of_week INTEGER NOT NULL CHECK (day_of_week BETWEEN 0 AND 6),
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(professional_id, day_of_week)
);
ALTER TABLE public.professional_availability ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Availability viewable by all" ON public.professional_availability FOR SELECT USING (true);
CREATE POLICY "Professionals can manage own availability" ON public.professional_availability FOR INSERT WITH CHECK (professional_id = get_my_profile_id());
CREATE POLICY "Professionals can update own availability" ON public.professional_availability FOR UPDATE USING (professional_id = get_my_profile_id());
CREATE POLICY "Professionals can delete own availability" ON public.professional_availability FOR DELETE USING (professional_id = get_my_profile_id());

-- 5. Cidades de atuação do profissional
CREATE TABLE public.professional_cities (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  professional_id UUID NOT NULL REFERENCES public.profiles(id),
  city_id UUID NOT NULL REFERENCES public.cities(id),
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(professional_id, city_id)
);
ALTER TABLE public.professional_cities ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Professional cities viewable by all" ON public.professional_cities FOR SELECT USING (true);
CREATE POLICY "Professionals can manage own cities" ON public.professional_cities FOR INSERT WITH CHECK (professional_id = get_my_profile_id());
CREATE POLICY "Professionals can update own cities" ON public.professional_cities FOR UPDATE USING (professional_id = get_my_profile_id());
CREATE POLICY "Professionals can delete own cities" ON public.professional_cities FOR DELETE USING (professional_id = get_my_profile_id());

-- 6. Adicionar geolocalização ao perfil
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS latitude DOUBLE PRECISION;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS longitude DOUBLE PRECISION;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS service_radius_km NUMERIC DEFAULT 20;

-- 7. Índices para performance
CREATE INDEX idx_professional_services_professional ON public.professional_services(professional_id);
CREATE INDEX idx_professional_services_service ON public.professional_services(service_id);
CREATE INDEX idx_professional_availability_professional ON public.professional_availability(professional_id);
CREATE INDEX idx_professional_cities_professional ON public.professional_cities(professional_id);
CREATE INDEX idx_professional_cities_city ON public.professional_cities(city_id);
CREATE INDEX idx_services_subcategory ON public.services(subcategory_id);
CREATE INDEX idx_service_subcategories_category ON public.service_subcategories(category_id);
CREATE INDEX idx_profiles_lat_lng ON public.profiles(latitude, longitude) WHERE latitude IS NOT NULL;

-- 8. Triggers de updated_at
CREATE TRIGGER update_service_subcategories_updated_at BEFORE UPDATE ON public.service_subcategories FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_professional_services_updated_at BEFORE UPDATE ON public.professional_services FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 9. Função haversine para cálculo de distância
CREATE OR REPLACE FUNCTION public.haversine_distance(lat1 DOUBLE PRECISION, lon1 DOUBLE PRECISION, lat2 DOUBLE PRECISION, lon2 DOUBLE PRECISION)
RETURNS DOUBLE PRECISION
LANGUAGE plpgsql IMMUTABLE
SET search_path TO 'public'
AS $$
DECLARE
  r DOUBLE PRECISION := 6371;
  dlat DOUBLE PRECISION;
  dlon DOUBLE PRECISION;
  a DOUBLE PRECISION;
BEGIN
  dlat := radians(lat2 - lat1);
  dlon := radians(lon2 - lon1);
  a := sin(dlat/2)^2 + cos(radians(lat1)) * cos(radians(lat2)) * sin(dlon/2)^2;
  RETURN r * 2 * asin(sqrt(a));
END;
$$;
