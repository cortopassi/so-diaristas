-- Criar trigger para notificar cliente quando serviço for concluído para avaliar
CREATE OR REPLACE FUNCTION public.notify_review_request()
RETURNS TRIGGER AS $$
BEGIN
  -- Só quando status muda para 'completed'
  IF OLD.status IS DISTINCT FROM NEW.status AND NEW.status = 'completed' THEN
    -- Verificar se já não existe review para este booking
    IF NOT EXISTS (SELECT 1 FROM public.reviews WHERE booking_id = NEW.id) THEN
      INSERT INTO public.notifications (user_id, title, message, type, related_booking_id)
      VALUES (
        NEW.client_id,
        'Avalie o serviço! ⭐',
        'O serviço foi concluído. Que tal avaliar a profissional?',
        'review_request',
        NEW.id
      );
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Criar trigger
DROP TRIGGER IF EXISTS notify_review_request_trigger ON public.bookings;
CREATE TRIGGER notify_review_request_trigger
AFTER UPDATE ON public.bookings
FOR EACH ROW
EXECUTE FUNCTION public.notify_review_request();