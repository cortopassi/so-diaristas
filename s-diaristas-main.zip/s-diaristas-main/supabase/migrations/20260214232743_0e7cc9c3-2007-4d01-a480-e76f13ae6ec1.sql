
-- Add missing columns to profiles table
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS cpf text;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS date_of_birth date;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS cep text;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS rua text;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS numero text;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS complemento text;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS estado text;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS foto_url text;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS rg_frente_url text;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS rg_verso_url text;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS comprovante_url text;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS antecedentes_url text;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS autoriza_imagem boolean DEFAULT false;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS tipo_cobranca text;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS valor_hora numeric;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS status_aprovacao text DEFAULT 'pendente';

-- Add unique constraint on cpf (only for non-null values)
CREATE UNIQUE INDEX IF NOT EXISTS profiles_cpf_unique ON public.profiles (cpf) WHERE cpf IS NOT NULL;

-- Create otp_codes table
CREATE TABLE IF NOT EXISTS public.otp_codes (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  cpf text NOT NULL,
  code text NOT NULL,
  expires_at timestamp with time zone NOT NULL,
  used boolean DEFAULT false,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.otp_codes ENABLE ROW LEVEL SECURITY;

-- OTP policies: anyone can insert (for signup), select by cpf match
CREATE POLICY "Anyone can create OTP codes" ON public.otp_codes FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can read OTP codes" ON public.otp_codes FOR SELECT USING (true);
CREATE POLICY "Anyone can update OTP codes" ON public.otp_codes FOR UPDATE USING (true);
