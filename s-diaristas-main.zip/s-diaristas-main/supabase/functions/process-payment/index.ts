import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface PaymentRequest {
  booking_id: string;
  customer_name: string;
  customer_email: string;
  customer_cpf: string;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(
        JSON.stringify({ error: "Não autorizado" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );

    const token = authHeader.replace("Bearer ", "");
    const { data: claimsData, error: claimsError } = await supabase.auth.getUser(token);
    if (claimsError || !claimsData?.user) {
      return new Response(
        JSON.stringify({ error: "Token inválido" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { booking_id, customer_name, customer_email, customer_cpf }: PaymentRequest = await req.json();

    // Buscar dados do booking
    const { data: booking, error: bookingError } = await supabase
      .from("bookings")
      .select(`
        *,
        professional:profiles!bookings_professional_id_fkey(
          id, full_name, pix_key, pix_key_type, user_id
        )
      `)
      .eq("id", booking_id)
      .single();

    if (bookingError || !booking) {
      return new Response(
        JSON.stringify({ error: "Booking não encontrado" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const ASAAS_API_KEY = Deno.env.get("ASAAS_API_KEY");
    const ASAAS_WALLET_ID = Deno.env.get("ASAAS_WALLET_ID");
    const ASAAS_BASE_URL = "https://api.asaas.com/v3";

    if (!ASAAS_API_KEY || !ASAAS_WALLET_ID) {
      console.error("Missing Asaas configuration");
      return new Response(
        JSON.stringify({ error: "Erro temporário no sistema de pagamentos. Tente novamente mais tarde." }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Calcular valores do split (15% plataforma, 85% profissional)
    const totalAmount = Number(booking.total_amount);
    const platformFee = Math.round(totalAmount * 0.15 * 100) / 100;
    const professionalAmount = Math.round((totalAmount - platformFee) * 100) / 100;

    // 1. Criar ou buscar cliente no Asaas
    const customerResponse = await fetch(`${ASAAS_BASE_URL}/customers`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "access_token": ASAAS_API_KEY,
      },
      body: JSON.stringify({
        name: customer_name,
        email: customer_email,
        cpfCnpj: customer_cpf.replace(/\D/g, ""),
      }),
    });

    const customerData = await customerResponse.json();
    const customerId = customerData.id || customerData.errors?.[0]?.description?.includes("já existe") 
      ? customer_cpf.replace(/\D/g, "") 
      : null;

    if (!customerId && !customerData.id) {
      // Tentar buscar cliente existente
      const searchResponse = await fetch(
        `${ASAAS_BASE_URL}/customers?cpfCnpj=${customer_cpf.replace(/\D/g, "")}`,
        {
          headers: { "access_token": ASAAS_API_KEY },
        }
      );
      const searchData = await searchResponse.json();
      if (searchData.data?.[0]?.id) {
        customerData.id = searchData.data[0].id;
      }
    }

    // 2. Criar cobrança PIX com split
    const dueDate = new Date();
    dueDate.setDate(dueDate.getDate() + 1);

    const paymentBody: Record<string, unknown> = {
      customer: customerData.id,
      billingType: "PIX",
      value: totalAmount,
      dueDate: dueDate.toISOString().split("T")[0],
      description: `Serviço: ${booking.service_type} - ${booking.hours}h`,
      externalReference: booking_id,
    };

    // Adicionar split se profissional tem chave PIX configurada
    if (booking.professional?.pix_key) {
      paymentBody.split = [
        {
          walletId: ASAAS_WALLET_ID,
          fixedValue: platformFee,
        },
      ];
    }

    const paymentResponse = await fetch(`${ASAAS_BASE_URL}/payments`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "access_token": ASAAS_API_KEY,
      },
      body: JSON.stringify(paymentBody),
    });

    const paymentData = await paymentResponse.json();

    if (paymentData.errors) {
      console.error("Asaas payment error:", JSON.stringify(paymentData.errors));
      return new Response(
        JSON.stringify({ error: "Não foi possível processar o pagamento. Tente novamente." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // 3. Buscar QR Code PIX
    const pixResponse = await fetch(`${ASAAS_BASE_URL}/payments/${paymentData.id}/pixQrCode`, {
      headers: { "access_token": ASAAS_API_KEY },
    });
    const pixData = await pixResponse.json();

    // 4. Criar registro de pagamento no banco usando service role
    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    await supabaseAdmin.from("payments").insert({
      booking_id,
      amount: totalAmount,
      platform_fee: platformFee,
      professional_amount: professionalAmount,
      asaas_payment_id: paymentData.id,
      status: "pending",
    });

    return new Response(
      JSON.stringify({
        success: true,
        payment_id: paymentData.id,
        pix_code: pixData.payload,
        pix_qrcode: pixData.encodedImage,
        expires_at: paymentData.dueDate,
        total_amount: totalAmount,
        platform_fee: platformFee,
        professional_amount: professionalAmount,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Erro no processamento:", error);
    return new Response(
      JSON.stringify({ error: "Erro interno do servidor" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
