import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const { action, cpf, code } = await req.json();

    if (action === "request") {
      // Look up profile by CPF using admin client (bypasses RLS)
      const { data: profile, error } = await supabaseAdmin
        .from("profiles")
        .select("user_id, full_name")
        .eq("cpf", cpf)
        .maybeSingle();

      if (error) throw error;
      if (!profile) {
        return new Response(JSON.stringify({ error: "CPF não cadastrado" }), {
          status: 404,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      // Generate OTP
      const otpCode = Math.floor(100000 + Math.random() * 900000).toString();

      // Store OTP
      await supabaseAdmin.from("otp_codes").insert({
        cpf,
        code: otpCode,
        expires_at: new Date(Date.now() + 5 * 60 * 1000).toISOString(),
      });

      return new Response(
        JSON.stringify({ full_name: profile.full_name, otp: otpCode }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (action === "verify") {
      // Verify OTP - find the latest matching code for this CPF
      const { data: otpRecord, error: otpError } = await supabaseAdmin
        .from("otp_codes")
        .select("*")
        .eq("cpf", cpf)
        .eq("code", code)
        .gte("expires_at", new Date().toISOString())
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();

      if (otpError) throw otpError;
      if (!otpRecord) {
        return new Response(
          JSON.stringify({ error: "Código inválido ou expirado" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // Mark OTP as used
      await supabaseAdmin
        .from("otp_codes")
        .update({ used: true })
        .eq("id", otpRecord.id);

      // Get profile to find user and role
      const { data: profile } = await supabaseAdmin
        .from("profiles")
        .select("user_id, role")
        .eq("cpf", cpf)
        .maybeSingle();

      if (!profile) {
        return new Response(
          JSON.stringify({ error: "Perfil não encontrado" }),
          { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // Get user email from auth
      const { data: authUser, error: authError } = await supabaseAdmin.auth.admin.getUserById(profile.user_id);
      if (authError || !authUser?.user?.email) {
        return new Response(
          JSON.stringify({ error: "Usuário não encontrado" }),
          { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // Generate a magic link for the user (sign them in)
      const { data: linkData, error: linkError } = await supabaseAdmin.auth.admin.generateLink({
        type: "magiclink",
        email: authUser.user.email,
      });

      if (linkError) throw linkError;

      return new Response(
        JSON.stringify({
          role: profile.role,
          token: linkData.properties?.email_otp,
          email: authUser.user.email,
        }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(JSON.stringify({ error: "Ação inválida" }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error: any) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
