import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, asaas-access-token",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const body = await req.json();
    console.log("Webhook Asaas recebido:", JSON.stringify(body));

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const { event, payment } = body;

    if (!payment?.externalReference) {
      return new Response(
        JSON.stringify({ message: "Sem referência externa" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const bookingId = payment.externalReference;

    switch (event) {
      case "PAYMENT_CONFIRMED":
      case "PAYMENT_RECEIVED": {
        // Atualizar status do pagamento
        await supabase
          .from("payments")
          .update({
            status: "paid",
            paid_at: new Date().toISOString(),
            payment_method: "pix",
          })
          .eq("booking_id", bookingId);

        // Atualizar status do booking para confirmado
        await supabase
          .from("bookings")
          .update({ status: "confirmed" })
          .eq("id", bookingId);

        // Buscar dados para notificação
        const { data: booking } = await supabase
          .from("bookings")
          .select(`
            *,
            professional:profiles!bookings_professional_id_fkey(user_id, full_name)
          `)
          .eq("id", bookingId)
          .single();

        if (booking?.professional?.user_id) {
          // Notificar profissional sobre pagamento recebido
          await supabase.from("notifications").insert({
            user_id: booking.professional.user_id,
            title: "Pagamento recebido!",
            message: `O pagamento de R$ ${payment.value.toFixed(2)} foi confirmado para o serviço de ${booking.service_type}`,
            type: "payment_received",
            related_booking_id: bookingId,
          });
        }

        // Iniciar transferência PIX para profissional
        const { data: paymentRecord } = await supabase
          .from("payments")
          .select("professional_amount")
          .eq("booking_id", bookingId)
          .single();

        if (paymentRecord && booking?.professional) {
          const { data: profile } = await supabase
            .from("profiles")
            .select("pix_key, pix_key_type")
            .eq("id", booking.professional_id)
            .single();

          if (profile?.pix_key) {
            // Criar transferência PIX via Asaas
            const ASAAS_API_KEY = Deno.env.get("ASAAS_API_KEY");
            const transferResponse = await fetch("https://api.asaas.com/v3/transfers", {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
                "access_token": ASAAS_API_KEY!,
              },
              body: JSON.stringify({
                value: paymentRecord.professional_amount,
                pixAddressKey: profile.pix_key,
                pixAddressKeyType: profile.pix_key_type?.toUpperCase() || "CPF",
                description: `Pagamento serviço #${bookingId.slice(0, 8)}`,
              }),
            });

            const transferData = await transferResponse.json();
            console.log("Transferência criada:", transferData);

            if (transferData.id) {
              await supabase
                .from("payments")
                .update({ asaas_transfer_id: transferData.id })
                .eq("booking_id", bookingId);
            }
          }
        }
        break;
      }

      case "PAYMENT_OVERDUE":
      case "PAYMENT_DELETED":
      case "PAYMENT_REFUNDED": {
        const statusMap: Record<string, string> = {
          PAYMENT_OVERDUE: "pending",
          PAYMENT_DELETED: "refunded",
          PAYMENT_REFUNDED: "refunded",
        };

        await supabase
          .from("payments")
          .update({ status: statusMap[event] })
          .eq("booking_id", bookingId);

        if (event === "PAYMENT_REFUNDED") {
          await supabase
            .from("bookings")
            .update({ status: "cancelled" })
            .eq("id", bookingId);
        }
        break;
      }
    }

    return new Response(
      JSON.stringify({ success: true }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Erro no webhook:", error);
    return new Response(
      JSON.stringify({ error: "Erro interno" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
