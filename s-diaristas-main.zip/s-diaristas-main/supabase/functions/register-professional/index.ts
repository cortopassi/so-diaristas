import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const body = await req.json();
    const {
      email, fullName, phone, cpf, cep, rua, numero, complemento,
      bairro, cidade, estado, latitude, longitude, pixKey, pixKeyType,
      autorizaImagem, fotoUrl, rgFrenteUrl, rgVersoUrl, comprovanteUrl,
      antecedentesUrl, selectedServiceNames, professionalServices,
    } = body;

    if (!email || !fullName || !cpf) {
      return new Response(
        JSON.stringify({ error: "Campos obrigatórios: email, fullName, cpf" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const cleanCpf = cpf.replace(/\D/g, "");

    // 1. Check if profile with this CPF already exists
    const { data: existingProfile } = await supabaseAdmin
      .from("profiles")
      .select("id")
      .eq("cpf", cleanCpf)
      .maybeSingle();

    if (existingProfile) {
      return new Response(
        JSON.stringify({ error: "CPF já cadastrado", code: "cpf_exists" }),
        { status: 409, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // 2. Try to create auth user directly (fast path)
    const invisiblePassword = crypto.randomUUID();
    let userId: string;

    const { data: authData, error: authError } = await supabaseAdmin.auth.admin.createUser({
      email,
      password: invisiblePassword,
      email_confirm: true,
    });

    if (authError) {
      // If user already exists, try to find and handle
      if (authError.message?.includes("already been registered") || authError.message?.includes("already exists")) {
        // Check if they have a profile via email lookup in profiles
        // Use admin API with filter instead of listUsers
        const { data: lookupData } = await supabaseAdmin.auth.admin.listUsers({ 
          page: 1, 
          perPage: 1,
          // We'll use a direct GoTrue REST call instead for speed
        });

        // Faster: use GoTrue REST API directly to get user by email
        const gotrueUrl = Deno.env.get("SUPABASE_URL")! + "/auth/v1/admin/users";
        const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
        
        const lookupRes = await fetch(gotrueUrl + `?filter=${encodeURIComponent(email)}&page=1&per_page=1`, {
          headers: {
            "Authorization": `Bearer ${serviceKey}`,
            "apikey": serviceKey,
          },
        });
        const lookupJson = await lookupRes.json();
        const existingUser = lookupJson?.users?.[0];

        if (existingUser) {
          // Check if profile exists for this user
          const { data: userProfile } = await supabaseAdmin
            .from("profiles")
            .select("id")
            .eq("user_id", existingUser.id)
            .maybeSingle();

          if (userProfile) {
            return new Response(
              JSON.stringify({ error: "E-mail já cadastrado", code: "email_exists" }),
              { status: 409, headers: { ...corsHeaders, "Content-Type": "application/json" } }
            );
          }

          // Orphan - delete and recreate
          await supabaseAdmin.auth.admin.deleteUser(existingUser.id);
          
          const { data: retryAuth, error: retryError } = await supabaseAdmin.auth.admin.createUser({
            email,
            password: invisiblePassword,
            email_confirm: true,
          });

          if (retryError) throw retryError;
          userId = retryAuth.user.id;
        } else {
          throw new Error("Usuário não encontrado após erro de duplicata");
        }
      } else {
        throw authError;
      }
    } else {
      userId = authData.user.id;
    }

    // 3. Create profile
    const { data: profileResult, error: profileError } = await supabaseAdmin
      .from("profiles")
      .insert({
        user_id: userId,
        full_name: fullName,
        role: "professional",
        phone: phone || null,
        city: cidade || null,
        neighborhood: bairro || null,
        pix_key: pixKey || null,
        pix_key_type: pixKeyType || null,
        terms_accepted_at: new Date().toISOString(),
        services_offered: selectedServiceNames || [],
        cpf: cleanCpf,
        cep: cep ? cep.replace(/\D/g, "") : null,
        rua: rua || null,
        numero: numero || null,
        complemento: complemento || null,
        estado: estado || null,
        latitude: latitude || null,
        longitude: longitude || null,
        foto_url: fotoUrl || null,
        rg_frente_url: rgFrenteUrl || null,
        rg_verso_url: rgVersoUrl || null,
        comprovante_url: comprovanteUrl || null,
        antecedentes_url: antecedentesUrl || null,
        autoriza_imagem: autorizaImagem || false,
        status_aprovacao: "pendente",
        verification_status: "pending",
        is_active: false,
      })
      .select("id")
      .single();

    if (profileError) {
      await supabaseAdmin.auth.admin.deleteUser(userId);
      throw profileError;
    }

    const profileId = profileResult.id;

    // 4. Insert professional_services
    if (professionalServices && professionalServices.length > 0) {
      const svcs = professionalServices.map((s: any) => ({
        professional_id: profileId,
        service_id: s.service_id,
        charge_type: s.charge_type || "hour",
        price: parseFloat(s.price),
        handles_emergency: false,
        is_active: true,
      }));
      await supabaseAdmin.from("professional_services").insert(svcs);
    }

    // 5. Admin alert
    await supabaseAdmin.from("admin_alerts").insert({
      title: "Novo profissional aguardando aprovação",
      message: `${fullName} (CPF: ${cleanCpf}) se cadastrou e aguarda aprovação.`,
      alert_type: "new_professional",
      severity: "info",
      target_type: "profile",
      target_id: profileId,
    });

    // 6. OTP code
    const otpCode = Math.floor(100000 + Math.random() * 900000).toString();
    await supabaseAdmin.from("otp_codes").insert({
      cpf: cleanCpf,
      code: otpCode,
      expires_at: new Date(Date.now() + 10 * 60 * 1000).toISOString(),
    });

    return new Response(
      JSON.stringify({ success: true, profileId, otpCode, message: "Cadastro realizado!" }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    console.error("Error:", err);
    return new Response(
      JSON.stringify({ error: err.message || "Erro interno" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
